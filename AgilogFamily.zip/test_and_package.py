from pathlib import Path
import zipfile,subprocess,xml.etree.ElementTree as ET
src=Path('/mnt/data/agilog_v3');dest=Path('/mnt/data/AgilogFamily-v2.2.zip')
for x in [src/'android/app/src/main/AndroidManifest.xml',*list((src/'android/app/src/main/res/layout').glob('*.xml'))]:
    ET.parse(x)
js=src/'web/app.js'
r=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
assert r.returncode==0,r.stderr
rules=(src/'firestore.rules').read_text();assert "function validParts(p)" in rules and "feedParts" in rules
index=(src/'web/index.html').read_text();assert all(f'id="{x}"' in index for x in ['total-feed','n-feed','n-pee','n-poop','last-feed','last-pee','last-poop','editBreastMl','editPumpedMl','editFormulaMl','editBreastUnknown'])
for f in (src/'android/app/src/main/java').rglob('*.java'):
    s=f.read_text(); assert s.count('{')==s.count('}'),f
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for path in src.rglob('*'):
        if not path.is_file() or path.name.startswith('upgrade') or path.name=='test_and_package.py' or path.name=='__pycache__':continue
        z.write(path,arcname=path.relative_to(src).as_posix())
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    expect={'web/index.html','web/app.js','android/app/build.gradle','android/app/src/main/java/com/agilog/local/MainActivity.java','android/app/src/main/java/com/agilog/local/FamilyStore.java','android/app/src/main/java/com/agilog/local/RecordWorker.java','firestore.rules','.github/workflows/build-and-deploy.yml'}
    assert expect<=set(z.namelist()),expect-set(z.namelist())
print('Built',dest, dest.stat().st_size,'bytes')
print('Files:',len(zipfile.ZipFile(dest).namelist()))
print('JS syntax and XML syntax checked; actual Firebase/APK build not tested')
