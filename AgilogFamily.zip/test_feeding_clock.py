from playwright.sync_api import sync_playwright
from pathlib import Path
import json
src=Path('/mnt/data/agi_feedclock/web/app.js').read_text(encoding='utf-8')
js=src[src.index('const FEED_TIMELINE_TYPES='):src.index('function renderStatistics(){')]
style=Path('/mnt/data/agi_feedclock/web/index.html').read_text(encoding='utf-8')
css=style[style.index('/* v2.48: one local-calendar-day clock;'):style.index('/* v2.48: graph descriptions open only through the one ! button at top right. */')]
html=f'''<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8"><style>
body{{max-width:560px;background:#29242e;color:#f0e4eb;font-family:system-ui;margin:auto;padding:20px}}
.feeding-clock{{gap:10px}} {css}
</style></head><body><div id="feedingClock" class="feeding-clock"></div><script>
'use strict';
let records=[];
const $=id=>document.getElementById(id);
function partsFor(r){{return r.feedParts || {{breastMl:0,pumpedMl:0,formulaMl:r.ml||0,breastUnmeasured:false}};}}
function feedingAmountText(r){{return '합계 '+(r.ml||0)+'mL';}}
{js}
window.testRecord=(kind,days,hour,min,ml=120)=>{{
  const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()+days);d.setHours(hour,min,0,0);
  return {{kind,at:{{toDate:()=>d}},feedParts:{{breastMl:0,pumpedMl:0,formulaMl:ml,breastUnmeasured:false}},ml,feedType:'formula'}};
}};
window.setRecords=(rs)=>{{records=rs;renderFeedingClock();}};
</script></body></html>'''
Path('/mnt/data/agi_feedclock/feeding_clock_test.html').write_text(html,encoding='utf-8')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':412,'height':900},device_scale_factor=2)
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(html, wait_until='load')
    page.evaluate('''()=>{
     const current=new Date();const h=current.getHours();
     // Test can always use past times: set now to 23:59, by overriding clock Date?
     // Create example with source dates set to today and use current hours before current time.
     const today=()=>{const x=new Date();x.setHours(0,0,0,0);return x;};
     const earlier=(day, mins, ml)=>{const t=today();t.setDate(t.getDate()+day);t.setTime(t.getTime()+mins*60000);return {kind:'feed',at:{toDate:()=>t},feedType:'formula',feedParts:{formulaMl:ml,breastMl:0,pumpedMl:0,breastUnmeasured:false},ml};};
     // use renderer at arbitrary late fixed date via clockFeedingRecords(s,custom Now) separately
     window.sourceRecords=[earlier(-1, 240,45),earlier(-1, 540,60),earlier(-1, 1000,80),
         earlier(0, 0,100),earlier(0, 30,90),earlier(0, 59,80),earlier(0, 60,120),earlier(0, 80,40)];
    }''')
    # Use date-safe records that are all earlier than current local time (00:02 case test only today 00:00, midnight + 1m)
    page.evaluate('''()=>{
      const date=new Date();date.setHours(0,0,0,0);
      const add=(offset,min)=>{const d=new Date(date.getTime()+offset*86400000+min*60000);return {kind:'feed',at:{toDate:()=>d},feedType:'formula',feedParts:{formulaMl:100,pumpedMl:0,breastMl:0,breastUnmeasured:false},ml:100};};
      const now=new Date();const mins=now.getHours()*60+now.getMinutes();
      records=[add(-1,45),add(-1,330),add(-1,755),add(0,0)];
      if(mins>=1) records.push(add(0,1));
      renderFeedingClock();
    }''')
    if errors:raise AssertionError('page errors: '+str(errors))
    initial=page.evaluate('''()=>({summary:document.querySelector('.feeding-clock-summary').textContent,
      previous:document.querySelectorAll('.feeding-clock-previous').length,
      current:document.querySelectorAll('.feeding-clock-mark').length,
      previousOpacity:getComputedStyle(document.querySelector('.feeding-clock-previous')).opacity,
      aria:document.querySelector('.feeding-clock-previous').getAttribute('aria-hidden'),
      prevActions:[...document.querySelectorAll('.feeding-clock-previous')].map(x=>x.getAttribute('role')||'none'),
      listings:document.querySelectorAll('.feeding-clock-record').length,
      times: [...document.querySelectorAll('.feeding-clock-record strong')].map(e=>e.textContent)
    })''')
    print('INITIAL',initial)
    assert initial['previous']==3
    assert initial['current'] in (1,2)
    assert initial['previousOpacity']=='0.3'
    assert initial['listings']==initial['current']
    assert initial['aria']=='true'
    assert all(x=='none' for x in initial['prevActions'])
    # Confirm grouping math independent of real current hour via mock JS entries
    sessions=page.evaluate('''()=>{
      const t=new Date();t.setHours(9,0,0,0);
      const entries=[0,30,59,60,80,120].map(i=>({at:new Date(t.getTime()+i*60000),ring:i<180?'am':'pm'}));
      return clockFeedSessions(entries).map(s=>({start:s.startedAt,len:s.items.length}));
    }''')
    print('SESSIONS',sessions)
    assert [s['len'] for s in sessions]==[3,2,1]
    # Noon-crossing: 11:45 + 12:15 are one morning-anchored session, 12:45 second
    crossing=page.evaluate('''()=>{
      const t=new Date();t.setHours(11,45,0,0);
      const entries=[0,30,60].map(i=>({at:new Date(t.getTime()+i*60000),ring:i<15?'am':'pm'}));
      return clockFeedSessions(entries).map(s=>[s.ring,s.items.length]);
    }''')
    print('NOON CROSS',crossing)
    assert crossing==[['am',2],['pm',1]]
    assert not errors, errors
    page.screenshot(path='/mnt/data/agi_feedclock/feed_clock_preview.png',full_page=True)
    browser.close()
print('PASS')
