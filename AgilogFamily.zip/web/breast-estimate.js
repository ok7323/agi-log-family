/** Graph-only estimate for DIRECT breastfeeds with no measured volume.
 * The first recorded direct breastfeed is always 50mL (even if a pump record
 * exists earlier). Subsequent direct breastfeeds use elapsed time since the
 * latest prior direct pumping or direct breastfeeding event at 25mL/hour.
 * A 60-minute anchored feeding session gets at most one estimate.
 * These are display-only approximations, NOT measured intake or Firebase data.
 */
export const ESTIMATE_ML_PER_HOUR=25;
export function breastEstimateByDay(source){
  const now=Date.now()+300000;
  const sorted=source.map(r=>{
    const d=typeof r?.at?.toDate==='function'?r.at.toDate():r?.at;
    return {r,t:d instanceof Date?d.getTime():NaN};
  }).filter(e=>Number.isFinite(e.t)&&e.t<=now).sort((a,b)=>a.t-b.t||
    (a.r.kind==='pump'?-1:0)-(b.r.kind==='pump'?-1:0));
  const byDay=new Map();let lastTrigger=null,anchor=null,estimatedThisSession=false;
  let hasPriorDirectBreastfeed=false;
  for(const {r,t} of sorted){
    if(r.kind==='pump'){lastTrigger=t;continue;}
    if(r.kind!=='feed')continue;
    if(anchor===null||t-anchor>=3600000){anchor=t;estimatedThisSession=false;}
    if(r.legacy)continue;
    const p=r.feedParts&&typeof r.feedParts==='object'?r.feedParts:null;
    const measured=p?Number(p.breastMl)||0:r.feedType==='breast'&&Number(r.ml)>0?Number(r.ml):0;
    const unmeasured=p?p.breastUnmeasured===true:r.feedType==='breast'&&Number(r.ml)===-1;
    const isDirect=measured>0||unmeasured;
    if(unmeasured&&!estimatedThisSession){
      // The first direct nursing session must never inherit days/weeks of
      // elapsed time from an old pumping record (a very tall yellow bar).
      // If no prior DIRECT breastfeeding exists, use a fixed 50mL baseline.
      // For all later sessions, preserve the existing 25mL/hour rule.
      const amount=!hasPriorDirectBreastfeed?50:
        lastTrigger!==null&&t>lastTrigger
          ?Math.round((t-lastTrigger)/3600000*ESTIMATE_ML_PER_HOUR):0;
      const d=new Date(anchor);const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
      if(amount>0)byDay.set(key,(byDay.get(key)||0)+amount);
      estimatedThisSession=true;
    }
    if(isDirect){hasPriorDirectBreastfeed=true;lastTrigger=t;}
  }
  return byDay;
}
