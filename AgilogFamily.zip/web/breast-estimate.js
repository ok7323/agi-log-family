/** Graph-only breastmilk approximation; DOES NOT change recorded quantities.
 *  The first direct breastfeed of EACH LOCAL DAY is fixed to 50mL.
 *  Later direct unmeasured breastfeeding: 25mL/hour since the preceding direct
 *  breastfeeding or pumping. If that preceding event is more than 12h old,
 *  the stale gap is never used: reset to 50mL.
 *  This fixes a 2,450mL yellow bar produced by a pumping record days earlier.
 *  One unmeasured breastfeed per anchored 60-minute feeding session is counted.
 */
export const ESTIMATE_ML_PER_HOUR=25;
export const FIRST_BREAST_ESTIMATE_ML=50;
export const MAX_PRIOR_GAP_MS=12*3600000;
export function breastEstimateByDay(source){
  const now=Date.now()+300000;
  const sorted=source.map(r=>{
    const d=typeof r?.at?.toDate==='function'?r.at.toDate():r?.at;
    return {r,t:d instanceof Date?d.getTime():NaN};
  }).filter(e=>Number.isFinite(e.t)&&e.t<=now).sort((a,b)=>a.t-b.t||
    (a.r.kind==='pump'?-1:0)-(b.r.kind==='pump'?-1:0));
  const byDay=new Map();let lastTrigger=null,anchor=null,estimatedThisSession=false;
  let lastDirectBreastDay=null;
  const dayKey=t=>{const d=new Date(t);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  for(const {r,t} of sorted){
    if(r.kind==='pump'){lastTrigger=t;continue;}
    if(r.kind!=='feed')continue;
    if(anchor===null||t-anchor>=3600000){anchor=t;estimatedThisSession=false;}
    if(r.legacy)continue;
    const p=r.feedParts&&typeof r.feedParts==='object'?r.feedParts:null;
    const measured=p?Number(p.breastMl)||0:r.feedType==='breast'&&Number(r.ml)>0?Number(r.ml):0;
    const unmeasured=p?p.breastUnmeasured===true:r.feedType==='breast'&&Number(r.ml)===-1;
    const isDirect=measured>0||unmeasured;
    if(unmeasured&&!estimatedThisSession){
      // Reset at the first DIRECT breastfeed of each local calendar day,
      // even if a direct breastfeed happened a week earlier in history.
      const firstOfDay=lastDirectBreastDay!==dayKey(t);
      const staleGap=lastTrigger===null||t-lastTrigger>MAX_PRIOR_GAP_MS;
      const amount=firstOfDay||staleGap?FIRST_BREAST_ESTIMATE_ML:
        t>lastTrigger?Math.round((t-lastTrigger)/3600000*ESTIMATE_ML_PER_HOUR):0;
      const key=dayKey(anchor);
      if(amount>0)byDay.set(key,(byDay.get(key)||0)+amount);
      estimatedThisSession=true;
    }
    if(isDirect){lastDirectBreastDay=dayKey(t);lastTrigger=t;}
  }
  return byDay;
}
