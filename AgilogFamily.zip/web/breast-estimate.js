/** Graph-only estimate based on time since the previous DIRECT pumping/breastfeeding event.
 * No prior event -> 0. A 60-minute anchored feeding session receives at most
 * one estimate, even when it contains multiple unmeasured breast-feeding records.
 * This is NOT a physiological model and is never stored or included in measured mL.
 */
export const ESTIMATE_ML_PER_HOUR=25;
export function breastEstimateByDay(source){
  const now=Date.now()+300000;
  const sorted=source.map(r=>{
    const d=typeof r?.at?.toDate==='function'?r.at.toDate():r?.at;
    return {r,t:d instanceof Date?d.getTime():NaN};
  }).filter(e=>Number.isFinite(e.t)&&e.t<=now).sort((a,b)=>a.t-b.t||
    (a.r.kind==='pump'?-1:0)-(b.r.kind==='pump'?-1:0));
  const byDay=new Map();let lastTrigger=null,anchor=null,estimatedThisSession=false;
  for(const {r,t} of sorted){
    if(r.kind==='pump'){lastTrigger=t;continue;}
    if(r.kind!=='feed')continue;
    if(anchor===null||t-anchor>=3600000){anchor=t;estimatedThisSession=false;}
    if(r.legacy)continue;
    const p=r.feedParts&&typeof r.feedParts==='object'?r.feedParts:null;
    const measured=p?Number(p.breastMl)||0:r.feedType==='breast'&&Number(r.ml)>0?Number(r.ml):0;
    const unmeasured=p?p.breastUnmeasured===true:r.feedType==='breast'&&Number(r.ml)===-1;
    const isDirect=measured>0||unmeasured;
    if(unmeasured&&!estimatedThisSession){
      if(lastTrigger!==null&&t>lastTrigger){
        const amount=Math.round((t-lastTrigger)/3600000*ESTIMATE_ML_PER_HOUR);
        const d=new Date(anchor);const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
        byDay.set(key,(byDay.get(key)||0)+amount);
      }
      estimatedThisSession=true;
    }
    if(isDirect)lastTrigger=t;
  }
  return byDay;
}
