// Family feeding/diaper history export. Unlike the on-screen list, CSV has no row cap.
// Keep the schema in sync with android/.../FamilyCsv.java.
const HEADERS=['기록ID','기록시각 (기기 시간대)','종류','수유종류','모유(mL)','유축(mL)','분유(mL)','모유미측정','수유총측정량(mL)','기저귀양','기록자','출처','예전기록'];
const kinds={feed:'수유',pee:'소변',poop:'대변',both:'소+대변'};
const feedTypes={breast:'모유',pumped:'유축',formula:'분유',mixed:'혼합'};
const sizes={small:'소',medium:'중',large:'대'};
// Prevent spreadsheet formula execution in free-text fields such as family names.
export function csvCell(value){
  let text=String(value??'');
  if(/^[\s\uFEFF]*[=+\-@]/u.test(text))text="'"+text;
  return /[",\r\n]/.test(text)?'"'+text.replaceAll('"','""')+'"':text;
}
function when(value){
  const date=value?.toDate?.()|| (value instanceof Date?value:null);
  if(!(date instanceof Date)||!Number.isFinite(date.getTime()))return '';
  const pad=n=>String(n).padStart(2,'0');
  const tz=-date.getTimezoneOffset(),sign=tz>=0?'+':'-';
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())} ${sign}${pad(Math.floor(Math.abs(tz)/60))}:${pad(Math.abs(tz)%60)}`;
}
function feeding(r){
  if(r.legacy||r.kind!=='feed')return {b:'',p:'',f:'',u:'',total:''};
  if(r.feedParts&&typeof r.feedParts==='object'){
    const b=Number(r.feedParts.breastMl)||0,p=Number(r.feedParts.pumpedMl)||0,f=Number(r.feedParts.formulaMl)||0;
    return {b,p,f,u:r.feedParts.breastUnmeasured===true?'예':'아니오',total:b+p+f};
  }
  const ml=Number(r.ml)||0;
  return {b:r.feedType==='breast'&&ml>0?ml:0,p:r.feedType==='pumped'&&ml>0?ml:0,
    f:r.feedType==='formula'&&ml>0?ml:0,u:r.feedType==='breast'&&ml===-1?'예':'아니오',total:Math.max(ml,0)};
}
export function serializeFamilyCsv(items){
  const lines=[HEADERS.map(csvCell).join(',')];
  for(const r of items){
    const f=feeding(r),feed=r.kind==='feed';
    lines.push([
      r.id||'',when(r.at),kinds[r.kind]||r.kind||'',feed?(feedTypes[r.feedType]||r.feedType||''):'',
      f.b,f.p,f.f,f.u,f.total,feed?'':sizes[r.size]||'',r.who||'',r.source||'',r.legacy===true?'예':'아니오'
    ].map(csvCell).join(','));
  }
  return lines.join('\r\n')+'\r\n';
}
