import {initializeApp} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js';
import {getAuth,onAuthStateChanged,signInAnonymously} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js';
import {getFirestore,doc,setDoc,getDoc,addDoc,collection,query,orderBy,onSnapshot,getDocsFromServer,deleteDoc,updateDoc,deleteField,Timestamp,serverTimestamp} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js';
import {firebaseConfig} from './firebase-config.js';
import {serializeFamilyCsv} from './family-csv.js';
import {breastEstimateByDay} from './breast-estimate.js';
const $=id=>document.getElementById(id);
let auth,db,user=null,family='',who='',unsubscribe=null,records=[],kind='',feedType='',editingId=null;
let activeTab='record',statsDays=7,olderRecordsExpanded=false,olderRecordsVisible=100;
const labels={feed:'수유',diaper:'기저귀',pump:'유축 시작',poop:'대변',pee:'소변',both:'소+대변',breast:'모유',pumped:'유축',formula:'분유',mixed:'혼합',small:'소',medium:'중',large:'대'};
const icons={feed:'🍼',diaper:'🧷',pump:'🥛',poop:'💩',pee:'💧',both:'💧💩'};
const CODE='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const DEFAULT_PUMPED_KEY='agilog-default-pumped-ml-v1';
const DEFAULT_FORMULA_KEY='agilog-default-formula-ml-v1';
function validDefaultMl(value){const n=Number(value);return Number.isInteger(n)&&n>=5&&n<=1000&&n%5===0;}
function readDefault(key){
  try{const raw=localStorage.getItem(key);return raw!==null&&validDefaultMl(raw)?Number(raw):50;}
  catch(_){return 50;}
}
function defaultPumpedMl(){return readDefault(DEFAULT_PUMPED_KEY);}
function defaultFormulaMl(){return readDefault(DEFAULT_FORMULA_KEY);}
function openFeedSettings(){
  $('defaultPumpedMl').value=String(defaultPumpedMl());
  $('defaultFormulaMl').value=String(defaultFormulaMl());
  $('feedSettingsError').textContent='';
  $('settingsDialog').showModal();
}
function adjustDefault(which,delta){
  const id=which==='pumped'?'defaultPumpedMl':'defaultFormulaMl';
  const fallback=which==='pumped'?defaultPumpedMl():defaultFormulaMl();
  const raw=Number($(id).value);const n=Number.isFinite(raw)&&raw>0?raw:fallback;
  $(id).value=String(Math.max(5,Math.min(1000,Math.round(n/5)*5+delta)));
}
function saveFeedSettings(){
  const pump=$('defaultPumpedMl').value.trim(),formula=$('defaultFormulaMl').value.trim();
  if(!/^\d+$/.test(pump)||!validDefaultMl(pump)||!/^\d+$/.test(formula)||!validDefaultMl(formula)){
    $('feedSettingsError').textContent='유축·분유 각각 5~1000mL, 5mL 단위로 입력하세요.';return;
  }
  try{
    localStorage.setItem(DEFAULT_PUMPED_KEY,pump);
    localStorage.setItem(DEFAULT_FORMULA_KEY,formula);
  }catch(e){$('feedSettingsError').textContent='설정을 저장할 수 없습니다. 브라우저 저장 공간을 확인하세요.';return;}
  $('settingsDialog').close();
}
function error(msg){$('error').textContent=String(msg);$('error').classList.remove('hidden');}
function clearError(){$('error').classList.add('hidden');$('error').textContent='';}
function show(id,flag){$(id).classList.toggle('hidden',!flag);}
function newCode(){const bytes=crypto.getRandomValues(new Uint8Array(20));return Array.from(bytes,v=>CODE[v%CODE.length]).join('');}
function name(){const v=$('name').value.trim();if(v.length<1||v.length>40)throw Error('이름을 1~40자로 입력하세요.');return v;}
function meta(){return{createdBy:user.uid,who,source:'web'};}
async function createFamily(){clearError();try{
  who=name();const code=newCode();
  // Failed member creation is recoverable: paste the new code into the join form.
  await setDoc(doc(db,'families',code),{createdBy:user.uid,createdAt:serverTimestamp()});
  try{await setDoc(doc(db,'families',code,'members',user.uid),{name:who,joinedAt:serverTimestamp()});}
  catch(e){$('invite').value=code;throw Error('가족은 만들었지만 가입에 실패했어요. 화면에 표시된 코드를 보관하고 다시 가입해 주세요. '+e.message);}
  await enter(code,who);
}catch(e){error(e.message);}}
async function joinFamily(){clearError();try{
  who=name();const code=$('invite').value.toUpperCase().replace(/[\s-]/g,'');
  if(!/^[A-HJ-NP-Z2-9]{20}$/.test(code))throw Error('가족 코드는 영문/숫자 20자리입니다.');
  try{await setDoc(doc(db,'families',code,'members',user.uid),{name:who,joinedAt:serverTimestamp()});}
  catch(e){const existing=await getDoc(doc(db,'families',code,'members',user.uid)).catch(()=>null);
    if(!existing?.exists())throw Error('코드가 틀렸거나 권한이 없습니다. 다시 확인해 주세요. '+e.message);
  }
  await enter(code,who);
}catch(e){error(e.message);}}
async function enter(code,n){
  stopToolSync();toolCache={};family=code;who=n;
  localStorage.setItem('agilog-family-code',code);localStorage.setItem('agilog-family-name',n);
  $('familyCode').textContent=code;
  show('connect',false);show('app',true);show('status',false);
  if(unsubscribe){unsubscribe();unsubscribe=null;}
  const q=query(collection(db,'families',code,'events'),orderBy('at','desc')); // 전체 기록을 받아 오늘 총계와 마지막 시간을 정확하게 계산
  unsubscribe=onSnapshot(q,snap=>{records=snap.docs.map(d=>({id:d.id,...d.data()}));renderRecords();},e=>error('기록을 불러오지 못했어요: '+e.message));
}
function partsFor(r){
  if(r.feedParts && typeof r.feedParts==='object'){
    return {breastMl:Number(r.feedParts.breastMl)||0,pumpedMl:Number(r.feedParts.pumpedMl)||0,formulaMl:Number(r.feedParts.formulaMl)||0,breastUnmeasured:r.feedParts.breastUnmeasured===true};
  }
  const p={breastMl:0,pumpedMl:0,formulaMl:0,breastUnmeasured:r.feedType==='breast'&&r.ml===-1};
  if(['breast','pumped','formula'].includes(r.feedType)&&Number(r.ml)>0)p[r.feedType==='breast'?'breastMl':r.feedType==='pumped'?'pumpedMl':'formulaMl']=r.ml;
  return p;
}
function feedTotal(r){if(r.kind!=='feed'||r.legacy)return 0;const p=partsFor(r);return p.breastMl+p.pumpedMl+p.formulaMl;}
function feedUnknown(r){return r.kind==='feed'&&!r.legacy&&partsFor(r).breastUnmeasured;}
function elapsed(date){
  if(!date)return '기록 없음';
  const minutes=Math.max(0,Math.floor((Date.now()-date.getTime())/60000));
  return String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0');
}
// Latest and immediately previous feeding are selected by recorded time, not by the current day's boundary.
function feedingAmountText(r){
  if(!r)return '수유량 없음';
  if(r.legacy)return '수유량 정보 없음';
  const p=partsFor(r),amount=feedTotal(r);
  const components=[];
  if(p.breastMl>0)components.push('모유 '+p.breastMl);
  if(p.breastUnmeasured)components.push('모유 미측정');
  if(p.pumpedMl>0)components.push('유축 '+p.pumpedMl);
  if(p.formulaMl>0)components.push('분유 '+p.formulaMl);
  if(amount===0&&p.breastUnmeasured)return '모유 미측정';
  if(amount===0)return '수유량 정보 없음';
  return components.join(' + ')+' · 합계 '+amount+'mL';
}
// A feeding session starts at its first recorded feed and lasts 60 minutes.
// Three feeds at 09:00, 09:25 and 09:55 count as ONE session; 10:00 starts another.
// Individual records and amounts remain unchanged.
function groupFeedSessions(items){
  const now=Date.now();
  const feeds=items.filter(r=>r.kind==='feed'&&r.at?.toDate?.() instanceof Date&&r.at.toDate().getTime()<=now+300000)
    .sort((a,b)=>a.at.toDate().getTime()-b.at.toDate().getTime());
  const sessions=[];
  for(const r of feeds){
    const timestamp=r.at.toDate().getTime();
    const p=partsFor(r),breast=!r.legacy&&(p.breastMl>0||p.breastUnmeasured);
    const breastUnmeasured=!r.legacy&&p.breastUnmeasured;
    let last=sessions[sessions.length-1];
    if(!last||timestamp-last.startedAt>=3600000){
      last={startedAt:timestamp,breast,breastUnmeasured};sessions.push(last);
    }else{if(breast)last.breast=true;if(breastUnmeasured)last.breastUnmeasured=true;}
  }
  return sessions;
}
function daySummary(items, allSessions=null, start=null, end=null){
  const feeds=items.filter(r=>r.kind==='feed');
  const measured=feeds.reduce((sum,r)=>sum+feedTotal(r),0);
  const sessions=allSessions&&start!==null&&end!==null
    ?allSessions.filter(session=>session.startedAt>=start&&session.startedAt<end)
    :groupFeedSessions(items);
  const breast=sessions.filter(session=>session.breast).length;
  const breastUnmeasured=sessions.filter(session=>session.breastUnmeasured).length;
  const pumped=feeds.reduce((sum,r)=>sum+(r.legacy?0:partsFor(r).pumpedMl),0);
  const formula=feeds.reduce((sum,r)=>sum+(r.legacy?0:partsFor(r).formulaMl),0);
  const poop=items.filter(r=>r.kind==='poop'||r.kind==='both').length;
  const pee=items.filter(r=>r.kind==='pee'||r.kind==='both').length;
  const diapers=items.filter(r=>['pee','poop','both'].includes(r.kind)).length;
  const both=items.filter(r=>r.kind==='both').length;
  const breastMl=feeds.reduce((sum,r)=>sum+(r.legacy?0:partsFor(r).breastMl),0);
  const pumpEvents=items.filter(r=>r.kind==='pump');
  const pumpMl=pumpEvents.reduce((sum,r)=>sum+Math.max(0,Number(r.ml)||0),0);
  return {feeds:sessions.length,measured,breast,breastUnmeasured,breastMl,pumped,formula,poop,pee,both,diapers,pumpMl,pumpCount:pumpEvents.length};
}
function refreshSummary(){
  const now=new Date(),todayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
  const yesterdayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1).getTime();
  const eligible=records.filter(r=>r.at?.toDate?.() instanceof Date&&r.at.toDate().getTime()<=Date.now()+300000);
  const sessions=groupFeedSessions(eligible);
  const today=daySummary(eligible.filter(r=>r.at.toDate().getTime()>=todayStart),sessions,todayStart,Infinity);
  const yesterday=daySummary(eligible.filter(r=>r.at.toDate().getTime()>=yesterdayStart&&r.at.toDate().getTime()<todayStart),sessions,yesterdayStart,todayStart);
  for(const [prefix,data] of [['today',today],['yesterday',yesterday]]){
    $(prefix+'-breast').textContent=data.breast+'회';
    $(prefix+'-pumped').textContent=data.pumped+'mL';
    $(prefix+'-pump-count').textContent=data.pumpCount+'회';
    $(prefix+'-pump-ml').textContent=data.pumpMl+'mL';
    $(prefix+'-formula').textContent=data.formula+'mL';
  }
  $('n-feed').textContent=today.feeds+'회';
  $('total-feed').textContent=today.measured+'mL';
  $('n-poop').textContent=today.poop+'회';$('n-pee').textContent=today.pee+'회';$('n-diapers').textContent=today.diapers+'개';
  $('yesterday-n-feed').textContent=yesterday.feeds+'회';
  $('yesterday-feed').textContent=yesterday.measured+'mL';
  $('yesterday-poop').textContent=yesterday.poop+'회';
  $('yesterday-pee').textContent=yesterday.pee+'회';$('yesterday-diapers').textContent=yesterday.diapers+'개';
  const feedEvents=eligible.filter(r=>r.kind==='feed')
    .sort((a,b)=>b.at.toDate().getTime()-a.at.toDate().getTime());
  const latest=feedEvents[0],previous=feedEvents[1];
  $('last-feed').textContent=elapsed(latest?.at?.toDate?.());
  $('last-feed-amount').textContent=feedingAmountText(latest);
  $('previous-feed').textContent=elapsed(previous?.at?.toDate?.());
  $('previous-feed-amount').textContent=feedingAmountText(previous);
  // The timer restarts after actual expression or DIRECT breastfeeding, not
  // after giving pumped milk or formula. Mixed feeds count only if breast is used.
  const pumpAndBreast=eligible.filter(r=>r.kind==='pump'||
    (r.kind==='feed'&&!r.legacy&&
      (partsFor(r).breastMl>0||partsFor(r).breastUnmeasured)))
    .sort((a,b)=>b.at.toDate().getTime()-a.at.toDate().getTime());
  const pumpKind=r=>!r?'기록 없음':r.kind==='pump'?'직접 유축 시작':'직접 모유수유';
  $('last-pump').textContent=elapsed(pumpAndBreast[0]?.at?.toDate?.());
  $('previous-pump').textContent=elapsed(pumpAndBreast[1]?.at?.toDate?.());
  $('last-pump-kind').textContent=pumpKind(pumpAndBreast[0]);
  $('previous-pump-kind').textContent=pumpKind(pumpAndBreast[1]);
  for(const k of ['poop','pee']){
    const r=eligible.find(e=>e.kind===k||e.kind==='both');
    $('last-'+k).textContent=elapsed(r?.at?.toDate?.());
  }
}
function formatTime(item){const value=item.at?.toDate?.()||new Date();return value.toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});}
function details(r){
  if(r.legacy)return '이전 기록 · 상세 정보 없음';
  if(r.kind==='pump')return (Number(r.ml)>0?'유축량 '+Number(r.ml)+'mL':'유축 시작 · 양 미입력');
  if(r.kind==='feed'){
    const p=partsFor(r),items=[];
    if(p.breastMl)items.push('모유 '+p.breastMl+'mL');
    if(p.breastUnmeasured)items.push('모유 양 미측정');
    if(p.pumpedMl)items.push('유축 '+p.pumpedMl+'mL');
    if(p.formulaMl)items.push('분유 '+p.formulaMl+'mL');
    return (items.length?items.join(' + '):'수유')+' · 합계 '+feedTotal(r)+'mL'+(p.breastUnmeasured?' (미측정 제외)':'');
  }
  return '양 '+(labels[r.size]||'-');
}
// The last rolling 12h is shown by default; older records and full CSV remain accessible.
function recordElement(r){
  const entry=document.createElement('div');entry.className='event';entry.tabIndex=0;entry.setAttribute('role','button');
  entry.onclick=e=>{if(!e.target.closest('button'))openEdit(r);};
  entry.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&e.target===entry){e.preventDefault();openEdit(r);}};
  const symbol=document.createElement('span');symbol.textContent=icons[r.kind]||'🍼';entry.append(symbol);
  const main=document.createElement('div'),name=document.createElement('b'),detail=document.createElement('small');
  name.textContent=(labels[r.kind]||'기록')+' · '+formatTime(r);detail.textContent=details(r)+' · '+(r.who||'가족');
  main.append(name,detail);entry.append(main);
  const edit=document.createElement('button');edit.className='edit';edit.textContent='수정';edit.onclick=()=>openEdit(r);entry.append(edit);
  if(r.createdBy===user?.uid){const btn=document.createElement('button');btn.textContent='삭제';btn.onclick=async()=>{
    if(!confirm('이 기록을 가족 모두의 기록에서 삭제할까요?'))return;
    try{await deleteDoc(doc(db,'families',family,'events',r.id));}catch(e){error(e.message);}
  };entry.append(btn);}
  return entry;
}
function renderRecords(){
  refreshSummary();
  if(activeTab==='stats')renderStatistics();
  const now=Date.now(),cutoff=now-12*60*60*1000;
  const recent=[],older=[];
  for(const r of records){const at=r.at?.toDate?.();
    if(at instanceof Date&&Number.isFinite(at.getTime())&&at.getTime()>=cutoff&&at.getTime()<=now+300000)recent.push(r);
    else older.push(r);
  }
  const container=$('records');container.replaceChildren();
  $('recentRecordsCount').textContent=`최근 12시간 ${recent.length}건 · 이전 기록 ${older.length}건`;
  if(!recent.length)container.textContent='최근 12시간 내 기록이 없어요 🌱';
  else container.append(...recent.map(recordElement));
  const toggle=$('olderRecordsToggle');toggle.classList.toggle('hidden',older.length===0);
  toggle.textContent=olderRecordsExpanded?`이전 기록 접기 (${older.length}건)`:`이전 기록 펼치기 (${older.length}건)`;
  toggle.setAttribute('aria-expanded',String(olderRecordsExpanded));
  const past=$('olderRecords');past.classList.toggle('hidden',!olderRecordsExpanded||older.length===0);
  past.replaceChildren();
  if(olderRecordsExpanded)past.append(...older.slice(0,olderRecordsVisible).map(recordElement));
  const more=$('olderRecordsMore');const remain=Math.max(0,older.length-olderRecordsVisible);
  more.classList.toggle('hidden',!olderRecordsExpanded||remain===0);
  more.textContent=`이전 기록 ${Math.min(100,remain)}건 더 보기 (${remain}건 남음)`;
}
async function downloadAllFamilyCsv(){
  const button=$('downloadFamilyCsv'),message=$('familyCsvStatus');
  if(!family||!user){message.textContent='먼저 가족에 연결해 주세요.';return;}
  button.disabled=true;button.textContent='Firebase에서 전체 기록 조회 중…';
  message.textContent='전체 기록을 가져오고 있어요. 네트워크 연결이 필요합니다.';
  try{
    // A fresh server query avoids exporting a limited, old or offline UI snapshot.
    const q=query(collection(db,'families',family,'events'),orderBy('at','desc'));
    const snap=await getDocsFromServer(q);
    const rows=snap.docs.map(d=>({id:d.id,...d.data()}));
    const body=serializeFamilyCsv(rows);
    const blob=new Blob(['\uFEFF',body],{type:'text/csv;charset=utf-8'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');
    const now=new Date(),pad=n=>String(n).padStart(2,'0');
    a.href=url;a.download=`AgilogFamily_AllRecords_${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}.csv`;
    document.body.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),30000);
    message.textContent=`전체 ${rows.length}건 CSV 다운로드를 요청했어요. 파일 앱의 다운로드 폴더를 확인해 주세요.`;
  }catch(e){message.textContent='CSV 내보내기 실패: '+e.message;error('CSV 내보내기 실패: '+e.message);}
  finally{button.disabled=false;button.textContent='전체 기록 CSV 저장';}
}
// Daily statistics use local calendar dates, so midnight and daylight-saving changes
// do not shift a feeding or a diaper event into the wrong day.
function dayRows(days){
  const now=new Date(),out=[],sessions=groupFeedSessions(records),estimated=breastEstimateByDay(records);
  for(let offset=days-1;offset>=0;offset--){
    const start=new Date(now.getFullYear(),now.getMonth(),now.getDate()-offset);
    const end=new Date(start.getFullYear(),start.getMonth(),start.getDate()+1);
    const one=records.filter(r=>{const d=r.at?.toDate?.();return d instanceof Date&&d>=start&&d<end&&d.getTime()<=Date.now()+300000;});
    const key=`${start.getFullYear()}-${String(start.getMonth()+1).padStart(2,'0')}-${String(start.getDate()).padStart(2,'0')}`;
    out.push({date:start, ...daySummary(one,sessions,start.getTime(),end.getTime()),breastEstimatedMl:estimated.get(key)||0});
  }
  return out;
}
// Charts keep exact logged milk totals separate from the 25mL/hour *visual estimate*
// for direct breastfeeding where no milk amount was measured. The approximation
// is never saved to Firebase and never added to the actual statistics totals.
function drawBars(id,rows,type){
  const canvas=$(id),scroll=canvas.parentElement;
  const seven=statsDays===7;
  const cssWidth=seven?Math.max(245,scroll.clientWidth):Math.max(scroll.clientWidth,rows.length*38+18);
  const cssHeight=217,ratio=Math.min(window.devicePixelRatio||1,3);
  canvas.style.width=cssWidth+'px';canvas.style.height=cssHeight+'px';
  canvas.width=Math.round(cssWidth*ratio);canvas.height=Math.round(cssHeight*ratio);
  const ctx=canvas.getContext('2d');if(!ctx)return;
  ctx.scale(ratio,ratio);ctx.clearRect(0,0,cssWidth,cssHeight);
  const left=35,right=5,top=49,bottom=185,height=bottom-top;
  const measured=r=>type==='milk'?r.breastMl+r.pumped+r.formula:type==='formula'?r.formula:r.diapers;
  const estimate=r=>type==='milk'?Math.max(0,Number(r.breastEstimatedMl)||0):0;
  const chartValue=r=>measured(r)+estimate(r);
  const max=Math.max(1,...rows.map(chartValue));
  const step=Math.max(1,Math.ceil(max/4/((type==='diaper')?1:10))*((type==='diaper')?1:10));
  const ceiling=step*4,usable=cssWidth-left-right;
  ctx.strokeStyle='#ebdfe1';ctx.fillStyle='#8b7381';ctx.lineWidth=1;
  ctx.font='10px system-ui';ctx.textAlign='right';
  for(let i=0;i<=4;i++){
    const y=bottom-i*step/ceiling*height;
    ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(cssWidth-right,y);ctx.stroke();
    ctx.fillText(String(i*step),left-5,y+3);
  }
  ctx.textAlign='center';
  rows.forEach((r,i)=>{
    const mid=left+(i+0.5)*usable/rows.length,barW=Math.min(27,usable/rows.length*.64);
    let base=bottom;
    const segments=type==='milk'?
      [[r.formula,'#d88692'],[r.pumped,'#77a6d5'],[r.breastMl,'#eac276']]:
      type==='formula'?[[r.formula,'#d88692']]:[[r.diapers,'#7a9cce']];
    for(const [v,color] of segments){
      const h=Math.max(0,Number(v)||0)/ceiling*height;
      if(h>0){ctx.fillStyle=color;ctx.fillRect(mid-barW/2,base-h,barW,h);base-=h;}
    }
    if(type==='milk'&&estimate(r)>0){
      const h=estimate(r)/ceiling*height;
      ctx.fillStyle='#f5d99b';ctx.fillRect(mid-barW/2,base-h,barW,h);
      ctx.strokeStyle='#b58a49';ctx.lineWidth=1;
      ctx.strokeRect(mid-barW/2+.5,base-h+.5,barW-1,Math.max(0,h-1));
      base-=h;
    }
    if(type==='milk'){
      ctx.font='bold 10px system-ui';ctx.fillStyle='#634d58';
      ctx.fillText('모 '+(Number(r.breast)||0)+'회',mid,15);
    }
    if(type==='milk'||type==='formula'){
      // Exact measured quantity, not an estimated/combined volume.
      ctx.fillStyle='#445e81';ctx.font='bold 10px system-ui';
      const mlText=measured(r)+'mL';
      const slot=usable/rows.length;
      ctx.fillText(ctx.measureText(mlText).width>slot-2?String(measured(r)):mlText,mid,Math.max(top-5,base-7));
    }
    if(type==='diaper'&&r.diapers){
      ctx.fillStyle='#8b7381';ctx.font='10px system-ui';
      ctx.fillText(String(r.diapers),mid,Math.max(13,base-5));
    }
    ctx.fillStyle='#8b7381';ctx.font='11px system-ui';
    ctx.fillText(String(r.date.getDate()),mid,bottom+17);
  });
}
/** Day-by-day expressed-milk FEEDING (mL), with direct breastfeed sessions above.
 *  NOTE: rows[].pumpMl is the amount extracted by the parent, and MUST NOT be
 *  used here. rows[].pumped is the amount fed to the baby, including mixed feeds.
 *  The left axis represents mL ONLY; the count labels are never axis values.
 */
function drawPumpedFeedingChart(id,rows){
  const canvas=$(id),scroll=canvas.parentElement;
  // All seven days fit without sideways scrolling on a phone. Only 30-day mode scrolls.
  const cssWidth=statsDays===7?Math.max(245,scroll.clientWidth):Math.max(scroll.clientWidth,rows.length*44+44);
  const cssHeight=245,ratio=Math.min(window.devicePixelRatio||1,3);
  canvas.style.width=cssWidth+'px';canvas.style.height=cssHeight+'px';
  canvas.width=Math.round(cssWidth*ratio);canvas.height=Math.round(cssHeight*ratio);
  const ctx=canvas.getContext('2d');if(!ctx)return;
  ctx.scale(ratio,ratio);ctx.clearRect(0,0,cssWidth,cssHeight);
  const left=38,top=68,bottom=219,height=bottom-top;
  const value=r=>Math.max(0,Number(r.pumped)||0);
  const estimated=r=>Math.max(0,Number(r.breastEstimatedMl)||0);
  const max=Math.max(1,...rows.map(r=>value(r)+estimated(r)));
  const step=Math.max(10,Math.ceil(max/40)*10);
  const ceiling=step*4;
  ctx.strokeStyle='#ebdfe1';ctx.fillStyle='#8b7381';ctx.lineWidth=1;
  ctx.font='10px system-ui';ctx.textAlign='right';
  for(let i=0;i<=4;i++){
    const y=bottom-i*step/ceiling*height;
    ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(cssWidth-4,y);ctx.stroke();
    ctx.fillText(String(i*step),left-5,y+4);
  }
  ctx.textAlign='left';ctx.fillStyle='#856d7a';ctx.font='10px system-ui';
  ctx.fillText('mL',4,top-12);
  ctx.textAlign='center';
  const usable=cssWidth-left-5;
  rows.forEach((r,i)=>{
    const mid=left+(i+0.5)*usable/rows.length;
    const ml=value(r),barWidth=Math.min(29,usable/rows.length*.65);
    const barHeight=ml/ceiling*height;
    const estimatedHeight=estimated(r)/ceiling*height;
    ctx.fillStyle='#634d58';ctx.font='bold 10px system-ui';
    ctx.fillText('모 '+(Number(r.breast)||0)+'회',mid,17);
    ctx.fillStyle='#77a6d5';
    if(barHeight>0)ctx.fillRect(mid-barWidth/2,bottom-barHeight,barWidth,barHeight);
    // Pale gold is a visual 25mL/hour-from-previous-direct-breast-or-pump estimate, never saved.
    if(estimatedHeight>0){ctx.fillStyle='#f5d99b';ctx.fillRect(mid-barWidth/2,bottom-barHeight-estimatedHeight,barWidth,estimatedHeight);
      ctx.strokeStyle='#b58a49';ctx.strokeRect(mid-barWidth/2+0.5,bottom-barHeight-estimatedHeight+0.5,barWidth-1,Math.max(0,estimatedHeight-1));}
    ctx.font='bold 10px system-ui';ctx.fillStyle='#445e81';
    const mlText=ml+'mL';
    ctx.fillText(ctx.measureText(mlText).width>usable/rows.length-2?String(ml):mlText,mid,Math.max(top-3,bottom-barHeight-estimatedHeight-7));
    ctx.font='11px system-ui';ctx.fillStyle='#8b7381';
    ctx.fillText(String(r.date.getDate()),mid,bottom+17);
  });
}
function renderStatistics(){
  if(activeTab!=='stats')return;
  const rows=dayRows(statsDays),sum=rows.reduce((s,r)=>{
    for(const k of ['feeds','measured','breast','pumped','formula','poop','pee','diapers','pumpMl','pumpCount'])s[k]+=r[k];return s;
  },{feeds:0,measured:0,breast:0,pumped:0,formula:0,poop:0,pee:0,diapers:0,pumpMl:0,pumpCount:0});
  $('period-breast').textContent=sum.breast+'회';
  $('period-milk').textContent=sum.pumped+' / '+sum.formula;
  $('period-total').textContent=sum.measured+'mL';
  $('period-diapers').textContent=sum.diapers+'개';
  $('period-extra').textContent='수유 '+sum.feeds+'회 · 유축 시작 '+sum.pumpCount+'회 · 유축량 '+sum.pumpMl+'mL · 대변 '+sum.poop+'회 · 소변 '+sum.pee+'회 · 하루 평균 기저귀 '+(sum.diapers/statsDays).toFixed(1)+'개';
  const tbody=$('statsDailyRows');tbody.replaceChildren();
  for(const d of [...rows].reverse()){
    const tr=document.createElement('tr');
    const cells=[`${d.date.getMonth()+1}/${d.date.getDate()}`,d.breast+'회',d.pumpMl,d.pumped,d.formula,d.poop,d.pee,d.diapers];
    for(const val of cells){const td=document.createElement('td');td.textContent=String(val);tr.append(td);}tbody.append(tr);
  }
  const insights=calculateStatsInsights(rows,records);
  renderInsightCards(insights,rows);
  drawBars('milkChart',rows,'milk');drawPumpedFeedingChart('pumpChart',rows);drawBars('formulaChart',rows,'formula');
  drawInsightChart('pumpOutputChart',rows,'pumpMl');
  drawInsightChart('feedSessionsChart',rows,'feeds');
  drawInsightChart('breastSessionsChart',rows,'breast');
  drawInsightChart('diaperDetailsChart',rows,'diaperBreakdown');
  drawTimePattern('timePatternChart',insights.timeBuckets);
}
// Statistics use only existing family records: no extra reads or writes.
// One 60-minute anchored feeding session counts once, including for night patterns.
function calculateStatsInsights(rows,source){
  const start=rows[0]?.date.getTime()??Date.now();
  const end=new Date(rows.at(-1)?.date.getFullYear()??2026,rows.at(-1)?.date.getMonth()??0,(rows.at(-1)?.date.getDate()??1)+1).getTime();
  const valid=source.filter(r=>{const d=r.at?.toDate?.();return d instanceof Date&&Number.isFinite(d.getTime())&&d.getTime()>=start&&d.getTime()<end&&d.getTime()<=Date.now()+300000;});
  const sessions=groupFeedSessions(source).filter(s=>s.startedAt>=start&&s.startedAt<end);
  const gaps=[];const buckets=[0,0,0,0];let night=0;
  for(let i=0;i<sessions.length;i++){
    const hour=new Date(sessions[i].startedAt).getHours();
    buckets[Math.floor(hour/6)]++;
    if(hour>=22||hour<6)night++;
    if(i>0){const minutes=(sessions[i].startedAt-sessions[i-1].startedAt)/60000;
      if(minutes>0)gaps.push(minutes);}
  }
  const totals=rows.reduce((a,r)=>{for(const k of ['feeds','measured','breast','breastUnmeasured','breastMl','pumped','formula','poop','pee','diapers','pumpMl','pumpCount'])a[k]+=(Number(r[k])||0);return a;},
    {feeds:0,measured:0,breast:0,breastUnmeasured:0,breastMl:0,pumped:0,formula:0,poop:0,pee:0,diapers:0,pumpMl:0,pumpCount:0});
  const both=valid.filter(r=>r.kind==='both').length;
  const knownPumpCount=valid.filter(r=>r.kind==='pump'&&Number(r.ml)>0).length;
  const complete=rows.slice(-7,-1); // Six FULL days; avoids comparing part of today to full days.
  const first3=complete.slice(0,3),last3=complete.slice(3,6);
  const avg=(rs,key)=>rs.reduce((acc,r)=>acc+(Number(r[key])||0),0)/(rs.length||1);
  return {totals,dayCount:rows.length,timeBuckets:buckets,night,gaps,averageGap:gaps.length?gaps.reduce((a,b)=>a+b,0)/gaps.length:null,
    maxGap:gaps.length?Math.max(...gaps):null,both,knownPumpCount,
    recent:{milk:avg(last3,'measured'),beforeMilk:avg(first3,'measured'),formula:avg(last3,'formula'),beforeFormula:avg(first3,'formula'),feeds:avg(last3,'feeds'),beforeFeeds:avg(first3,'feeds'),valid:complete.length===6}};
}
function formatGap(minutes){if(minutes===null||!Number.isFinite(minutes))return '기록 부족';const n=Math.round(minutes);return Math.floor(n/60)+'시간 '+String(n%60).padStart(2,'0')+'분';}
function renderInsightCards(data,rows){
  const {totals:t,dayCount:n,recent:r}=data;const f=(x,unit='')=>Math.round(x).toLocaleString('ko-KR')+unit;
  const cards=[
    ['하루 평균 실측 수유량',f(t.measured/n,'mL'),'직접 모유 미측정량 제외'],
    ['하루 평균 수유 회차',(t.feeds/n).toFixed(1)+'회','1시간 내 기록은 1회차'],
    ['수유 1회차당 실측량',t.feeds?f(t.measured/t.feeds,'mL'):'기록 없음','직접 모유 미측정량 제외'],
    ['평균 수유 간격',formatGap(data.averageGap),'기록된 수유 회차 시작 기준'],
    ['가장 긴 수유 간격',formatGap(data.maxGap),'기간 내 연속 수유 회차 간격'],
    ['야간 수유 회차',t.feeds?data.night+'회':'기록 없음','오후 10시~오전 6시 시작'],
    ['하루 평균 유축수유량',f(t.pumped/n,'mL'),'아기에게 먹인 유축 모유'],
    ['하루 평균 분유량',f(t.formula/n,'mL'),'실측 분유량'],
    ['직접 모유수유',t.breast+'회','양 미측정 회차 '+t.breastUnmeasured+'회'],
    ['수유량 구성','유축 '+(t.measured?Math.round(t.pumped/t.measured*100):0)+'% · 분유 '+(t.measured?Math.round(t.formula/t.measured*100):0)+'%','실측 전체 대비, 직접 모유 측정량도 포함'],
    ['직접 유축한 양',f(t.pumpMl,'mL'),'유축 시작 '+t.pumpCount+'회'],
    ['1회 평균 유축량',data.knownPumpCount?f(t.pumpMl/data.knownPumpCount,'mL'):'기록 없음','양이 입력된 유축 기록만 평균'],
    ['하루 평균 기저귀',(t.diapers/n).toFixed(1)+'개','소+대변은 기저귀 1개'],
    ['소변 / 대변',t.pee+'회 / '+t.poop+'회','같이 기록한 경우 '+data.both+'회'],
    ['최근 3일 평균 실측 수유',r.valid?f(r.milk,'mL'):'기록 부족',r.valid?'이전 3일 대비 '+changeText(r.milk,r.beforeMilk):'오늘 제외, 완료된 6일 필요'],
    ['최근 3일 평균 분유량',r.valid?f(r.formula,'mL'):'기록 부족',r.valid?'이전 3일 대비 '+changeText(r.formula,r.beforeFormula):'오늘 제외, 완료된 6일 필요'],
    ['최근 3일 평균 수유 회차',r.valid?r.feeds.toFixed(1)+'회':'기록 부족',r.valid?'이전 3일 대비 '+(r.feeds-r.beforeFeeds>=0?'+':'')+(r.feeds-r.beforeFeeds).toFixed(1)+'회':'오늘 제외, 완료된 6일 필요']
  ];
  const box=$('insightsGrid');box.replaceChildren();
  for(const [label,value,note] of cards){
    const item=document.createElement('div');item.className='insight-tile';
    const heading=document.createElement('span');heading.textContent=label;
    const amount=document.createElement('b');amount.textContent=value;
    const detail=document.createElement('small');detail.textContent=note;
    item.append(heading,amount,detail);box.append(item);
  }
  $('statisticsDisclosure').textContent=`최근 ${n}일 기록을 기준으로 계산 · 모유 미측정 수유는 실제 mL 합계에 포함하지 않음 · 데이터 부족 시 간격은 표시하지 않음`;
}
function changeText(now,before){if(before===0)return now===0?'변화 없음':'이전 0mL (비율 계산 안 함)';const percent=(now-before)/before*100;return(percent>0?'+':'')+percent.toFixed(1)+'%';}
function drawInsightChart(id,rows,type){
  const canvas=$(id),parent=canvas.parentElement;
  const width=statsDays===7?Math.max(245,parent.clientWidth):Math.max(parent.clientWidth,rows.length*44+20);
  const height=212,ratio=Math.min(3,window.devicePixelRatio||1);
  canvas.style.width=width+'px';canvas.style.height=height+'px';canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
  const ctx=canvas.getContext('2d');if(!ctx)return;ctx.scale(ratio,ratio);
  const left=34,right=5,top=37,bottom=184,usable=width-left-right;
  const value=r=>type==='pumpMl'?r.pumpMl:type==='feeds'?r.feeds:type==='breast'?r.breast:r.diapers;
  const estimated=r=>type==='pumpMl'?Math.max(0,Number(r.breastEstimatedMl)||0):0;
  const max=Math.max(1,...rows.map(r=>value(r)+estimated(r)));
  const maxAxis=type==='pumpMl'?Math.max(100,Math.ceil(max/100)*100):Math.max(4,Math.ceil(max/4)*4);
  const parts=r=>type==='diaperBreakdown'?[[Math.max(0,r.pee-(r.both||0)),'#75a6d0'],[Math.max(0,r.poop-(r.both||0)),'#d88692'],[r.both||0,'#a18aca']]:
    type==='pumpMl'?[[value(r),'#8bb4a4'],[estimated(r),'#f5d99b']]:[[value(r),type==='breast'?'#e0b965':'#7a9cce']];
  ctx.lineWidth=1;ctx.font='10px system-ui';ctx.textAlign='right';
  for(let j=0;j<=4;j++){const y=bottom-j*(bottom-top)/4;ctx.strokeStyle='#ebdfe1';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(width-right,y);ctx.stroke();ctx.fillStyle='#8b7381';ctx.fillText(String(Math.round(maxAxis*j/4)),left-5,y+3);}
  ctx.textAlign='center';rows.forEach((r,i)=>{
    const mid=left+(i+.5)*usable/rows.length,bw=Math.min(28,usable/rows.length*.65);let y=bottom;
    for(const [amount,color] of parts(r)){const h=Math.max(0,amount)/maxAxis*(bottom-top);ctx.fillStyle=color;if(h>0)ctx.fillRect(mid-bw/2,y-h,bw,h);y-=h;}
    if(type==='pumpMl'){ctx.fillStyle='#634d58';ctx.font='bold 10px system-ui';ctx.fillText('모 '+(Number(r.breast)||0)+'회',mid,16);}
    ctx.fillStyle='#445e81';ctx.font='bold 10px system-ui';const val=Math.max(0,value(r));
    const text=type==='pumpMl'?val+'mL':String(val);ctx.fillText(ctx.measureText(text).width>usable/rows.length-2?String(val):text,mid,Math.max(type==='pumpMl'?35:13,y-6));
    ctx.fillStyle='#8b7381';ctx.font='11px system-ui';ctx.fillText(String(r.date.getDate()),mid,bottom+19);
  });
}
function drawTimePattern(id,buckets){
  const canvas=$(id),parent=canvas.parentElement;const width=Math.max(245,parent.clientWidth),height=198,ratio=Math.min(3,window.devicePixelRatio||1);
  canvas.style.width=width+'px';canvas.style.height=height+'px';canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
  const ctx=canvas.getContext('2d');if(!ctx)return;ctx.scale(ratio,ratio);
  const max=Math.max(1,...buckets),left=25,right=7,top=22,bottom=156,usable=width-left-right;
  const names=['00~06','06~12','12~18','18~24'];ctx.textAlign='center';
  buckets.forEach((v,i)=>{const mid=left+(i+.5)*usable/4,w=Math.min(49,usable/4*.61),h=v/max*(bottom-top);
    ctx.fillStyle=['#8c9fd2','#e7c981','#d88692','#8ca5bb'][i];if(h)ctx.fillRect(mid-w/2,bottom-h,w,h);
    ctx.fillStyle='#634d58';ctx.font='bold 12px system-ui';ctx.fillText(v+'회',mid,Math.max(15,bottom-h-7));
    ctx.font='11px system-ui';ctx.fillStyle='#816f78';ctx.fillText(names[i],mid,bottom+18);
  });
}
// Family tools data is stored in separate Firestore documents (not a shared JSON blob),
// so unrelated edits from two family members do not overwrite each other.
const toolCollections={entries:'toolEntries',schedules:'toolSchedules',checks:'toolChecks',stocks:'toolStocks',meta:'toolMeta'};
let toolOff=[],toolCache={},toolSyncActive=false;
const toolFrame=()=>document.getElementById('toolsFrame');
function toolNotify(message){
  toolFrame()?.contentWindow?.postMessage({source:'agilog-tools-cloud',message},location.origin);
}
function stopToolSync(){for(const stop of toolOff)stop();toolOff=[];toolSyncActive=false;}
function startToolSync(){
  if(toolSyncActive||!user||!family||activeTab!=='tools')return;
  toolSyncActive=true;
  for(const [category,path] of Object.entries(toolCollections)){
    const off=onSnapshot(collection(db,'families',family,path),snap=>{
      const items=snap.docs.map(d=>({id:d.id,...d.data()}));
      toolCache[category]={type:'snapshot',category,items};toolNotify(toolCache[category]);
    },err=>toolNotify({type:'error',message:'동기화 실패 ('+category+'): '+err.message}));
    toolOff.push(off);
  }
}
async function toolWrite(op){
  const category=op?.category,action=op?.action,id=op?.id;
  if(!toolCollections[category]||!['upsert','delete'].includes(action)||typeof id!=='string'||
      !/^[A-Za-z0-9_.%\-]{1,180}$/.test(id))return;
  const key=category+'|'+id,seq=op.seq;
  try{
    if(!family||!user)throw Error('가족 연결을 확인하세요.');
    const target=doc(db,'families',family,toolCollections[category],id);
    if(action==='delete')await deleteDoc(target);
    else await setDoc(target,op.value);
    toolFrame()?.contentWindow?.postMessage({source:'agilog-tools-ack',message:{ok:true,key,seq}},location.origin);
  }catch(err){toolFrame()?.contentWindow?.postMessage({source:'agilog-tools-ack',message:{ok:false,key,seq,message:err.message}},location.origin);}
}
window.addEventListener('message',e=>{
  if(e.origin!==location.origin||e.source!==toolFrame()?.contentWindow)return;
  if(e.data?.source==='agilog-tools-write')toolWrite(e.data.operation);
  if(e.data?.source==='agilog-tools-ready'){
    for(const msg of Object.values(toolCache))toolNotify(msg);
  }
});
toolFrame().addEventListener('load',()=>{for(const msg of Object.values(toolCache))toolNotify(msg);});
function selectTab(tab){
  activeTab=tab;
  show('recordTab',tab==='record');show('statsTab',tab==='stats');show('toolsTab',tab==='tools');
  for(const t of ['record','stats','tools']){
    const b=$(t+'TabButton');b.classList.toggle('active',t===tab);b.setAttribute('aria-selected',String(t===tab));
  }
  if(tab==='tools')startToolSync();else stopToolSync();
  if(tab==='stats')requestAnimationFrame(renderStatistics);
  if(tab==='tools' && !$('toolsFrame').src){$('toolsFrame').src='parenting-tools.html';}
}
function setStatDays(days){statsDays=days;for(const d of [7,30])$('stats'+d).classList.toggle('selected',d===days);renderStatistics();}
function localInputValue(date){
  const d=new Date(date.getTime()-date.getTimezoneOffset()*60000);
  return d.toISOString().slice(0,16);
}
function editError(message){$('editError').textContent=message;$('editError').classList.remove('hidden');}
function clearEditError(){$('editError').textContent='';$('editError').classList.add('hidden');}
function editVisibility(){const k=$('editKind').value;show('editFeed',k==='feed');show('editPump',k==='pump');show('editDiaper',!['feed','pump'].includes(k));}
function fillParts(prefix,p){
  $(prefix+'BreastMl').value=p.breastMl;
  $(prefix+'PumpedMl').value=p.pumpedMl;
  $(prefix+'FormulaMl').value=p.formulaMl;
  $(prefix+'BreastUnknown').checked=p.breastUnmeasured;
}
function readParts(prefix){
  const get=k=>{const raw=$(prefix+k).value.trim();const n=Number(raw);if(!raw||!Number.isInteger(n)||n<0||n>1000||n%5!==0)throw Error('모유·유축·분유는 각각 0~1000mL, 5mL 단위로 입력하세요.');return n;};
  const p={breastMl:get('BreastMl'),pumpedMl:get('PumpedMl'),formulaMl:get('FormulaMl'),breastUnmeasured:$(prefix+'BreastUnknown').checked};
  const total=p.breastMl+p.pumpedMl+p.formulaMl;
  if((total===0&&!p.breastUnmeasured)||total>1000)throw Error('수유량 합계는 1~1000mL 범위여야 해요. 직접 모유 수유 양 미측정만 기록할 수도 있어요.');
  return p;
}
function feedData(p){const total=p.breastMl+p.pumpedMl+p.formulaMl;
  const types=[p.breastMl>0||p.breastUnmeasured?'breast':null,p.pumpedMl>0?'pumped':null,p.formulaMl>0?'formula':null].filter(Boolean);
  return {feedType:types.length>1?'mixed':types[0],ml:total,size:'',feedParts:p};
}
function openEdit(r){
  clearError();clearEditError();editingId=r.id;
  $('editKind').value=['feed','pee','poop','both','pump'].includes(r.kind)?r.kind:'feed';
  $('editAt').value=localInputValue(r.at?.toDate?.()||new Date());
  fillParts('edit',r.kind==='feed'?partsFor(r):{breastMl:0,pumpedMl:0,formulaMl:defaultFormulaMl(),breastUnmeasured:false});
  $('editSize').value=['small','medium','large'].includes(r.size)?r.size:'medium';
  $('editPumpMl').value=r.kind==='pump'?String(Math.max(0,Number(r.ml)||0)):'0';
  editVisibility();$('editDialog').showModal();
}
async function saveEdit(evt){
  evt.preventDefault();clearError();clearEditError();if(!editingId)return;
  const date=new Date($('editAt').value);
  if(!Number.isFinite(date.getTime())||date.getTime()>Date.now()+300000||date.getFullYear()<2020){editError('기록 시간은 2020년 이후부터 현재까지 입력할 수 있어요.');return;}
  const k=$('editKind').value;
  const data={kind:k,at:Timestamp.fromDate(date),legacy:false};
  try{
    if(k==='feed')Object.assign(data,feedData(readParts('edit')));
    else if(k==='pump'){const raw=$('editPumpMl').value.trim(),ml=Number(raw);
      if(!/^\d+$/.test(raw)||!Number.isInteger(ml)||ml<0||ml>1000||ml%5!==0)throw Error('유축량은 0~1000mL, 5mL 단위로 입력하세요.');
      Object.assign(data,{feedType:'',ml,size:'',feedParts:null});
    }else Object.assign(data,{feedType:'',ml:0,size:$('editSize').value,feedParts:null});
  }catch(e){editError(e.message);return;}
  // Firestore rules accept feedParts only on feeds; updateDoc can delete the previous feedParts on diaper edits.
  if(k!=='feed')data.feedParts=deleteField();
  const save=$('saveEdit');save.disabled=true;
  try{await updateDoc(doc(db,'families',family,'events',editingId),data);
    $('editDialog').close();editingId=null;$('status').textContent='기록 수정 완료';
  }catch(e){editError('수정할 수 없습니다: '+e.message);}finally{save.disabled=false;}
}
function option(text,fn){const button=document.createElement('button');button.textContent=text;button.onclick=fn;return button;}
function stepTitle(text){const el=document.createElement('h3');el.textContent=text;return el;}
function grid(container,values,fn,cls='grid'){const div=document.createElement('div');div.className=cls;for(const [label,value] of values)div.append(option(label,()=>fn(value)));container.append(div);}
function picker(k){kind=k;feedType='formula';show('picker',true);$('pickerTitle').textContent=(icons[k]||'')+' '+labels[k];renderPicker();$('picker').scrollIntoView({behavior:'smooth',block:'nearest'});}
function renderPicker(){const el=$('pickerStep');el.replaceChildren();
  if(kind==='diaper'){el.append(stepTitle('기저귀 종류 선택'));grid(el,[['💧 소변','pee'],['💩 대변','poop'],['💧💩 소+대변','both']],k=>{kind=k;renderPicker();});return;}
  if(kind==='pump'){renderPumpPicker(el);return;}
  if(kind!=='feed'){
    el.append(stepTitle('양을 선택하면 바로 저장돼요'));
    grid(el,[['소 · 적음','small'],['중 · 보통','medium'],['대 · 많음','large']],size=>save(kind,'',0,size));return;
  }
  el.append(stepTitle('수유 종류 선택 · 5mL 단위'));
  const types=document.createElement('div');types.className='grid4';
  for(const [label,value] of [['모유','breast'],['유축','pumped'],['분유','formula'],['혼합 (유축+분유)','mixed']]){
    const btn=option(label,()=>{feedType=value;renderPicker();});
    if(feedType===value)btn.classList.add('selected');types.append(btn);
  }
  el.append(types);
  const rows=feedType==='mixed'?[['유축','PumpedMl',defaultPumpedMl()],['분유','FormulaMl',defaultFormulaMl()]]:
    feedType==='breast'?[['모유','BreastMl',0]]:
    feedType==='pumped'?[['유축','PumpedMl',defaultPumpedMl()]]:[['분유','FormulaMl',defaultFormulaMl()]];
  for(const [label,id,value] of rows){
    const row=document.createElement('div');row.className='feed-line';
    const name=document.createElement('label');name.textContent=label+' (mL)';name.htmlFor='pick'+id;
    const input=document.createElement('input');input.type='number';input.min='0';input.max='1000';input.step='5';input.value=String(value);input.id='pick'+id;
    row.append(name,input);el.append(row);
  }
  if(feedType==='breast'){
    const check=document.createElement('label');check.className='feed-check';
    const input=document.createElement('input');input.type='checkbox';input.id='pickBreastUnknown';input.checked=true;
    check.append(input,document.createTextNode('직접 모유수유 · 양 미측정'));el.append(check);
  }
  const hint=document.createElement('p');hint.className='feed-footnote';
  hint.textContent=feedType==='mixed'?'혼합 수유는 유축 + 분유만 기록하며 두 종류 모두 5mL 이상 입력해야 합니다.':
    '모유는 혼합에 포함하지 않고 별도 수유로 기록합니다.';
  el.append(hint);
  // Final step before saving: select now or a past time, in five-minute increments.
  let offsetMinutes=0;
  const timeTitle=stepTitle('마지막 단계 · 수유 시간');el.append(timeTitle);
  const timeDisplay=document.createElement('p');timeDisplay.className='feed-footnote';el.append(timeDisplay);
  const timeControls=document.createElement('div');timeControls.className='grid4';el.append(timeControls);
  const sum=document.createElement('span');sum.className='time-offset-summary';sum.setAttribute('aria-live','polite');
  const redrawTime=()=>{const d=new Date(Date.now()-offsetMinutes*60000);
    timeDisplay.textContent='선택 시각: '+d.toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})
      +(offsetMinutes?' ('+offsetMinutes+'분 전)':' (현재)');
    sum.textContent='누적 '+offsetMinutes+'분 전';};
  timeControls.append(option('현재',()=>{offsetMinutes=0;redrawTime();}));
  timeControls.append(option('이전 시간',()=>{if(offsetMinutes===0)offsetMinutes=5;redrawTime();}));
  timeControls.append(option('−5분',()=>{offsetMinutes=Math.min(1440,offsetMinutes+5);redrawTime();}));
  timeControls.append(sum);
  redrawTime();
  const saveBtn=option('🍼 선택한 시간으로 수유 저장',async()=>{
    try{
      const get=id=>{const el=$(id);if(!el)return 0;const n=Number(el.value);
        if(!el.value.trim()||!Number.isInteger(n)||n<0||n>1000||n%5!==0)throw Error('5mL 단위로 입력해 주세요.');return n;};
      const p={breastMl:feedType==='breast'?get('pickBreastMl'):0,
        pumpedMl:['pumped','mixed'].includes(feedType)?get('pickPumpedMl'):0,
        formulaMl:['formula','mixed'].includes(feedType)?get('pickFormulaMl'):0,
        breastUnmeasured:feedType==='breast'&&$('pickBreastUnknown').checked};
      if(p.breastUnmeasured)p.breastMl=0;
      const total=p.breastMl+p.pumpedMl+p.formulaMl;
      if(total>1000||(total===0&&!p.breastUnmeasured))throw Error('수유량은 5mL 이상 입력해 주세요.');
      if(feedType==='mixed'&&(p.pumpedMl<5||p.formulaMl<5))throw Error('혼합은 유축과 분유를 각각 5mL 이상 입력해 주세요.');
      const data=feedData(p);saveBtn.disabled=true;
      await addDoc(collection(db,'families',family,'events'),{kind:'feed',...data,legacy:false,...meta(),
        at:offsetMinutes===0?serverTimestamp():Timestamp.fromMillis(Date.now()-offsetMinutes*60000)});
      show('picker',false);$('status').textContent='수유 기록 저장됨';
    }catch(e){error('기록 저장 실패: '+e.message);}finally{saveBtn.disabled=false;}
  });saveBtn.className='primary';saveBtn.style.width='100%';el.append(saveBtn);
}
function renderPumpPicker(el){
  el.append(stepTitle('🥛 유축 시작 시각 · 양은 나중에 수정 가능'));
  const time=document.createElement('input');time.type='datetime-local';time.value=localInputValue(new Date());time.max=localInputValue(new Date(Date.now()+300000));
  time.className='field';time.setAttribute('aria-label','유축 시작 날짜·시간');el.append(time);
  const nowBtn=option('현재 시간',()=>{time.value=localInputValue(new Date());});el.append(nowBtn);
  const saveBtn=option('🥛 유축 시작 저장 (양 미입력)',async()=>{
    const d=new Date(time.value);if(!Number.isFinite(d.getTime())||d.getFullYear()<2020||d.getTime()>Date.now()+300000){error('유축 시작 시간은 2020년 이후부터 현재까지 입력해 주세요.');return;}
    clearError();saveBtn.disabled=true;try{await addDoc(collection(db,'families',family,'events'),{kind:'pump',feedType:'',ml:0,size:'',legacy:false,...meta(),at:Timestamp.fromDate(d)});
    show('picker',false);$('status').textContent='유축 시작 저장됨 · 양은 기록에서 수정하세요';
    }catch(e){error('유축 기록 저장 실패: '+e.message);}finally{saveBtn.disabled=false;}
  });saveBtn.className='primary';saveBtn.style.width='100%';el.append(saveBtn);
}
async function save(k,t,ml,size){clearError();const e={kind:k,feedType:t,ml,size,legacy:false,...meta(),at:serverTimestamp()};
  show('picker',false);try{await addDoc(collection(db,'families',family,'events'),e);$('status').textContent='저장됨 · '+(labels[k]||k);}catch(ex){show('picker',true);error('기록 저장에 실패했습니다: '+ex.message);}}
async function init(){
  if(!firebaseConfig.apiKey||firebaseConfig.apiKey.startsWith('REPLACE')||!firebaseConfig.projectId||firebaseConfig.projectId.startsWith('REPLACE')){
    $('status').textContent='아직 Firebase 연결 전입니다.';error('관리자가 Firebase 설정을 연결한 뒤 GitHub Pages로 배포해야 가족 공유가 작동합니다.');return;
  }
  try{
    const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
    onAuthStateChanged(auth,async(u)=>{
      if(!u){try{await signInAnonymously(auth);}catch(e){error('로그인 실패: '+e.message);}return;}
      user=u;$('status').textContent='연결 준비 완료';
      const old=localStorage.getItem('agilog-family-code'),oldName=localStorage.getItem('agilog-family-name');
      if(old&&oldName){
        try{const m=await getDoc(doc(db,'families',old,'members',u.uid));if(m.exists()){await enter(old,oldName);return;}}catch(e){error('기존 가족 확인 실패: '+e.message);}
      }
      show('connect',true);
    });
  }catch(e){error('Firebase 연결 오류: '+e.message);}
}
setInterval(()=>{if(records.length)refreshSummary();},60000);
$('openSettings').onclick=openFeedSettings;
$('decreasePumpedDefault').onclick=()=>adjustDefault('pumped',-5);
$('increasePumpedDefault').onclick=()=>adjustDefault('pumped',5);
$('decreaseFormulaDefault').onclick=()=>adjustDefault('formula',-5);
$('increaseFormulaDefault').onclick=()=>adjustDefault('formula',5);
$('saveFeedDefault').onclick=saveFeedSettings;
$('cancelFeedDefault').onclick=()=>$('settingsDialog').close();
$('olderRecordsToggle').onclick=()=>{olderRecordsExpanded=!olderRecordsExpanded;olderRecordsVisible=100;renderRecords();};
$('olderRecordsMore').onclick=()=>{olderRecordsVisible+=100;renderRecords();};
$('downloadFamilyCsv').onclick=downloadAllFamilyCsv;
$('recordTabButton').onclick=()=>selectTab('record');$('statsTabButton').onclick=()=>selectTab('stats');$('toolsTabButton').onclick=()=>selectTab('tools');
window.addEventListener('message', e=>{if(e.origin===location.origin&&e.data?.source==='agilog-tools'){const h=Math.max(500,Math.min(16000,Number(e.data.height)||1200));$('toolsFrame').style.height=(h+15)+'px';}});
$('stats7').onclick=()=>setStatDays(7);$('stats30').onclick=()=>setStatDays(30);
window.addEventListener('resize',()=>{if(activeTab==='stats')renderStatistics();});
$('create').onclick=createFamily;$('join').onclick=joinFamily;
document.querySelectorAll('[data-kind]').forEach(b=>b.onclick=()=>picker(b.dataset.kind));
$('closePicker').onclick=()=>show('picker',false);
$('editKind').onchange=editVisibility;
$('editForm').onsubmit=saveEdit;
$('cancelEdit').onclick=()=>{$('editDialog').close();editingId=null;};
$('share').onclick=async()=>{const code=$('familyCode').textContent;const text='아기로그 가족 초대 코드: '+code+'\n같은 가족 공유 앱에 코드를 입력해 주세요.';
  try{if(navigator.share)await navigator.share({text});else{await navigator.clipboard.writeText(text);$('status').textContent='초대 코드 복사됨';}}
  catch(e){if(e.name!=='AbortError')error('공유할 수 없습니다. 코드를 길게 눌러 복사하세요.');}
};
if('serviceWorker' in navigator)navigator.serviceWorker.register('./service-worker.js?v=237',{updateViaCache:'none'}).catch(()=>{});
init();
