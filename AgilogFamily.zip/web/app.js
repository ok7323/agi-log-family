import {initializeApp} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js';
import {getAuth,onAuthStateChanged,signInAnonymously} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js';
import {getFirestore,doc,setDoc,getDoc,addDoc,collection,query,orderBy,onSnapshot,deleteDoc,updateDoc,deleteField,Timestamp,serverTimestamp} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js';
import {firebaseConfig} from './firebase-config.js';
const $=id=>document.getElementById(id);
let auth,db,user=null,family='',who='',unsubscribe=null,records=[],kind='',feedType='',editingId=null;
let activeTab='record',statsDays=7;
const labels={feed:'수유',poop:'대변',pee:'소변',both:'소+대변',breast:'모유',pumped:'유축',formula:'분유',mixed:'혼합',small:'소',medium:'중',large:'대'};
const icons={feed:'🍼',poop:'💩',pee:'💧',both:'💧💩'};
const CODE='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function error(msg){$('error').textContent=String(msg);$('error').classList.remove('hidden');}
function clearError(){$('error').classList.add('hidden');$('error').textContent='';}
function show(id,flag){$(id).classList.toggle('hidden',!flag);}
function newCode(){const bytes=crypto.getRandomValues(new Uint8Array(20));return Array.from(bytes,v=>CODE[v%CODE.length]).join('');}
function name(){const v=$('name').value.trim();if(v.length<1||v.length>40)throw Error('이름을 1~40자로 입력하세요.');return v;}
function meta(){return{createdBy:user.uid,who,source:'web'};}
async function createFamily(){clearError();try{
  who=name();const code=newCode();
  // Failed member creation is recoverable: paste the new code into the join form.
  await setDoc(doc(db,'families',code),{createdBy:user.uid,createdAt:serverTimestamp()});
  try{await setDoc(doc(db,'families',code,'members',user.uid),{name:who,joinedAt:serverTimestamp()});}
  catch(e){$('invite').value=code;throw Error('가족은 만들었지만 가입에 실패했어요. 화면에 표시된 코드를 보관하고 다시 가입해 주세요. '+e.message);}
  await enter(code,who);
}catch(e){error(e.message);}}
async function joinFamily(){clearError();try{
  who=name();const code=$('invite').value.toUpperCase().replace(/[\s-]/g,'');
  if(!/^[A-HJ-NP-Z2-9]{20}$/.test(code))throw Error('가족 코드는 영문/숫자 20자리입니다.');
  try{await setDoc(doc(db,'families',code,'members',user.uid),{name:who,joinedAt:serverTimestamp()});}
  catch(e){const existing=await getDoc(doc(db,'families',code,'members',user.uid)).catch(()=>null);
    if(!existing?.exists())throw Error('코드가 틀렸거나 권한이 없습니다. 다시 확인해 주세요. '+e.message);
  }
  await enter(code,who);
}catch(e){error(e.message);}}
async function enter(code,n){
  stopToolSync();toolCache={};family=code;who=n;
  localStorage.setItem('agilog-family-code',code);localStorage.setItem('agilog-family-name',n);
  $('familyCode').textContent=code;
  show('connect',false);show('app',true);show('status',false);
  if(unsubscribe){unsubscribe();unsubscribe=null;}
  const q=query(collection(db,'families',code,'events'),orderBy('at','desc')); // 전체 기록을 받아 오늘 총계와 마지막 시간을 정확하게 계산
  unsubscribe=onSnapshot(q,snap=>{records=snap.docs.map(d=>({id:d.id,...d.data()}));renderRecords();},e=>error('기록을 불러오지 못했어요: '+e.message));
}
function partsFor(r){
  if(r.feedParts && typeof r.feedParts==='object'){
    return {breastMl:Number(r.feedParts.breastMl)||0,pumpedMl:Number(r.feedParts.pumpedMl)||0,formulaMl:Number(r.feedParts.formulaMl)||0,breastUnmeasured:r.feedParts.breastUnmeasured===true};
  }
  const p={breastMl:0,pumpedMl:0,formulaMl:0,breastUnmeasured:r.feedType==='breast'&&r.ml===-1};
  if(['breast','pumped','formula'].includes(r.feedType)&&Number(r.ml)>0)p[r.feedType==='breast'?'breastMl':r.feedType==='pumped'?'pumpedMl':'formulaMl']=r.ml;
  return p;
}
function feedTotal(r){if(r.kind!=='feed'||r.legacy)return 0;const p=partsFor(r);return p.breastMl+p.pumpedMl+p.formulaMl;}
function feedUnknown(r){return r.kind==='feed'&&!r.legacy&&partsFor(r).breastUnmeasured;}
function elapsed(date){
  if(!date)return '기록 없음';
  const minutes=Math.max(0,Math.floor((Date.now()-date.getTime())/60000));
  return String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0');
}
// Latest and immediately previous feeding are selected by recorded time, not by the current day's boundary.
function feedingAmountText(r){
  if(!r)return '수유량 없음';
  if(r.legacy)return '수유량 정보 없음';
  const p=partsFor(r),amount=feedTotal(r);
  const components=[];
  if(p.breastMl>0)components.push('모유 '+p.breastMl);
  if(p.breastUnmeasured)components.push('모유 미측정');
  if(p.pumpedMl>0)components.push('유축 '+p.pumpedMl);
  if(p.formulaMl>0)components.push('분유 '+p.formulaMl);
  if(amount===0&&p.breastUnmeasured)return '모유 미측정';
  if(amount===0)return '수유량 정보 없음';
  return components.join(' + ')+' · 합계 '+amount+'mL';
}
// A feeding session starts at its first recorded feed and lasts 60 minutes.
// Three feeds at 09:00, 09:25 and 09:55 count as ONE session; 10:00 starts another.
// Individual records and amounts remain unchanged.
function groupFeedSessions(items){
  const now=Date.now();
  const feeds=items.filter(r=>r.kind==='feed'&&r.at?.toDate?.() instanceof Date&&r.at.toDate().getTime()<=now+300000)
    .sort((a,b)=>a.at.toDate().getTime()-b.at.toDate().getTime());
  const sessions=[];
  for(const r of feeds){
    const timestamp=r.at.toDate().getTime();
    const p=partsFor(r),breast=!r.legacy&&(p.breastMl>0||p.breastUnmeasured);
    let last=sessions[sessions.length-1];
    if(!last||timestamp-last.startedAt>=3600000){
      last={startedAt:timestamp,breast};sessions.push(last);
    }else if(breast){last.breast=true;}
  }
  return sessions;
}
function daySummary(items, allSessions=null, start=null, end=null){
  const feeds=items.filter(r=>r.kind==='feed');
  const measured=feeds.reduce((sum,r)=>sum+feedTotal(r),0);
  const sessions=allSessions&&start!==null&&end!==null
    ?allSessions.filter(session=>session.startedAt>=start&&session.startedAt<end)
    :groupFeedSessions(items);
  const breast=sessions.filter(session=>session.breast).length;
  const pumped=feeds.reduce((sum,r)=>sum+(r.legacy?0:partsFor(r).pumpedMl),0);
  const formula=feeds.reduce((sum,r)=>sum+(r.legacy?0:partsFor(r).formulaMl),0);
  const poop=items.filter(r=>r.kind==='poop'||r.kind==='both').length;
  const pee=items.filter(r=>r.kind==='pee'||r.kind==='both').length;
  const diapers=items.filter(r=>['pee','poop','both'].includes(r.kind)).length;
  const breastMl=feeds.reduce((sum,r)=>sum+(r.legacy?0:partsFor(r).breastMl),0);
  return {feeds:sessions.length,measured,breast,breastMl,pumped,formula,poop,pee,diapers};
}
function refreshSummary(){
  const now=new Date(),todayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
  const yesterdayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1).getTime();
  const eligible=records.filter(r=>r.at?.toDate?.() instanceof Date&&r.at.toDate().getTime()<=Date.now()+300000);
  const sessions=groupFeedSessions(eligible);
  const today=daySummary(eligible.filter(r=>r.at.toDate().getTime()>=todayStart),sessions,todayStart,Infinity);
  const yesterday=daySummary(eligible.filter(r=>r.at.toDate().getTime()>=yesterdayStart&&r.at.toDate().getTime()<todayStart),sessions,yesterdayStart,todayStart);
  for(const [prefix,data] of [['today',today],['yesterday',yesterday]]){
    $(prefix+'-breast').textContent=data.breast+'회';
    $(prefix+'-pumped').textContent=data.pumped+'mL';
    $(prefix+'-formula').textContent=data.formula+'mL';
  }
  $('n-feed').textContent=today.feeds+'회';
  $('total-feed').textContent=today.measured+'mL';
  $('n-poop').textContent=today.poop+'회';$('n-pee').textContent=today.pee+'회';$('n-diapers').textContent=today.diapers+'개';
  $('yesterday-n-feed').textContent=yesterday.feeds+'회';
  $('yesterday-feed').textContent=yesterday.measured+'mL';
  $('yesterday-poop').textContent=yesterday.poop+'회';
  $('yesterday-pee').textContent=yesterday.pee+'회';$('yesterday-diapers').textContent=yesterday.diapers+'개';
  const feedEvents=eligible.filter(r=>r.kind==='feed')
    .sort((a,b)=>b.at.toDate().getTime()-a.at.toDate().getTime());
  const latest=feedEvents[0],previous=feedEvents[1];
  $('last-feed').textContent=elapsed(latest?.at?.toDate?.());
  $('last-feed-amount').textContent=feedingAmountText(latest);
  $('previous-feed').textContent=elapsed(previous?.at?.toDate?.());
  $('previous-feed-amount').textContent=feedingAmountText(previous);
  for(const k of ['poop','pee']){
    const r=eligible.find(e=>e.kind===k||e.kind==='both');
    $('last-'+k).textContent=elapsed(r?.at?.toDate?.());
  }
}
function formatTime(item){const value=item.at?.toDate?.()||new Date();return value.toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});}
function details(r){
  if(r.legacy)return '이전 기록 · 상세 정보 없음';
  if(r.kind==='feed'){
    const p=partsFor(r),items=[];
    if(p.breastMl)items.push('모유 '+p.breastMl+'mL');
    if(p.breastUnmeasured)items.push('모유 양 미측정');
    if(p.pumpedMl)items.push('유축 '+p.pumpedMl+'mL');
    if(p.formulaMl)items.push('분유 '+p.formulaMl+'mL');
    return (items.length?items.join(' + '):'수유')+' · 합계 '+feedTotal(r)+'mL'+(p.breastUnmeasured?' (미측정 제외)':'');
  }
  return '양 '+(labels[r.size]||'-');
}
function renderRecords(){
  refreshSummary();
  if(activeTab==='stats')renderStatistics();
  const container=$('records');container.replaceChildren();
  if(!records.length){container.textContent='첫 기록을 남겨보세요 🌱';return;}
  for(const r of records.slice(0,100)){const entry=document.createElement('div');entry.className='event';entry.tabIndex=0;entry.setAttribute('role','button');
    entry.onclick=e=>{if(!e.target.closest('button'))openEdit(r);};
    entry.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&e.target===entry){e.preventDefault();openEdit(r);}};
    const symbol=document.createElement('span');symbol.textContent=icons[r.kind]||'🍼';entry.append(symbol);
    const main=document.createElement('div'),name=document.createElement('b'),detail=document.createElement('small');
    name.textContent=(labels[r.kind]||'기록')+' · '+formatTime(r);detail.textContent=details(r)+' · '+(r.who||'가족');
    main.append(name,detail);entry.append(main);
    const edit=document.createElement('button');edit.className='edit';edit.textContent='수정';edit.onclick=()=>openEdit(r);entry.append(edit);
    if(r.createdBy===user?.uid){const btn=document.createElement('button');btn.textContent='삭제';btn.onclick=async()=>{
      if(!confirm('이 기록을 가족 모두의 기록에서 삭제할까요?'))return;
      try{await deleteDoc(doc(db,'families',family,'events',r.id));}catch(e){error(e.message);}
    };entry.append(btn);}
    container.append(entry);
  }
}
// Daily statistics use local calendar dates, so midnight and daylight-saving changes
// do not shift a feeding or a diaper event into the wrong day.
function dayRows(days){
  const now=new Date(),out=[],sessions=groupFeedSessions(records);
  for(let offset=days-1;offset>=0;offset--){
    const start=new Date(now.getFullYear(),now.getMonth(),now.getDate()-offset);
    const end=new Date(start.getFullYear(),start.getMonth(),start.getDate()+1);
    const one=records.filter(r=>{const d=r.at?.toDate?.();return d instanceof Date&&d>=start&&d<end&&d.getTime()<=Date.now()+300000;});
    out.push({date:start, ...daySummary(one,sessions,start.getTime(),end.getTime())});
  }
  return out;
}
function drawBars(id,rows,type){
  const canvas=$(id),scroll=canvas.parentElement;
  const per=statsDays===30?36:Math.max(39,Math.floor((scroll.clientWidth-26)/7));
  const cssWidth=Math.max(scroll.clientWidth,rows.length*per+18),cssHeight=205;
  canvas.style.width=cssWidth+'px';canvas.style.height=cssHeight+'px';
  const ratio=Math.min(window.devicePixelRatio||1,3);
  canvas.width=Math.round(cssWidth*ratio);canvas.height=Math.round(cssHeight*ratio);
  const ctx=canvas.getContext('2d');ctx.scale(ratio,ratio);
  const left=33,top=10,bottom=179,height=bottom-top;
  const val=r=>type==='milk'?r.breastMl+r.pumped+r.formula:r.diapers;
  const max=Math.max(1,...rows.map(val)),nice=Math.max(1,Math.ceil(max/4));
  const ceiling=nice*4;
  ctx.strokeStyle='#ebdfe1';ctx.fillStyle='#8b7381';ctx.lineWidth=1;
  ctx.font='10px system-ui';ctx.textAlign='right';
  for(let i=0;i<=4;i++){const v=i*nice,y=bottom-v/ceiling*height;
    ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(cssWidth-5,y);ctx.stroke();ctx.fillText(String(v),left-5,y+3);
  }
  ctx.textAlign='center';
  rows.forEach((r,i)=>{
    const mid=left+9+i*((cssWidth-left-7)/rows.length),barW=Math.min(27,(cssWidth-left-7)/rows.length*.67);
    let base=bottom;
    const segments=type==='milk'?[[r.formula,'#d88692'],[r.pumped,'#77a6d5'],[r.breastMl,'#eac276']]:[[r.diapers,'#7a9cce']];
    for(const [v,color] of segments){const h=v/ceiling*height;if(h>0){ctx.fillStyle=color;ctx.fillRect(mid-barW/2,base-h,barW,h);base-=h;}}
    ctx.fillStyle='#8b7381';ctx.font='10px system-ui';
    ctx.fillText(String(r.date.getDate()),mid,bottom+15);
    if(type==='diaper'&&r.diapers)ctx.fillText(String(r.diapers),mid,Math.max(12,base-4));
  });
}
function renderStatistics(){
  if(activeTab!=='stats')return;
  const rows=dayRows(statsDays),sum=rows.reduce((s,r)=>{
    for(const k of ['feeds','measured','breast','pumped','formula','poop','pee','diapers'])s[k]+=r[k];return s;
  },{feeds:0,measured:0,breast:0,pumped:0,formula:0,poop:0,pee:0,diapers:0});
  $('period-breast').textContent=sum.breast+'회';
  $('period-milk').textContent=sum.pumped+' / '+sum.formula;
  $('period-total').textContent=sum.measured+'mL';
  $('period-diapers').textContent=sum.diapers+'개';
  $('period-extra').textContent='수유 '+sum.feeds+'회 · 대변 '+sum.poop+'회 · 소변 '+sum.pee+'회 · 하루 평균 기저귀 '+(sum.diapers/statsDays).toFixed(1)+'개';
  const tbody=$('statsDailyRows');tbody.replaceChildren();
  for(const d of [...rows].reverse()){
    const tr=document.createElement('tr');
    const cells=[`${d.date.getMonth()+1}/${d.date.getDate()}`,d.breast+'회',d.pumped,d.formula,d.poop,d.pee,d.diapers];
    for(const val of cells){const td=document.createElement('td');td.textContent=String(val);tr.append(td);}tbody.append(tr);
  }
  drawBars('milkChart',rows,'milk');drawBars('diaperChart',rows,'diaper');
}
// Family tools data is stored in separate Firestore documents (not a shared JSON blob),
// so unrelated edits from two family members do not overwrite each other.
const toolCollections={entries:'toolEntries',schedules:'toolSchedules',checks:'toolChecks',stocks:'toolStocks',meta:'toolMeta'};
let toolOff=[],toolCache={},toolSyncActive=false;
const toolFrame=()=>document.getElementById('toolsFrame');
function toolNotify(message){
  toolFrame()?.contentWindow?.postMessage({source:'agilog-tools-cloud',message},location.origin);
}
function stopToolSync(){for(const stop of toolOff)stop();toolOff=[];toolSyncActive=false;}
function startToolSync(){
  if(toolSyncActive||!user||!family||activeTab!=='tools')return;
  toolSyncActive=true;
  for(const [category,path] of Object.entries(toolCollections)){
    const off=onSnapshot(collection(db,'families',family,path),snap=>{
      const items=snap.docs.map(d=>({id:d.id,...d.data()}));
      toolCache[category]={type:'snapshot',category,items};toolNotify(toolCache[category]);
    },err=>toolNotify({type:'error',message:'동기화 실패 ('+category+'): '+err.message}));
    toolOff.push(off);
  }
}
async function toolWrite(op){
  const category=op?.category,action=op?.action,id=op?.id;
  if(!toolCollections[category]||!['upsert','delete'].includes(action)||typeof id!=='string'||
      !/^[A-Za-z0-9_.%\-]{1,180}$/.test(id))return;
  const key=category+'|'+id,seq=op.seq;
  try{
    if(!family||!user)throw Error('가족 연결을 확인하세요.');
    const target=doc(db,'families',family,toolCollections[category],id);
    if(action==='delete')await deleteDoc(target);
    else await setDoc(target,op.value);
    toolFrame()?.contentWindow?.postMessage({source:'agilog-tools-ack',message:{ok:true,key,seq}},location.origin);
  }catch(err){toolFrame()?.contentWindow?.postMessage({source:'agilog-tools-ack',message:{ok:false,key,seq,message:err.message}},location.origin);}
}
window.addEventListener('message',e=>{
  if(e.origin!==location.origin||e.source!==toolFrame()?.contentWindow)return;
  if(e.data?.source==='agilog-tools-write')toolWrite(e.data.operation);
  if(e.data?.source==='agilog-tools-ready'){
    for(const msg of Object.values(toolCache))toolNotify(msg);
  }
});
toolFrame().addEventListener('load',()=>{for(const msg of Object.values(toolCache))toolNotify(msg);});
function selectTab(tab){
  activeTab=tab;
  show('recordTab',tab==='record');show('statsTab',tab==='stats');show('toolsTab',tab==='tools');
  for(const t of ['record','stats','tools']){
    const b=$(t+'TabButton');b.classList.toggle('active',t===tab);b.setAttribute('aria-selected',String(t===tab));
  }
  if(tab==='tools')startToolSync();else stopToolSync();
  if(tab==='stats')requestAnimationFrame(renderStatistics);
  if(tab==='tools' && !$('toolsFrame').src){$('toolsFrame').src='parenting-tools.html';}
}
function setStatDays(days){statsDays=days;for(const d of [7,30])$('stats'+d).classList.toggle('selected',d===days);renderStatistics();}
function localInputValue(date){
  const d=new Date(date.getTime()-date.getTimezoneOffset()*60000);
  return d.toISOString().slice(0,16);
}
function editError(message){$('editError').textContent=message;$('editError').classList.remove('hidden');}
function clearEditError(){$('editError').textContent='';$('editError').classList.add('hidden');}
function editVisibility(){const feed=$('editKind').value==='feed';show('editFeed',feed);show('editDiaper',!feed);}
function fillParts(prefix,p){
  $(prefix+'BreastMl').value=p.breastMl;
  $(prefix+'PumpedMl').value=p.pumpedMl;
  $(prefix+'FormulaMl').value=p.formulaMl;
  $(prefix+'BreastUnknown').checked=p.breastUnmeasured;
}
function readParts(prefix){
  const get=k=>{const raw=$(prefix+k).value.trim();const n=Number(raw);if(!raw||!Number.isInteger(n)||n<0||n>1000||n%5!==0)throw Error('모유·유축·분유는 각각 0~1000mL, 5mL 단위로 입력하세요.');return n;};
  const p={breastMl:get('BreastMl'),pumpedMl:get('PumpedMl'),formulaMl:get('FormulaMl'),breastUnmeasured:$(prefix+'BreastUnknown').checked};
  const total=p.breastMl+p.pumpedMl+p.formulaMl;
  if((total===0&&!p.breastUnmeasured)||total>1000)throw Error('수유량 합계는 1~1000mL 범위여야 해요. 직접 모유 수유 양 미측정만 기록할 수도 있어요.');
  return p;
}
function feedData(p){const total=p.breastMl+p.pumpedMl+p.formulaMl;
  const types=[p.breastMl>0||p.breastUnmeasured?'breast':null,p.pumpedMl>0?'pumped':null,p.formulaMl>0?'formula':null].filter(Boolean);
  return {feedType:types.length>1?'mixed':types[0],ml:total,size:'',feedParts:p};
}
function openEdit(r){
  clearError();clearEditError();editingId=r.id;
  $('editKind').value=['feed','pee','poop','both'].includes(r.kind)?r.kind:'feed';
  $('editAt').value=localInputValue(r.at?.toDate?.()||new Date());
  fillParts('edit',r.kind==='feed'?partsFor(r):{breastMl:0,pumpedMl:0,formulaMl:70,breastUnmeasured:false});
  $('editSize').value=['small','medium','large'].includes(r.size)?r.size:'medium';
  editVisibility();$('editDialog').showModal();
}
async function saveEdit(evt){
  evt.preventDefault();clearError();clearEditError();if(!editingId)return;
  const date=new Date($('editAt').value);
  if(!Number.isFinite(date.getTime())||date.getTime()>Date.now()+300000||date.getFullYear()<2020){editError('기록 시간은 2020년 이후부터 현재까지 입력할 수 있어요.');return;}
  const k=$('editKind').value;
  const data={kind:k,at:Timestamp.fromDate(date),legacy:false};
  try{
    if(k==='feed')Object.assign(data,feedData(readParts('edit')));
    else Object.assign(data,{feedType:'',ml:0,size:$('editSize').value,feedParts:null});
  }catch(e){editError(e.message);return;}
  // Firestore rules accept feedParts only on feeds; updateDoc can delete the previous feedParts on diaper edits.
  if(k!=='feed')data.feedParts=deleteField();
  const save=$('saveEdit');save.disabled=true;
  try{await updateDoc(doc(db,'families',family,'events',editingId),data);
    $('editDialog').close();editingId=null;$('status').textContent='기록 수정 완료';
  }catch(e){editError('수정할 수 없습니다: '+e.message);}finally{save.disabled=false;}
}
function option(text,fn){const button=document.createElement('button');button.textContent=text;button.onclick=fn;return button;}
function stepTitle(text){const el=document.createElement('h3');el.textContent=text;return el;}
function grid(container,values,fn,cls='grid'){const div=document.createElement('div');div.className=cls;for(const [label,value] of values)div.append(option(label,()=>fn(value)));container.append(div);}
function picker(k){kind=k;feedType='formula';show('picker',true);$('pickerTitle').textContent=(icons[k]||'')+' '+labels[k];renderPicker();$('picker').scrollIntoView({behavior:'smooth',block:'nearest'});}
function renderPicker(){const el=$('pickerStep');el.replaceChildren();
  if(kind!=='feed'){
    el.append(stepTitle('양을 선택하면 바로 저장돼요'));
    grid(el,[['소 · 적음','small'],['중 · 보통','medium'],['대 · 많음','large']],size=>save(kind,'',0,size));return;
  }
  el.append(stepTitle('수유 종류 선택 · 5mL 단위'));
  const types=document.createElement('div');types.className='grid4';
  for(const [label,value] of [['모유','breast'],['유축','pumped'],['분유','formula'],['혼합 (유축+분유)','mixed']]){
    const btn=option(label,()=>{feedType=value;renderPicker();});
    if(feedType===value)btn.classList.add('selected');types.append(btn);
  }
  el.append(types);
  const rows=feedType==='mixed'?[['유축','PumpedMl',0],['분유','FormulaMl',70]]:
    feedType==='breast'?[['모유','BreastMl',0]]:
    feedType==='pumped'?[['유축','PumpedMl',70]]:[['분유','FormulaMl',70]];
  for(const [label,id,value] of rows){
    const row=document.createElement('div');row.className='feed-line';
    const name=document.createElement('label');name.textContent=label+' (mL)';name.htmlFor='pick'+id;
    const input=document.createElement('input');input.type='number';input.min='0';input.max='1000';input.step='5';input.value=String(value);input.id='pick'+id;
    row.append(name,input);el.append(row);
  }
  if(feedType==='breast'){
    const check=document.createElement('label');check.className='feed-check';
    const input=document.createElement('input');input.type='checkbox';input.id='pickBreastUnknown';input.checked=true;
    check.append(input,document.createTextNode('직접 모유수유 · 양 미측정'));el.append(check);
  }
  const hint=document.createElement('p');hint.className='feed-footnote';
  hint.textContent=feedType==='mixed'?'혼합 수유는 유축 + 분유만 기록하며 두 종류 모두 5mL 이상 입력해야 합니다.':
    '모유는 혼합에 포함하지 않고 별도 수유로 기록합니다.';
  el.append(hint);
  // Final step before saving: select now or a past time, in five-minute increments.
  let offsetMinutes=0;
  const timeTitle=stepTitle('마지막 단계 · 수유 시간');el.append(timeTitle);
  const timeDisplay=document.createElement('p');timeDisplay.className='feed-footnote';el.append(timeDisplay);
  const timeControls=document.createElement('div');timeControls.className='grid4';el.append(timeControls);
  const sum=document.createElement('span');sum.className='time-offset-summary';sum.setAttribute('aria-live','polite');
  const redrawTime=()=>{const d=new Date(Date.now()-offsetMinutes*60000);
    timeDisplay.textContent='선택 시각: '+d.toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})
      +(offsetMinutes?' ('+offsetMinutes+'분 전)':' (현재)');
    sum.textContent='누적 '+offsetMinutes+'분 전';};
  timeControls.append(option('현재',()=>{offsetMinutes=0;redrawTime();}));
  timeControls.append(option('이전 시간',()=>{if(offsetMinutes===0)offsetMinutes=5;redrawTime();}));
  timeControls.append(option('−5분',()=>{offsetMinutes=Math.min(1440,offsetMinutes+5);redrawTime();}));
  timeControls.append(sum);
  redrawTime();
  const saveBtn=option('🍼 선택한 시간으로 수유 저장',async()=>{
    try{
      const get=id=>{const el=$(id);if(!el)return 0;const n=Number(el.value);
        if(!el.value.trim()||!Number.isInteger(n)||n<0||n>1000||n%5!==0)throw Error('5mL 단위로 입력해 주세요.');return n;};
      const p={breastMl:feedType==='breast'?get('pickBreastMl'):0,
        pumpedMl:['pumped','mixed'].includes(feedType)?get('pickPumpedMl'):0,
        formulaMl:['formula','mixed'].includes(feedType)?get('pickFormulaMl'):0,
        breastUnmeasured:feedType==='breast'&&$('pickBreastUnknown').checked};
      if(p.breastUnmeasured)p.breastMl=0;
      const total=p.breastMl+p.pumpedMl+p.formulaMl;
      if(total>1000||(total===0&&!p.breastUnmeasured))throw Error('수유량은 5mL 이상 입력해 주세요.');
      if(feedType==='mixed'&&(p.pumpedMl<5||p.formulaMl<5))throw Error('혼합은 유축과 분유를 각각 5mL 이상 입력해 주세요.');
      const data=feedData(p);saveBtn.disabled=true;
      await addDoc(collection(db,'families',family,'events'),{kind:'feed',...data,legacy:false,...meta(),
        at:offsetMinutes===0?serverTimestamp():Timestamp.fromMillis(Date.now()-offsetMinutes*60000)});
      show('picker',false);$('status').textContent='수유 기록 저장됨';
    }catch(e){error('기록 저장 실패: '+e.message);}finally{saveBtn.disabled=false;}
  });saveBtn.className='primary';saveBtn.style.width='100%';el.append(saveBtn);
}
async function save(k,t,ml,size){clearError();const e={kind:k,feedType:t,ml,size,legacy:false,...meta(),at:serverTimestamp()};
  show('picker',false);try{await addDoc(collection(db,'families',family,'events'),e);$('status').textContent='저장됨 · '+(labels[k]||k);}catch(ex){show('picker',true);error('기록 저장에 실패했습니다: '+ex.message);}}
async function init(){
  if(!firebaseConfig.apiKey||firebaseConfig.apiKey.startsWith('REPLACE')||!firebaseConfig.projectId||firebaseConfig.projectId.startsWith('REPLACE')){
    $('status').textContent='아직 Firebase 연결 전입니다.';error('관리자가 Firebase 설정을 연결한 뒤 GitHub Pages로 배포해야 가족 공유가 작동합니다.');return;
  }
  try{
    const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
    onAuthStateChanged(auth,async(u)=>{
      if(!u){try{await signInAnonymously(auth);}catch(e){error('로그인 실패: '+e.message);}return;}
      user=u;$('status').textContent='연결 준비 완료';
      const old=localStorage.getItem('agilog-family-code'),oldName=localStorage.getItem('agilog-family-name');
      if(old&&oldName){
        try{const m=await getDoc(doc(db,'families',old,'members',u.uid));if(m.exists()){await enter(old,oldName);return;}}catch(e){error('기존 가족 확인 실패: '+e.message);}
      }
      show('connect',true);
    });
  }catch(e){error('Firebase 연결 오류: '+e.message);}
}
setInterval(()=>{if(records.length)refreshSummary();},60000);
$('recordTabButton').onclick=()=>selectTab('record');$('statsTabButton').onclick=()=>selectTab('stats');$('toolsTabButton').onclick=()=>selectTab('tools');
window.addEventListener('message', e=>{if(e.origin===location.origin&&e.data?.source==='agilog-tools'){const h=Math.max(500,Math.min(16000,Number(e.data.height)||1200));$('toolsFrame').style.height=(h+15)+'px';}});
$('stats7').onclick=()=>setStatDays(7);$('stats30').onclick=()=>setStatDays(30);
window.addEventListener('resize',()=>{if(activeTab==='stats')renderStatistics();});
$('create').onclick=createFamily;$('join').onclick=joinFamily;
document.querySelectorAll('[data-kind]').forEach(b=>b.onclick=()=>picker(b.dataset.kind));
$('closePicker').onclick=()=>show('picker',false);
$('editKind').onchange=editVisibility;
$('editForm').onsubmit=saveEdit;
$('cancelEdit').onclick=()=>{$('editDialog').close();editingId=null;};
$('share').onclick=async()=>{const code=$('familyCode').textContent;const text='아기로그 가족 초대 코드: '+code+'\n같은 가족 공유 앱에 코드를 입력해 주세요.';
  try{if(navigator.share)await navigator.share({text});else{await navigator.clipboard.writeText(text);$('status').textContent='초대 코드 복사됨';}}
  catch(e){if(e.name!=='AbortError')error('공유할 수 없습니다. 코드를 길게 눌러 복사하세요.');}
};
if('serviceWorker' in navigator)navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
init();
