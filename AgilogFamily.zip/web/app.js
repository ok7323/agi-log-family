import {initializeApp} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js';
import {getAuth,onAuthStateChanged,signInAnonymously} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js';
import {getFirestore,doc,setDoc,getDoc,addDoc,collection,query,orderBy,limit,onSnapshot,deleteDoc,serverTimestamp} from 'https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js';
import {firebaseConfig} from './firebase-config.js';
const $=id=>document.getElementById(id);
let auth,db,user=null,family='',who='',unsubscribe=null,records=[],kind='',feedType='';
const labels={feed:'수유',poop:'대변',pee:'소변',breast:'모유',pumped:'유축',formula:'분유',small:'소',medium:'중',large:'대'};
const icons={feed:'🍼',poop:'💩',pee:'💧'};
const CODE='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function error(msg){$('error').textContent=String(msg);$('error').classList.remove('hidden');}
function clearError(){$('error').classList.add('hidden');$('error').textContent='';}
function show(id,flag){$(id).classList.toggle('hidden',!flag);}
function newCode(){const bytes=crypto.getRandomValues(new Uint8Array(20));return Array.from(bytes,v=>CODE[v%CODE.length]).join('');}
function name(){const v=$('name').value.trim();if(v.length<1||v.length>40)throw Error('이름을 1~40자로 입력하세요.');return v;}
function meta(){return{createdBy:user.uid,who,source:'web'};}
async function createFamily(){clearError();try{
  who=name();const code=newCode();
  // Failed member creation is recoverable: paste the new code into the join form.
  await setDoc(doc(db,'families',code),{createdBy:user.uid,createdAt:serverTimestamp()});
  try{await setDoc(doc(db,'families',code,'members',user.uid),{name:who,joinedAt:serverTimestamp()});}
  catch(e){$('invite').value=code;throw Error('가족은 만들었지만 가입에 실패했어요. 화면에 표시된 코드를 보관하고 다시 가입해 주세요. '+e.message);}
  await enter(code,who);
}catch(e){error(e.message);}}
async function joinFamily(){clearError();try{
  who=name();const code=$('invite').value.toUpperCase().replace(/[\s-]/g,'');
  if(!/^[A-HJ-NP-Z2-9]{20}$/.test(code))throw Error('가족 코드는 영문/숫자 20자리입니다.');
  try{await setDoc(doc(db,'families',code,'members',user.uid),{name:who,joinedAt:serverTimestamp()});}
  catch(e){const existing=await getDoc(doc(db,'families',code,'members',user.uid)).catch(()=>null);
    if(!existing?.exists())throw Error('코드가 틀렸거나 권한이 없습니다. 다시 확인해 주세요. '+e.message);
  }
  await enter(code,who);
}catch(e){error(e.message);}}
async function enter(code,n){
  family=code;who=n;
  localStorage.setItem('agilog-family-code',code);localStorage.setItem('agilog-family-name',n);
  $('familyCode').textContent=code;
  show('connect',false);show('app',true);$('status').textContent='연결됨 · '+n;
  if(unsubscribe){unsubscribe();unsubscribe=null;}
  const q=query(collection(db,'families',code,'events'),orderBy('at','desc'),limit(100));
  unsubscribe=onSnapshot(q,snap=>{records=snap.docs.map(d=>({id:d.id,...d.data()}));renderRecords();},e=>error('기록을 불러오지 못했어요: '+e.message));
}
function formatTime(item){const value=item.at?.toDate?.()||new Date();return value.toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});}
function details(r){if(r.legacy)return '이전 기록 · 상세 정보 없음';return r.kind==='feed'?(labels[r.feedType]||'수유')+' · '+(r.ml===-1?'양 미측정':`${r.ml||0}mL`):'양 '+(labels[r.size]||'-');}
function renderRecords(){
  const today=new Date().toDateString();for(const k of ['feed','poop','pee'])$('n-'+k).textContent=records.filter(r=>r.kind===k&&(r.at?.toDate?.()||new Date(0)).toDateString()===today).length;
  const container=$('records');container.replaceChildren();
  if(!records.length){container.textContent='첫 기록을 남겨보세요 🌱';return;}
  for(const r of records){const entry=document.createElement('div');entry.className='event';
    const symbol=document.createElement('span');symbol.textContent=icons[r.kind]||'🍼';entry.append(symbol);
    const main=document.createElement('div'),name=document.createElement('b'),detail=document.createElement('small');
    name.textContent=(labels[r.kind]||'기록')+' · '+formatTime(r);detail.textContent=details(r)+' · '+(r.who||'가족');
    main.append(name,detail);entry.append(main);
    if(r.createdBy===user?.uid){const btn=document.createElement('button');btn.textContent='삭제';btn.onclick=async()=>{
      if(!confirm('이 기록을 가족 모두의 기록에서 삭제할까요?'))return;
      try{await deleteDoc(doc(db,'families',family,'events',r.id));}catch(e){error(e.message);}
    };entry.append(btn);}
    container.append(entry);
  }
}
function option(text,fn){const button=document.createElement('button');button.textContent=text;button.onclick=fn;return button;}
function stepTitle(text){const el=document.createElement('h3');el.textContent=text;return el;}
function grid(container,values,fn,cls='grid'){const div=document.createElement('div');div.className=cls;for(const [label,value] of values)div.append(option(label,()=>fn(value)));container.append(div);}
function picker(k){kind=k;feedType='';show('picker',true);$('pickerTitle').textContent=(icons[k]||'')+' '+labels[k];renderPicker();$('picker').scrollIntoView({behavior:'smooth',block:'nearest'});}
function renderPicker(){const el=$('pickerStep');el.replaceChildren();
  if(kind!=='feed'){
    el.append(stepTitle('양을 선택하면 바로 저장돼요'));
    grid(el,[['소 · 적음','small'],['중 · 보통','medium'],['대 · 많음','large']],size=>save(kind,'',0,size));return;
  }
  if(!feedType){el.append(stepTitle('수유 종류 선택'));grid(el,[['모유','breast'],['유축','pumped'],['분유','formula']],type=>{feedType=type;renderPicker();});return;}
  el.append(stepTitle((labels[feedType]||'수유')+' · 용량 선택'));
  if(feedType==='breast')el.append(option('모유 직접 수유 · 양 미측정',()=>save('feed','breast',-1,'')));
  let max=200;const amounts=document.createElement('div');amounts.className='quant';el.append(amounts);
  const more=option('＋ 10mL 단위로 더 보기',()=>{max=Math.min(1000,max+100);renderAmounts();});more.style.width='100%';more.style.marginTop='12px';el.append(more);
  function renderAmounts(){amounts.replaceChildren();for(let ml=30;ml<=max;ml+=10)amounts.append(option(ml+'mL',()=>save('feed',feedType,ml,'')));more.hidden=max>=1000;}
  renderAmounts();
}
async function save(k,t,ml,size){clearError();const e={kind:k,feedType:t,ml,size,legacy:false,...meta(),at:serverTimestamp()};
  show('picker',false);try{await addDoc(collection(db,'families',family,'events'),e);$('status').textContent='저장됨 · '+(labels[k]||k);}catch(ex){show('picker',true);error('기록 저장에 실패했습니다: '+ex.message);}}
async function init(){
  if(!firebaseConfig.apiKey||firebaseConfig.apiKey.startsWith('REPLACE')||!firebaseConfig.projectId||firebaseConfig.projectId.startsWith('REPLACE')){
    $('status').textContent='아직 Firebase 연결 전입니다.';error('관리자가 Firebase 설정을 연결한 뒤 GitHub Pages로 배포해야 가족 공유가 작동합니다.');return;
  }
  try{
    const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);
    onAuthStateChanged(auth,async(u)=>{
      if(!u){try{await signInAnonymously(auth);}catch(e){error('로그인 실패: '+e.message);}return;}
      user=u;$('status').textContent='연결 준비 완료';
      const old=localStorage.getItem('agilog-family-code'),oldName=localStorage.getItem('agilog-family-name');
      if(old&&oldName){
        try{const m=await getDoc(doc(db,'families',old,'members',u.uid));if(m.exists()){await enter(old,oldName);return;}}catch(e){error('기존 가족 확인 실패: '+e.message);}
      }
      show('connect',true);
    });
  }catch(e){error('Firebase 연결 오류: '+e.message);}
}
$('create').onclick=createFamily;$('join').onclick=joinFamily;
document.querySelectorAll('[data-kind]').forEach(b=>b.onclick=()=>picker(b.dataset.kind));
$('closePicker').onclick=()=>show('picker',false);
$('share').onclick=async()=>{const code=$('familyCode').textContent;const text='아기로그 가족 초대 코드: '+code+'\n같은 가족 공유 앱에 코드를 입력해 주세요.';
  try{if(navigator.share)await navigator.share({text});else{await navigator.clipboard.writeText(text);$('status').textContent='초대 코드 복사됨';}}
  catch(e){if(e.name!=='AbortError')error('공유할 수 없습니다. 코드를 길게 눌러 복사하세요.');}
};
if('serviceWorker' in navigator)navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
init();
