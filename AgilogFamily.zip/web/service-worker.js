const CACHE='agi-family-shell-v81';
const GAME_LOOKS=Array.from({length:24},(_,look)=>Array.from({length:8},(_,pose)=>`./nooni-looks/look-${look}-${pose}.webp`)).flat();
const GAME_REACTIONS=['feed','soothe','diaper','play','sleep','practice'].flatMap(kind=>Array.from({length:5},(_,n)=>`./nooni-reactions/${kind}-${n}.webp`));
const GAME_WARDROBE_PRELOAD=[...Array.from({length:8},(_,i)=>`./nooni-wardrobe/background/${i}.webp`),...['feed','soothe','diaper','play','sleep','practice'].map(k=>`./nooni-wardrobe/care/${k}-0.webp`),...['outfit','ribbon','toy'].flatMap(k=>Array.from({length:16},(_,i)=>`./nooni-wardrobe/thumb/${k}-${i}.webp`))];
// v2.73 low-data install: cache only the shell, load 700+ artwork files on demand.
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./manifest.webmanifest','./parenting-tools.html','./icons/icon-192.png'])).then(()=>self.skipWaiting())));
self.addEventListener('activate', e=>e.waitUntil(Promise.all([caches.keys().then(names=>Promise.all(names.filter(name=>name.startsWith('agi-family-shell-')&&name!==CACHE).map(name=>caches.delete(name)))),self.clients.claim()])));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin)return;
 // Never cache Firebase auth, data or configuration; only static assets.
 if(/\/(?:index\.html|parenting-tools\.html|manifest\.webmanifest|icons\/|game-frames\/|nooni-hd\/|nooni-looks\/|nooni-reactions\/|nooni-wardrobe\/)/.test(new URL(e.request.url).pathname)) e.respondWith(fetch(e.request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(e.request,copy)).catch(()=>{});}return response;}).catch(()=>caches.match(e.request)));
});
