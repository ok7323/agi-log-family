const CACHE='agi-family-shell-v62';
self.addEventListener('install', e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./manifest.webmanifest','./parenting-tools.html','./icons/icon-192.png','./game-frames/nooni-0.webp','./game-frames/nooni-1.webp','./game-frames/nooni-2.webp','./game-frames/nooni-3.webp','./game-frames/nooni-4.webp','./game-frames/nooni-5.webp','./game-frames/nooni-6.webp','./game-frames/nooni-7.webp','./game-frames/nooni-8.webp'])).then(()=>self.skipWaiting())));
self.addEventListener('activate', e=>e.waitUntil(Promise.all([caches.keys().then(names=>Promise.all(names.filter(name=>name.startsWith('agi-family-shell-')&&name!==CACHE).map(name=>caches.delete(name)))),self.clients.claim()])));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin)return;
 // Never cache Firebase auth, data or configuration; only static assets.
 if(/\/(?:index\.html|parenting-tools\.html|manifest\.webmanifest|icons\/|game-frames\/)/.test(new URL(e.request.url).pathname)) e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
});
