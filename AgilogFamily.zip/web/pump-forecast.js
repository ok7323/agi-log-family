/**
 * Display-only milk expression forecast, capped at 200mL.
 * Use measured pumping volume from the latest rolling 72 hours, with the
 * interval since the preceding milk-removal event (pump or direct nursing).
 * Feeding the baby stored pumped milk is NOT another milk-removal event.
 *
 * Calibrate the previous piecewise baseline by a recency-weighted average of
 * observed amount / baseline(interval), shrunk toward 1 when samples are few.
 * This is a convenience estimate, not a physiological prediction.
 */
const HOUR = 3600000;
const WINDOW = 72 * HOUR;
const MAX_ML = 200;

export function baselinePumpMl(hours) {
  if (!Number.isFinite(hours)) return 0;
  const h = Math.max(0, hours);
  return Math.min(MAX_ML, h <= 1 ? h * 25 : 25 + (h - 1) * 175 / 9);
}

/** Original baseline kept for insufficient measured pumping history. */
export function estimatedPumpMl(lastAtMs, nowMs = Date.now()) {
  if (!Number.isFinite(lastAtMs) || lastAtMs <= 0 ||
      !Number.isFinite(nowMs) || lastAtMs > nowMs + 300000) return null;
  return Math.round(baselinePumpMl((nowMs - lastAtMs) / HOUR));
}

/** Each entry is {at: milliseconds, kind: 'pump'|'breast', ml?: measured pump mL}. */
export function estimateFromPumpHistory(entries, nowMs = Date.now(), previousTriggerMs = null) {
  const events = (Array.isArray(entries) ? entries : [])
    .filter(e => e && Number.isFinite(e.at) && e.at > 0 && e.at <= nowMs + 300000 &&
      (e.kind === 'pump' || e.kind === 'breast'))
    .sort((a, b) => a.at - b.at);
  let lastTrigger = Number.isFinite(previousTriggerMs) && previousTriggerMs > 0 ? previousTriggerMs : null;
  let previousAt = null;
  let weightedRatio = 0;
  let totalWeight = 0;
  let count = 0;
  for (const e of events) {
    if (e.kind === 'pump' && e.at >= nowMs - WINDOW &&
        Number.isFinite(e.ml) && e.ml > 0 && e.ml <= 1000 && previousAt !== null) {
      const gapHours = (e.at - previousAt) / HOUR;
      if (gapHours >= 0.5 && gapHours <= 16) {
        const expected = baselinePumpMl(gapHours);
        if (expected >= 1) {
          const ratio = Math.max(0.25, Math.min(2.5, e.ml / expected));
          const ageHours = (nowMs - e.at) / HOUR;
          const weight = ageHours < 24 ? 1 : ageHours < 48 ? 0.8 : 0.6;
          weightedRatio += ratio * weight;
          totalWeight += weight;
          count++;
        }
      }
    }
    previousAt = e.at;
    if (lastTrigger === null || e.at > lastTrigger) lastTrigger = e.at;
  }
  const factor = (2 + weightedRatio) / (2 + totalWeight);
  const base = estimatedPumpMl(lastTrigger, nowMs);
  return {
    ml: base === null ? null : Math.min(MAX_ML, Math.max(0,
      Math.round(baselinePumpMl((nowMs - lastTrigger) / HOUR) * factor))),
    samples: count,
    factor,
    lastAt: lastTrigger
  };
}
