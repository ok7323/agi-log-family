/**
 * Display-only pumping estimate built ONLY from the previous 72 hours of
 * measured pumping (mL and interval). No prescribed 25mL/hour rate, no 10-hour
 * 200mL target and no fallback curve. The separate user-requested upper display
 * limit remains 200mL.
 *
 * Each measured pump is paired with the preceding milk-removal event (pumping
 * or direct breastfeeding). The first 20 minutes of that interval are treated
 * as an inactive period. A bottle feed of previously pumped milk never resets
 * the timer or supplies training data.
 *
 * Use a recent-weighted, outlier-resistant mean of the observed mL per active
 * hour. Require at least two usable measured pumping intervals before making
 * a numerical prediction. This is a user-configured estimate, not a clinical
 * measurement or a statement about the physiology of milk production.
 */
const HOUR = 3600000;
const PAUSE_MS = 20 * 60000;
const WINDOW = 72 * HOUR;
const MAX_ML = 200;
const MIN_ACTIVE_HOURS = 0.25;
const MAX_INTERVAL_HOURS = 24;
const MIN_SAMPLES = 2;

function observations(entries, atMs) {
  const sorted = (Array.isArray(entries) ? entries : [])
    .filter(e => e && Number.isFinite(e.at) && e.at > 0 && e.at <= atMs &&
      (e.kind === 'pump' || e.kind === 'breast'))
    .sort((a,b) => a.at - b.at);
  let previous = null;
  const samples = [];
  for (const event of sorted) {
    if (event.kind === 'pump' && event.at >= atMs - WINDOW &&
        Number.isFinite(event.ml) && event.ml > 0 && event.ml <= 1000 &&
        previous !== null && event.at > previous) {
      const gapHours = (event.at - previous) / HOUR;
      const activeHours = (event.at - previous - PAUSE_MS) / HOUR;
      if (activeHours >= MIN_ACTIVE_HOURS && gapHours <= MAX_INTERVAL_HOURS) {
        const ageHours = (atMs - event.at) / HOUR;
        const weight = ageHours < 24 ? 1 : ageHours < 48 ? 0.8 : 0.6;
        samples.push({rate:event.ml / activeHours, weight});
      }
    }
    previous = event.at;
  }
  return {lastAt:previous, samples};
}

function learnedRate(samples) {
  if (samples.length < MIN_SAMPLES) return null;
  const sorted = samples.slice().sort((a,b)=>a.rate-b.rate);
  const weightSum = sorted.reduce((sum,s)=>sum+s.weight,0);
  let cumulative = 0;
  let median = sorted[0].rate;
  for (const s of sorted) {
    cumulative += s.weight;
    if (cumulative >= weightSum / 2) {median = s.rate; break;}
  }
  // Winsorize extreme rates RELATIVE TO OBSERVED DATA, not a fixed mL/h curve.
  const lower = median * 0.5;
  const upper = median * 2;
  const weighted = sorted.reduce((sum,s)=>
    sum + Math.max(lower,Math.min(upper,s.rate))*s.weight,0);
  const rate = weighted / weightSum;
  return Number.isFinite(rate) && rate > 0 ? rate : null;
}

/** Each entry: {at: milliseconds, kind: 'pump'|'breast', ml?: measured mL}. */
export function estimateFromPumpHistory(entries, nowMs=Date.now(), previousTriggerMs=null) {
  if (!Number.isFinite(nowMs) || nowMs <= 0)
    return {ml:null,samples:0,rate:null,lastAt:null};
  const result = observations(entries, nowMs);
  const lastAt = Number.isFinite(previousTriggerMs) && previousTriggerMs > 0 &&
    previousTriggerMs <= nowMs && (result.lastAt === null || previousTriggerMs > result.lastAt)
      ? previousTriggerMs : result.lastAt;
  const rate = learnedRate(result.samples);
  const elapsed = lastAt === null ? null : nowMs - lastAt;
  const ml = elapsed === null ? null : elapsed <= PAUSE_MS ? 0 :
    rate === null ? null : Math.round(Math.max(0,
      Math.min(MAX_ML, rate * ((elapsed - PAUSE_MS) / HOUR))));
  return {ml, samples:result.samples.length, rate, lastAt};
}

/**
 * Backtest a pump at its RECORDED INSTANT using strictly earlier records,
 * excluding the first 72 hours since the earliest pump and any history with
 * fewer than two qualifying measured pumping intervals. Never persisted.
 * Map key is pumping timestamp in milliseconds.
 */
export function historicalPumpEstimates(entries, asOfMs=Date.now()) {
  const timeline = (Array.isArray(entries)?entries:[])
    .filter(e=>e && Number.isFinite(e.at) && e.at>0 && e.at<=asOfMs &&
      (e.kind==='pump'||e.kind==='breast'))
    .sort((a,b)=>a.at-b.at);
  const firstPumpAt = timeline.find(e=>e.kind==='pump')?.at;
  const forecasts = new Map();
  if (!Number.isFinite(firstPumpAt)) return forecasts;
  let windowStart = 0;
  for (let i=0;i<timeline.length;) {
    const at = timeline[i].at;
    let next = i+1;
    while (next<timeline.length && timeline[next].at===at) next++;
    if (at-firstPumpAt>=WINDOW &&
        timeline.slice(i,next).some(e=>e.kind==='pump')) {
      while (windowStart<i && timeline[windowStart].at<at-WINDOW) windowStart++;
      // One older trigger allows the earliest interval in this window to be
      // measured, without letting any future or same-time record train itself.
      const prior = timeline.slice(Math.max(0,windowStart-1),i);
      const result = estimateFromPumpHistory(prior,at);
      if (result.samples>=MIN_SAMPLES && result.ml!==null)
        forecasts.set(at,result.ml);
    }
    i=next;
  }
  return forecasts;
}
