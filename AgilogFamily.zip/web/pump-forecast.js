/**
 * Display-only milk expression forecast, capped at 200mL.
 * Use measured pumping volume from the latest rolling 72 hours, with the
 * interval since the preceding milk-removal event (pump or direct nursing).
 * The first 20 minutes after each recorded milk-removal start are inactive:
 * accumulation begins only after the first 20 minutes.
 * Feeding the baby stored pumped milk is NOT another milk-removal event.
 *
 * Calibrate the previous piecewise baseline by a recency-weighted average of
 * observed amount / baseline(interval), shrunk toward 1 when samples are few.
 * This is a convenience estimate, not a physiological prediction.
 */
const HOUR = 3600000;
const NO_ACCUMULATION_MS = 20 * 60000;
const WINDOW = 72 * HOUR;
const MAX_ML = 200;

export function baselinePumpMl(hours) {
  if (!Number.isFinite(hours)) return 0;
  // hours is the full elapsed time; model only time AFTER 20 minutes.
  const h = Math.max(0, hours - NO_ACCUMULATION_MS / HOUR);
  return Math.min(MAX_ML, h <= 1 ? h * 25 : 25 + (h - 1) * 175 / 9);
}

/** Original baseline kept for insufficient measured pumping history. */
export function estimatedPumpMl(lastAtMs, nowMs = Date.now()) {
  if (!Number.isFinite(lastAtMs) || lastAtMs <= 0 ||
      !Number.isFinite(nowMs) || lastAtMs > nowMs + 300000) return null;
  return Math.round(baselinePumpMl((nowMs - lastAtMs) / HOUR));
}

/** Each entry is {at: milliseconds, kind: 'pump'|'breast', ml?: measured pump mL}. */
export function estimateFromPumpHistory(entries, nowMs = Date.now(), previousTriggerMs = null) {
  const events = (Array.isArray(entries) ? entries : [])
    .filter(e => e && Number.isFinite(e.at) && e.at > 0 && e.at <= nowMs + 300000 &&
      (e.kind === 'pump' || e.kind === 'breast'))
    .sort((a, b) => a.at - b.at);
  let lastTrigger = Number.isFinite(previousTriggerMs) && previousTriggerMs > 0 ? previousTriggerMs : null;
  let previousAt = null;
  let weightedRatio = 0;
  let totalWeight = 0;
  let count = 0;
  for (const e of events) {
    if (e.kind === 'pump' && e.at >= nowMs - WINDOW &&
        Number.isFinite(e.ml) && e.ml > 0 && e.ml <= 1000 && previousAt !== null) {
      const gapHours = (e.at - previousAt) / HOUR;
      if (gapHours >= 0.5 && gapHours <= 16) {
        const expected = baselinePumpMl(gapHours);
        if (expected >= 1) {
          const ratio = Math.max(0.25, Math.min(2.5, e.ml / expected));
          const ageHours = (nowMs - e.at) / HOUR;
          const weight = ageHours < 24 ? 1 : ageHours < 48 ? 0.8 : 0.6;
          weightedRatio += ratio * weight;
          totalWeight += weight;
          count++;
        }
      }
    }
    previousAt = e.at;
    if (lastTrigger === null || e.at > lastTrigger) lastTrigger = e.at;
  }
  const factor = (2 + weightedRatio) / (2 + totalWeight);
  const base = estimatedPumpMl(lastTrigger, nowMs);
  return {
    ml: base === null ? null : Math.min(MAX_ML, Math.max(0,
      Math.round(baselinePumpMl((nowMs - lastTrigger) / HOUR) * factor))),
    samples: count,
    factor,
    lastAt: lastTrigger
  };
}

/**
 * Historical, display-only backtest for each pumping entry. At its recorded
 * instant use exclusively prior events (strictly earlier timestamps), never
 * the milk amount being entered or future events. Suppress the first 72 hours
 * after the family's earliest recorded pump, plus periods without measured
 * calibration samples in the preceding 72 hours.
 * Map key = pumping event Unix timestamp (milliseconds). Nothing is persisted.
 */
export function historicalPumpEstimates(entries, asOfMs = Date.now()) {
  const timeline = (Array.isArray(entries) ? entries : [])
    .filter(e => e && Number.isFinite(e.at) && e.at > 0 &&
      e.at <= asOfMs + 300000 && (e.kind === 'pump' || e.kind === 'breast'))
    .sort((a, b) => a.at - b.at);
  const firstPumpAt = timeline.find(e => e.kind === 'pump')?.at;
  const forecasts = new Map();
  if (!Number.isFinite(firstPumpAt)) return forecasts;
  let windowStart = 0;
  for (let i = 0; i < timeline.length;) {
    const at = timeline[i].at;
    let next = i + 1;
    while (next < timeline.length && timeline[next].at === at) next++;
    // Equal-time pump events also cannot train one another.
    if (at - firstPumpAt >= WINDOW &&
        timeline.slice(i, next).some(e => e.kind === 'pump')) {
      while (windowStart < i && timeline[windowStart].at < at - WINDOW) windowStart++;
      // Keep one extra earlier event so the oldest measured interval has its
      // original start time, without looking forward at the current pump.
      const previous = timeline.slice(Math.max(0, windowStart - 1), i);
      const value = estimateFromPumpHistory(previous, at);
      if (value.samples > 0 && value.ml !== null) forecasts.set(at, value.ml);
    }
    i = next;
  }
  return forecasts;
}
