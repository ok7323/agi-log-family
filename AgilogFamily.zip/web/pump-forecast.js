/**
 * Visual-only pumping amount estimate since the last direct pumping OR direct
 * breastfeeding record. No changes to measured milk totals or Firebase data.
 * 0..1h: 0->25mL, 1..10h: 25->200mL, beyond 10h: capped at 200mL.
 */
export function estimatedPumpMl(lastAtMs, nowMs = Date.now()) {
  if (!Number.isFinite(lastAtMs) || lastAtMs <= 0 ||
      !Number.isFinite(nowMs) || lastAtMs > nowMs + 300000) return null;
  const hours = Math.max(0, (nowMs - lastAtMs) / 3600000);
  return Math.round(hours <= 1 ? hours * 25 :
    hours < 10 ? 25 + (hours - 1) * 175 / 9 : 200);
}
