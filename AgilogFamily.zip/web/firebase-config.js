// GitHub Actions가 아래 설정을 배포할 때 Firebase Web 앱 설정으로 바꿉니다.
// 이 파일의 예시 값으로는 가족 공유가 작동하지 않습니다.
export const firebaseConfig = {
  apiKey: 'REPLACE_API_KEY',
  authDomain: 'REPLACE_PROJECT.firebaseapp.com',
  projectId: 'REPLACE_PROJECT',
  appId: 'REPLACE_APP_ID'
};
