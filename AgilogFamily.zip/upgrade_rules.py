from pathlib import Path
p=Path('/mnt/data/agilog_v3/firestore.rules');s=p.read_text()
anchor='    function validEvent(d) {'
fn='''    // Legacy feed entries remain readable/editable; new entries use a 5mL parts map.
    function validParts(p) {
      return p is map
        && p.keys().hasAll(['breastMl', 'pumpedMl', 'formulaMl', 'breastUnmeasured'])
        && p.keys().hasOnly(['breastMl', 'pumpedMl', 'formulaMl', 'breastUnmeasured'])
        && p.breastMl is int && p.pumpedMl is int && p.formulaMl is int
        && p.breastUnmeasured is bool
        && p.breastMl >= 0 && p.pumpedMl >= 0 && p.formulaMl >= 0
        && p.breastMl % 5 == 0 && p.pumpedMl % 5 == 0 && p.formulaMl % 5 == 0
        && (p.breastMl + p.pumpedMl + p.formulaMl <= 1000)
        && (p.breastMl + p.pumpedMl + p.formulaMl > 0 || p.breastUnmeasured);
    }
    function validFeed(d) {
      return d.kind == 'feed' && d.size == '' && d.ml is int && (
        (d.keys().hasAny(['feedParts'])
          && validParts(d.feedParts)
          && d.ml == d.feedParts.breastMl + d.feedParts.pumpedMl + d.feedParts.formulaMl
          && d.feedType in ['breast', 'pumped', 'formula', 'mixed'])
        || (!d.keys().hasAny(['feedParts'])
          && d.feedType in ['breast', 'pumped', 'formula']
          && ((d.ml >= 30 && d.ml <= 1000 && d.ml % 10 == 0)
          || (d.feedType == 'breast' && d.ml == -1)))
      );
    }

'''
assert anchor in s;s=s.replace(anchor,fn+anchor)
s=s.replace("['kind', 'feedType', 'ml', 'size', 'createdBy', 'who', 'at', 'source', 'legacy']", "['kind', 'feedType', 'ml', 'size', 'createdBy', 'who', 'at', 'source', 'legacy', 'feedParts']",1)
old="""            (d.kind == 'feed'
              && d.feedType in ['breast', 'pumped', 'formula']
              && d.size == ''
              && d.ml is int
              && ((d.ml >= 30 && d.ml <= 1000 && d.ml % 10 == 0)
                || (d.feedType == 'breast' && d.ml == -1)))
            ||
            (d.kind in ['pee', 'poop', 'both']
              && d.feedType == ''
              && d.ml == 0
              && d.size in ['small', 'medium', 'large'])"""
new="""            validFeed(d)
            ||
            (d.kind in ['pee', 'poop', 'both']
              && !d.keys().hasAny(['feedParts'])
              && d.feedType == ''
              && d.ml == 0
              && d.size in ['small', 'medium', 'large'])"""
assert old in s;s=s.replace(old,new)
s=s.replace(".hasOnly(['kind', 'feedType', 'ml', 'size', 'at', 'legacy'])", ".hasOnly(['kind', 'feedType', 'ml', 'size', 'at', 'legacy', 'feedParts'])")
p.write_text(s)
Path('/mnt/data/AgilogFamily-Firestore-Rules-v3.txt').write_text(s)
