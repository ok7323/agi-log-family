from pathlib import Path
p=Path('/mnt/data/agilog_v23/android/app/src/main/java/com/agilog/local/QuickNotification.java')
s=p.read_text()
s=s.replace('import android.os.Build;','import android.os.Build;\nimport android.os.SystemClock;\nimport java.util.Date;\nimport java.text.SimpleDateFormat;\nimport java.util.Locale;\nimport java.util.UUID;')
s=s.replace('private static final String MAIN="main",TYPES="types",SIZE="size",MILK="milk";', 'private static final String MAIN="main",TYPES="types",SIZE="size",MILK="milk",TIME="time";')
s=s.replace('static void enabled(Context c,boolean value){FamilyStore.prefs(c).edit().putBoolean("quick",value).apply();if(value){reset(c);show(c);}else hide(c);}', 'static void enabled(Context c,boolean value){FamilyStore.prefs(c).edit().putBoolean("quick",value).apply();if(value){reset(c);QuickStatsWorker.schedule(c);QuickStatsWorker.request(c);show(c);}else{QuickStatsWorker.unschedule(c);hide(c);}}')
s=s.replace('static void reset(Context c){FamilyStore.prefs(c).edit().putString(MODE,MAIN).remove(TYPE).remove(KIND).putInt("amount",70).putInt("page",0).apply();}', 'static void reset(Context c){FamilyStore.prefs(c).edit().putString(MODE,MAIN).remove(TYPE).remove(KIND).remove("pending_ml").remove("pending_unknown").remove("time_anchor").putInt("time_offset",0).putInt("amount",70).putInt("page",0).apply();}')
s=s.replace('if(MILK.equals(m))return new String[]{"−5",FamilyStore.prefs(c).getInt("amount",70)+"mL 저장","+5"};\n        return new String[]{"🍼 수유","💧 소변","💩 대변","💧💩 소+대변"};', 'if(MILK.equals(m))return new String[]{"−5",FamilyStore.prefs(c).getInt("amount",70)+"mL 다음","+5"};\n        if(TIME.equals(m))return new String[]{"지금 저장","−5분","+5분","이전 저장"};\n        return new String[]{"🍼 수유","💧 소변","💩 대변","💧💩"};')
s=s.replace('if(MILK.equals(m))return new String[]{"minus","save","plus"};','if(MILK.equals(m))return new String[]{"minus","save","plus"};\n        if(TIME.equals(m))return new String[]{"now","earlier","later","prior"};')
s=s.replace('if(MILK.equals(m))return "🍼 "+FamilyStore.typeLabel(FamilyStore.prefs(c).getString(TYPE,"formula"))+" · 양 선택";\n        return "아기로그 · 수유/소변/대변/소+대변";', 'if(MILK.equals(m))return "🍼 "+FamilyStore.typeLabel(FamilyStore.prefs(c).getString(TYPE,"formula"))+" · 양 선택";\n        if(TIME.equals(m))return "🍼 수유 시간 선택 · 아래에서 저장";\n        return "아기로그 · 빠른 기록";')
s=s.replace('        big.setTextViewText(R.id.quick_title,title(c));', '''        QuickStats.Summary stats=QuickStats.get(c);
        String totals=stats.synced?"오늘 "+stats.todayMl+"mL · 어제 "+stats.yesterdayMl+"mL":"오늘 — · 어제 — (동기화 대기)";
        small.setTextViewText(R.id.quick_totals_small,totals);
        big.setTextViewText(R.id.quick_totals_big,stats.synced?"오늘 총 수유 "+stats.todayMl+"mL · 어제 총 "+stats.yesterdayMl+"mL":"수유 합계 동기화 대기 중");
        if(stats.lastFeed>0){
            long elapsedMs=Math.max(0,System.currentTimeMillis()-stats.lastFeed);
            long base=SystemClock.elapsedRealtime()-elapsedMs;
            small.setViewVisibility(R.id.quick_elapsed_small,View.VISIBLE);
            big.setViewVisibility(R.id.quick_elapsed_big,View.VISIBLE);
            small.setViewVisibility(R.id.quick_empty_small,View.GONE);
            big.setViewVisibility(R.id.quick_empty_big,View.GONE);
            small.setChronometer(R.id.quick_elapsed_small,base,null,true);
            big.setChronometer(R.id.quick_elapsed_big,base,null,true);
        }else{
            small.setViewVisibility(R.id.quick_elapsed_small,View.GONE);
            big.setViewVisibility(R.id.quick_elapsed_big,View.GONE);
            small.setViewVisibility(R.id.quick_empty_small,View.VISIBLE);
            big.setViewVisibility(R.id.quick_empty_big,View.VISIBLE);
        }
        big.setTextViewText(R.id.quick_title,title(c));''')
s=s.replace('        }else big.setViewVisibility(R.id.quantities,View.GONE);','''        }else big.setViewVisibility(R.id.quantities,View.GONE);
        if(TIME.equals(mode(c))){
            int offset=FamilyStore.prefs(c).getInt("time_offset",0);
            long anchor=FamilyStore.prefs(c).getLong("time_anchor",System.currentTimeMillis());
            SimpleDateFormat f=new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA);
            big.setViewVisibility(R.id.selected_time,View.VISIBLE);
            big.setTextViewText(R.id.selected_time,"선택: "+f.format(new Date(anchor-offset*60000L))+(offset>0?" ("+offset+"분 전)":" (현재)"));
            big.setViewVisibility(R.id.change_amount,View.VISIBLE);
            big.setOnClickPendingIntent(R.id.change_amount,intent(c,"editml"));
        }else{
            big.setViewVisibility(R.id.selected_time,View.GONE);
            big.setViewVisibility(R.id.change_amount,View.GONE);
        }''')
s=s.replace('.setContentTitle("아기로그 가족").setContentText(title(c)).setVisibility(Notification.VISIBILITY_PUBLIC)', '.setContentTitle("아기로그 가족").setContentText(totals).setVisibility(Notification.VISIBILITY_PUBLIC)')
s=s.replace('        }else if(MILK.equals(m)){', '        }else if(MILK.equals(m)){')
start=s.index('            else if("unknown".equals(key)&&FamilyStore.BREAST.equals(type)){')
end=s.index('        }else return;\n        e.commit();show(c);',start)
s=s[:start]+'''            else if("unknown".equals(key)&&FamilyStore.BREAST.equals(type)){
                e.putString(MODE,TIME).putInt("pending_ml",-1).putBoolean("pending_unknown",true)
                    .putLong("time_anchor",System.currentTimeMillis()).putInt("time_offset",0);
            }else if("save".equals(key)){
                e.putString(MODE,TIME).putInt("pending_ml",amount).putBoolean("pending_unknown",false)
                    .putLong("time_anchor",System.currentTimeMillis()).putInt("time_offset",0);
            }else if(key.startsWith("ml-")){
                int ml;try{ml=Integer.parseInt(key.substring(3));}catch(NumberFormatException error){return;}
                if(ml<5||ml>1000||ml%5!=0||ml<5+page*40||ml>40+page*40)return;
                e.putString(MODE,TIME).putInt("pending_ml",ml).putBoolean("pending_unknown",false)
                    .putLong("time_anchor",System.currentTimeMillis()).putInt("time_offset",0);
            }else return;
        }else if(TIME.equals(m)){
            int offset=FamilyStore.prefs(c).getInt("time_offset",0);
            if("editml".equals(key))e.putString(MODE,MILK);
            else if("earlier".equals(key))e.putInt("time_offset",Math.min(24*60,offset+5));
            else if("later".equals(key))e.putInt("time_offset",Math.max(0,offset-5));
            else if("now".equals(key)||"prior".equals(key)){
                long anchor=FamilyStore.prefs(c).getLong("time_anchor",System.currentTimeMillis());
                long timestamp="now".equals(key)?System.currentTimeMillis():anchor-Math.max(5,offset)*60000L;
                String type=FamilyStore.prefs(c).getString(TYPE,FamilyStore.FORMULA);
                int ml=FamilyStore.prefs(c).getInt("pending_ml",70);
                RecordWorker.queueFull(c,UUID.randomUUID().toString(),FamilyStore.FEED,type,ml,"",timestamp,false);
                e.putString(MODE,MAIN).remove("pending_ml").remove("pending_unknown");
            }else return;
''' + s[end:]
p.write_text(s)
