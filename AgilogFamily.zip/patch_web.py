from pathlib import Path
p=Path('/mnt/data/agilog_v23/web/app.js')
s=p.read_text()
s=s.replace('''  $('total-feed').textContent=today.reduce((sum,r)=>sum+feedTotal(r),0)+'mL';''','''  $('total-feed').textContent=today.reduce((sum,r)=>sum+feedTotal(r),0)+'mL';
  const yesterdayDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()-1).getTime();
  $('yesterday-feed').textContent=records.filter(r=>r.kind==='feed'&&r.at?.toDate?.() instanceof Date
    &&r.at.toDate().getTime()>=yesterdayDate&&r.at.toDate().getTime()<day)
    .reduce((sum,r)=>sum+feedTotal(r),0)+'mL';''')
anchor="  const saveBtn=option('🍼 이번 수유 저장',async()=>{"
assert anchor in s
s=s.replace(anchor,'''  // Final step before saving: select now or a past time, in five-minute increments.
  let offsetMinutes=0;
  const timeTitle=stepTitle('마지막 단계 · 수유 시간');el.append(timeTitle);
  const timeDisplay=document.createElement('p');timeDisplay.className='feed-footnote';el.append(timeDisplay);
  const timeControls=document.createElement('div');timeControls.className='grid';el.append(timeControls);
  const redrawTime=()=>{const d=new Date(Date.now()-offsetMinutes*60000);
    timeDisplay.textContent='선택 시각: '+d.toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})
      +(offsetMinutes?' ('+offsetMinutes+'분 전)':' (현재)');};
  timeControls.append(option('현재',()=>{offsetMinutes=0;redrawTime();}));
  timeControls.append(option('이전 시간',()=>{if(offsetMinutes===0)offsetMinutes=5;redrawTime();}));
  timeControls.append(option('−5분',()=>{offsetMinutes=Math.min(1440,offsetMinutes+5);redrawTime();}));
  timeControls.append(option('+5분',()=>{offsetMinutes=Math.max(0,offsetMinutes-5);redrawTime();}));
  redrawTime();
  const saveBtn=option('🍼 선택한 시간으로 수유 저장',async()=>{''')
s=s.replace('''await addDoc(collection(db,'families',family,'events'),{kind:'feed',...data,legacy:false,...meta(),at:serverTimestamp()});''','''await addDoc(collection(db,'families',family,'events'),{kind:'feed',...data,legacy:false,...meta(),
        at:offsetMinutes===0?serverTimestamp():Timestamp.fromMillis(Date.now()-offsetMinutes*60000)});''')
p.write_text(s)
p=Path('/mnt/data/agilog_v23/web/index.html')
s=p.read_text()
old='<p id="unknown-feed" class="hint hidden">'
assert old in s
s=s.replace(old,'<p class="hint">어제 총 수유량: <b id="yesterday-feed">0mL</b></p>\n'+old)
p.write_text(s)
