package com.agilog.local;

import android.app.Activity;
import android.webkit.WebView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.CollectionReference;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Bridge between the signed-in native Firebase Auth session and the bundled tools page.
 *  This avoids a separate anonymous WebView login with a non-member UID.
 */
public final class ToolCloudSync {
    private final Activity activity;
    private final WebView view;
    private final String family;
    private final FirebaseFirestore firestore;
    private final ArrayList<ListenerRegistration> observers = new ArrayList<>();
    private volatile boolean closed = false;
    private static final String[] NAMES = {"entries","schedules","checks","stocks","meta"};
    private static final String[] PATHS = {"toolEntries","toolSchedules","toolChecks","toolStocks","toolMeta"};

    ToolCloudSync(Activity activity, WebView view, String family){
        this.activity=activity;this.view=view;this.family=family;this.firestore=FamilyStore.db();
    }
    private String path(String category){
        for(int i=0;i<NAMES.length;i++)if(NAMES[i].equals(category))return PATHS[i];
        return null;
    }
    private void send(String fn,JSONObject msg){
        if(closed)return;
        final String js="window."+fn+"("+JSONObject.quote(msg.toString())+");";
        activity.runOnUiThread(()->{if(!closed)view.evaluateJavascript(js,null);});
    }
    private void failure(String message){try{
        JSONObject m=new JSONObject();m.put("type","error");m.put("message",message);
        send("agilogToolRemote",m);
    }catch(Exception ignored){}}
    void start(){
        if(closed||family==null||family.isEmpty()){failure("가족 연결이 필요합니다.");return;}
        for(String category:NAMES){
            CollectionReference c=firestore.collection("families").document(family).collection(path(category));
            ListenerRegistration reg=c.addSnapshotListener((snap,err)->{
                if(closed)return;
                if(err!=null){failure(category+" 데이터 읽기 실패: "+err.getMessage());return;}
                try{
                    JSONArray rows=new JSONArray();
                    if(snap!=null)for(DocumentSnapshot d:snap.getDocuments()){
                        Map<String,Object> fields=d.getData();
                        JSONObject item=fields==null?new JSONObject():new JSONObject(fields);
                        item.put("id",d.getId());rows.put(item);
                    }
                    JSONObject packet=new JSONObject();packet.put("type","snapshot");packet.put("category",category);packet.put("items",rows);
                    send("agilogToolRemote",packet);
                }catch(Exception e){failure("데이터 해석 오류: "+e.getMessage());}
            });
            observers.add(reg);
        }
    }
    public void write(String json){
        try{
            if(closed)throw new Exception("화면이 닫혔습니다.");
            final JSONObject req=new JSONObject(json);
            final String category=req.optString("category"),id=req.optString("id"),action=req.optString("action");
            final String path=path(category),key=category+"|"+id;
            final int seq=req.optInt("seq",0);
            if(path==null||!("delete".equals(action)||"upsert".equals(action))
                ||!id.matches("[A-Za-z0-9_.%\\-]{1,180}"))throw new Exception("유효하지 않은 기록입니다.");
            if(!FamilyStore.code(activity).equals(family)||FamilyStore.uid().isEmpty())throw new Exception("가족 로그인 상태를 확인하세요.");
            var ref=firestore.collection("families").document(family).collection(path).document(id);
            if("delete".equals(action)){
                ref.delete().addOnSuccessListener(v->ack(key,seq,true,"")).addOnFailureListener(e->ack(key,seq,false,e.getMessage()));
            }else{
                JSONObject obj=req.optJSONObject("value");if(obj==null)throw new Exception("기록 내용이 없습니다.");
                Map<String,Object> fields=new HashMap<>();
                switch(category){
                    case "entries":
                        fields.put("kind",obj.getString("kind"));fields.put("at",obj.getLong("at"));
                        Object val=obj.get("value");fields.put("value",val instanceof Number?val:String.valueOf(val));
                        fields.put("note",obj.optString("note",""));break;
                    case "schedules":
                        fields.put("name",obj.getString("name"));fields.put("at",obj.getLong("at"));
                        fields.put("done",obj.getBoolean("done"));break;
                    case "checks":
                        fields.put("label",obj.getString("label"));fields.put("done",obj.getBoolean("done"));break;
                    case "stocks":
                        fields.put("name",obj.getString("name"));fields.put("count",obj.getInt("count"));break;
                    case "meta":
                        if(!"current".equals(id))throw new Exception("잘못된 타이머 정보입니다.");
                        fields.put("sleepStart",obj.getLong("sleepStart"));break;
                    default:throw new Exception("알 수 없는 기록입니다.");
                }
                ref.set(fields).addOnSuccessListener(v->ack(key,seq,true,"")).addOnFailureListener(e->ack(key,seq,false,e.getMessage()));
            }
        }catch(Exception e){
            try{JSONObject req=new JSONObject(json);ack(req.optString("category")+"|"+req.optString("id"),req.optInt("seq",0),false,e.getMessage());}
            catch(Exception ignored){failure("저장 요청 처리 실패: "+e.getMessage());}
        }
    }
    private void ack(String key,int seq,boolean ok,String message){try{
        JSONObject r=new JSONObject();r.put("key",key);r.put("seq",seq);r.put("ok",ok);r.put("message",message==null?"":message);
        send("agilogToolAck",r);
    }catch(Exception ignored){}}
    void close(){closed=true;for(ListenerRegistration l:observers)l.remove();observers.clear();}
}
