package com.agilog.local;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public final class QuickReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){if(intent!=null)QuickNotification.action(context,intent.getAction());}
}
