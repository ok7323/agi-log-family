package com.agilog.local;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.Timestamp;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

final class FamilyStore {
    static final String BREAST="breast",PUMPED="pumped",FORMULA="formula";
    static final String FEED="feed",POOP="poop",PEE="pee",BOTH="both";
    static final String SMALL="small",MEDIUM="medium",LARGE="large";
    private static final String FAMILY_PREF="agi_family_v1";
    private static final String CODES="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(FAMILY_PREF,Context.MODE_PRIVATE);}
    static String code(Context c){return prefs(c).getString("family_code","");}
    static String name(Context c){return prefs(c).getString("display_name","나");}
    // Independent, device-local defaults. Old shared preference is intentionally not
    // inherited: a previous 70mL value must not override the new 50mL defaults.
    private static boolean validVolume(int n){return n>=5 && n<=1000 && n%5==0;}
    static int defaultPumpedMl(Context c){
        int n=prefs(c).getInt("default_pumped_ml",50);
        return validVolume(n)?n:50;
    }
    static int defaultFormulaMl(Context c){
        int n=prefs(c).getInt("default_formula_ml",50);
        return validVolume(n)?n:50;
    }
    static int defaultForType(Context c,String type){
        return PUMPED.equals(type)?defaultPumpedMl(c):defaultFormulaMl(c);
    }
    static void setDefaultVolumes(Context c,int pumped,int formula){
        if(!validVolume(pumped)||!validVolume(formula))
            throw new IllegalArgumentException("5mL 단위로 5~1000mL를 선택하세요.");
        prefs(c).edit().putInt("default_pumped_ml",pumped)
            .putInt("default_formula_ml",formula).apply();
    }
    // Compatibility for generic legacy callers; use type-specific methods for feeds.
    static int defaultFeedMl(Context c){return defaultFormulaMl(c);}
    static void setFamily(Context c,String code,String name){prefs(c).edit().putString("family_code",code).putString("display_name",name).apply();}
    static FirebaseFirestore db(){return FirebaseFirestore.getInstance();}
    static String uid(){return FirebaseAuth.getInstance().getCurrentUser()==null?"":FirebaseAuth.getInstance().getCurrentUser().getUid();}
    static String randomCode(){SecureRandom random=new SecureRandom();StringBuilder b=new StringBuilder();for(int i=0;i<20;i++)b.append(CODES.charAt(random.nextInt(CODES.length())));return b.toString();}
    static boolean validCode(String code){return code.matches("^[A-HJ-NP-Z2-9]{20}$");}
    static boolean validType(String type){return BREAST.equals(type)||PUMPED.equals(type)||FORMULA.equals(type);}
    static boolean validSize(String size){return SMALL.equals(size)||MEDIUM.equals(size)||LARGE.equals(size);}
    static String typeLabel(String type){return BREAST.equals(type)?"모유":PUMPED.equals(type)?"유축":"mixed".equals(type)?"혼합":"분유";}
    static String kindLabel(String kind){return FEED.equals(kind)?"수유":POOP.equals(kind)?"대변":BOTH.equals(kind)?"소+대변":"소변";}
    static String icon(String kind){return FEED.equals(kind)?"🍼":POOP.equals(kind)?"💩":BOTH.equals(kind)?"💧💩":"💧";}
    static String sizeLabel(String size){return SMALL.equals(size)?"소":MEDIUM.equals(size)?"중":"대";}
    static Map<String,Object> event(Context c,String kind,String type,int ml,String size,long at,boolean legacy){
        Map<String,Object> data=new HashMap<>();
        data.put("kind",kind);data.put("feedType",type);data.put("ml",ml);data.put("size",size);
        data.put("createdBy",uid());data.put("who",name(c));data.put("at",new Timestamp(new Date(at)));
        data.put("source","android");data.put("legacy",legacy);return data;
    }
    static int knownMl(Map<String,Object> row){
        if(!FEED.equals(row.get("kind"))||Boolean.TRUE.equals(row.get("legacy")))return 0;
        Object obj=row.get("feedParts");
        if(obj instanceof Map){Map<?,?> p=(Map<?,?>)obj;return number(p.get("breastMl"))+number(p.get("pumpedMl"))+number(p.get("formulaMl"));}
        return Math.max(0,number(row.get("ml")));
    }
    static int number(Object value){return value instanceof Number?((Number)value).intValue():0;}
    static boolean unknownBreast(Map<String,Object> row){
        Object p=row.get("feedParts");if(p instanceof Map)return Boolean.TRUE.equals(((Map<?,?>)p).get("breastUnmeasured"));
        return BREAST.equals(row.get("feedType"))&&number(row.get("ml"))==-1;
    }
    static Map<String,Object> feedParts(int breast,int pumped,int formula,boolean unknown){
        Map<String,Object> p=new HashMap<>();p.put("breastMl",breast);p.put("pumpedMl",pumped);p.put("formulaMl",formula);p.put("breastUnmeasured",unknown);return p;
    }
    static String feedType(int breast,int pumped,int formula,boolean unknown){
        int c=(breast>0||unknown?1:0)+(pumped>0?1:0)+(formula>0?1:0);
        return c>1?"mixed":breast>0||unknown?BREAST:pumped>0?PUMPED:FORMULA;
    }
    static String detail(Map<String,Object> row){String kind=String.valueOf(row.get("kind"));
        if(Boolean.TRUE.equals(row.get("legacy")))return "이전 기록 · 상세 정보 없음";
        if(FEED.equals(kind)){
            Object parts=row.get("feedParts");
            if(!(parts instanceof Map)){
                int ml=number(row.get("ml"));return typeLabel(String.valueOf(row.get("feedType")))+" · "+(ml==-1?"양 미측정":ml+"mL");
            }
            Map<?,?> p=(Map<?,?>)parts;StringBuilder b=new StringBuilder();
            if(number(p.get("breastMl"))>0)b.append("모유 ").append(number(p.get("breastMl"))).append("mL · ");
            if(Boolean.TRUE.equals(p.get("breastUnmeasured")))b.append("모유 미측정 · ");
            if(number(p.get("pumpedMl"))>0)b.append("유축 ").append(number(p.get("pumpedMl"))).append("mL · ");
            if(number(p.get("formulaMl"))>0)b.append("분유 ").append(number(p.get("formulaMl"))).append("mL · ");
            b.append("합계 ").append(knownMl(row)).append("mL");return b.toString();
        }
        return "양 "+sizeLabel(String.valueOf(row.get("size")));
    }
    private FamilyStore(){}
}
