package com.agilog.local;

import com.google.firebase.firestore.DocumentSnapshot;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

/** Groups records by one hour anchored to the FIRST feed, not a sliding gap.
 *  Feed amounts and individual records are never combined or discarded. */
final class FeedSessions {
    static final long WINDOW_MS = 60L * 60L * 1000L;
    static final class Session {
        final long startedAt;
        boolean includesBreast;
        Session(long startedAt, boolean includesBreast) {
            this.startedAt=startedAt; this.includesBreast=includesBreast;
        }
    }
    private static boolean hasBreast(Map<String,Object> data) {
        if(data==null || Boolean.TRUE.equals(data.get("legacy")))return false;
        Object parts=data.get("feedParts");
        if(parts instanceof Map){
            Map<?,?> p=(Map<?,?>)parts;
            return FamilyStore.number(p.get("breastMl"))>0
                ||Boolean.TRUE.equals(p.get("breastUnmeasured"));
        }
        return FamilyStore.BREAST.equals(data.get("feedType"));
    }
    static ArrayList<Session> group(List<DocumentSnapshot> records) {
        ArrayList<DocumentSnapshot> feeds=new ArrayList<>();
        long now=System.currentTimeMillis();
        for(DocumentSnapshot d:records) {
            Date at=d.getDate("at");
            if(at!=null && at.getTime()<=now+300000L && FamilyStore.FEED.equals(d.getString("kind")))feeds.add(d);
        }
        Collections.sort(feeds, Comparator.comparingLong(d->d.getDate("at").getTime()));
        ArrayList<Session> sessions=new ArrayList<>();
        Session active=null;
        for(DocumentSnapshot d:feeds){
            long when=d.getDate("at").getTime();
            boolean breast=hasBreast(d.getData());
            // Exactly 60 minutes after the anchor begins a new feeding session.
            if(active==null || when-active.startedAt>=WINDOW_MS) {
                active=new Session(when,breast);sessions.add(active);
            }else if(breast)active.includesBreast=true;
        }
        return sessions;
    }
    private FeedSessions(){}
}
