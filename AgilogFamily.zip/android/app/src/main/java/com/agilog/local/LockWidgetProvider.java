package com.agilog.local;

/** Dedicated, compact app widget intended for Samsung Good Lock / LockStar or
 *  Android hosts that expose lock-screen AppWidgets. Android/Samsung controls
 *  which widgets are permitted and may require unlock before actions. */
public final class LockWidgetProvider extends HomeWidgetProvider { }
