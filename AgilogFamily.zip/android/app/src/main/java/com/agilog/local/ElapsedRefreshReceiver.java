package com.agilog.local;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Non-wakeup minute refresh; Android can batch it or pause during sleep. */
public final class ElapsedRefreshReceiver extends BroadcastReceiver {
    private static final String ACTION="com.agilog.local.MINUTE_REFRESH";
    private static PendingIntent pending(Context c) {
        Intent i=new Intent(c,ElapsedRefreshReceiver.class).setAction(ACTION);
        return PendingIntent.getBroadcast(c,43291,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static void schedule(Context c) {
        AlarmManager mgr=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(mgr==null)return;
        PendingIntent p=pending(c);
        mgr.cancel(p);
        if(!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c))return;
        long now=System.currentTimeMillis();
        long next=now+(60000L-now%60000L)+1500L;
        mgr.set(AlarmManager.RTC,next,p);
    }
    @Override public void onReceive(Context c,Intent intent) {
        if(intent==null||!ACTION.equals(intent.getAction()))return;
        if(QuickNotification.enabled(c))QuickNotification.show(c);
        HomeWidgetProvider.updateAll(c);
        schedule(c);
    }
}
