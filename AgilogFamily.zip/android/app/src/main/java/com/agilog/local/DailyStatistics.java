package com.agilog.local;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import com.google.firebase.firestore.DocumentSnapshot;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Calendar-day statistics using the device's local timezone. Nothing is written to Firestore. */
final class DailyStatistics {
    static final class Day {
        final Date date;
        int feedCount,breastCount,breastMl,pumpedMl,formulaMl,poop,pee,diapers,measured;
        Day(Date date){this.date=date;}
    }
    private static int part(Map<String,Object> item,String key,String originalType){
        if(Boolean.TRUE.equals(item.get("legacy")))return 0;
        Object parts=item.get("feedParts");
        if(parts instanceof Map)return Math.max(0,FamilyStore.number(((Map<?,?>)parts).get(key)));
        return originalType.equals(item.get("feedType"))?Math.max(0,FamilyStore.number(item.get("ml"))):0;
    }
    private static boolean breastPresent(Map<String,Object> item){
        if(Boolean.TRUE.equals(item.get("legacy")))return false;
        Object parts=item.get("feedParts");
        if(parts instanceof Map){Map<?,?> p=(Map<?,?>)parts;
            return FamilyStore.number(p.get("breastMl"))>0||Boolean.TRUE.equals(p.get("breastUnmeasured"));}
        return FamilyStore.BREAST.equals(item.get("feedType"));
    }
    static ArrayList<Day> collect(List<DocumentSnapshot> events,int length){
        ArrayList<Day> result=new ArrayList<>();
        HashMap<String,Day> byDate=new HashMap<>();
        Calendar day=Calendar.getInstance();
        day.set(Calendar.HOUR_OF_DAY,0);day.set(Calendar.MINUTE,0);day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);
        day.add(Calendar.DAY_OF_MONTH,1-length);
        SimpleDateFormat key=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        for(int i=0;i<length;i++){
            Date d=day.getTime();Day entry=new Day(d);result.add(entry);byDate.put(key.format(d),entry);
            day.add(Calendar.DAY_OF_MONTH,1);
        }
        long now=System.currentTimeMillis();
        for(DocumentSnapshot snap:events){
            Date date=snap.getDate("at");if(date==null||date.getTime()>now+300000L)continue;
            Day out=byDate.get(key.format(date));if(out==null)continue;
            String kind=snap.getString("kind");if(kind==null)continue;
            if(FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))out.poop++;
            if(FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))out.pee++;
            // A combined poop+pee event uses one physical diaper, never two.
            if(FamilyStore.POOP.equals(kind)||FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))out.diapers++;
            if(FamilyStore.FEED.equals(kind)){
                out.feedCount++;
                Map<String,Object> item=snap.getData();if(item==null)continue;
                out.measured+=FamilyStore.knownMl(item);
                if(breastPresent(item))out.breastCount++;
                out.breastMl+=part(item,"breastMl",FamilyStore.BREAST);
                out.pumpedMl+=part(item,"pumpedMl",FamilyStore.PUMPED);
                out.formulaMl+=part(item,"formulaMl",FamilyStore.FORMULA);
            }
        }
        return result;
    }
    /** Scrollable, battery-friendly Canvas chart. Draws only when the statistics screen is visible. */
    static final class GraphView extends View {
        private final ArrayList<Day> days;
        private final boolean milk;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        GraphView(Context context,ArrayList<Day> data,boolean milk){super(context);this.days=data;this.milk=milk;
            setContentDescription(milk?"일별 수유량 그래프":"일별 기저귀 개수 그래프");}
        private float dp(float n){return n*getResources().getDisplayMetrics().density;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);
            final float left=dp(38),top=dp(14),bottom=getHeight()-dp(30),right=getWidth()-dp(10);
            if(right<=left||days.isEmpty())return;
            int maximum=1;
            for(Day d:days)maximum=Math.max(maximum,milk?d.breastMl+d.pumpedMl+d.formulaMl:d.diapers);
            int scale=Math.max(1,(int)Math.ceil(maximum/4.0));int limit=scale*4;
            paint.setStrokeWidth(dp(1));paint.setTextSize(dp(10));
            paint.setTextAlign(Paint.Align.RIGHT);
            for(int i=0;i<=4;i++){
                float y=bottom-(bottom-top)*i/4f;
                paint.setColor(0xFFEFE4E7);c.drawLine(left,y,right,y,paint);
                paint.setColor(0xFF937E87);c.drawText(String.valueOf(i*scale),left-dp(5),y+dp(3),paint);
            }
            paint.setTextAlign(Paint.Align.CENTER);
            float unit=(right-left)/days.size();float w=Math.min(dp(28),unit*.65f);
            for(int i=0;i<days.size();i++){
                Day d=days.get(i);float x=left+(i+.5f)*unit;float base=bottom;
                if(milk){
                    base=drawBar(c,x,base,w,d.formulaMl,limit,top,bottom,0xFFD88692);
                    base=drawBar(c,x,base,w,d.pumpedMl,limit,top,bottom,0xFF77A6D5);
                    base=drawBar(c,x,base,w,d.breastMl,limit,top,bottom,0xFFEAC276);
                }else{base=drawBar(c,x,base,w,d.diapers,limit,top,bottom,0xFF69B59F);}
                paint.setColor(0xFF806C76);paint.setTextSize(dp(10));
                c.drawText(String.valueOf(d.date.getDate()),x,bottom+dp(16),paint);
                if(!milk&&d.diapers>0)c.drawText(String.valueOf(d.diapers),x,Math.max(top+dp(9),base-dp(4)),paint);
            }
        }
        private float drawBar(Canvas c,float x,float base,float w,int amount,int limit,float top,float bottom,int color){
            if(amount<=0)return base;
            float h=(bottom-top)*amount/limit;paint.setColor(color);
            c.drawRect(x-w/2,base-h,x+w/2,base,paint);return base-h;
        }
    }
    private DailyStatistics(){}
}
