package com.agilog.local;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.Toast;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

/** Resizable Samsung/Android home-screen widget. Every widget has its own entry state. */
public class HomeWidgetProvider extends AppWidgetProvider {
    private static final String CLICK="com.agilog.local.HOME_WIDGET_CLICK";
    private static final String WIDGET="agi_widget_";
    private static final String MODE="mode", TYPE="type", KIND="kind", ML="ml", OFFSET="offset", ANCHOR="anchor";
    private static final String MIX_STEP="mix_step", MIX_BREAST="mix_breast", MIX_PUMPED="mix_pumped", MIX_FORMULA="mix_formula", MIX_UNKNOWN="mix_unknown";
    private static final String MAIN="main",TYPES="types",AMOUNT="amount",MIX="mix",DIAPER="diaper",TIME="time";
    private static final int[] BUTTONS={R.id.widget_btn0,R.id.widget_btn1,R.id.widget_btn2,R.id.widget_btn3};

    static boolean hasWidgets(Context context){
        AppWidgetManager am=AppWidgetManager.getInstance(context);
        return am.getAppWidgetIds(new ComponentName(context,HomeWidgetProvider.class)).length>0
            || am.getAppWidgetIds(new ComponentName(context,LockWidgetProvider.class)).length>0;
    }
    static void updateAll(Context context){
        AppWidgetManager am=AppWidgetManager.getInstance(context);
        for(int id:am.getAppWidgetIds(new ComponentName(context,HomeWidgetProvider.class))) update(context,am,id);
        for(int id:am.getAppWidgetIds(new ComponentName(context,LockWidgetProvider.class))) update(context,am,id);
    }
    @Override public void onEnabled(Context context){
        QuickStatsWorker.schedule(context);
        QuickStatsWorker.request(context);
        ElapsedRefreshReceiver.schedule(context);
    }
    @Override public void onUpdate(Context context,AppWidgetManager manager,int[] ids){
        for(int id:ids)update(context,manager,id);
        QuickStatsWorker.schedule(context);
        QuickStatsWorker.request(context);
        ElapsedRefreshReceiver.schedule(context);
    }
    @Override public void onAppWidgetOptionsChanged(Context context,AppWidgetManager manager,int id,Bundle options){
        super.onAppWidgetOptionsChanged(context,manager,id,options);
        update(context,manager,id);
    }
    @Override public void onDeleted(Context context,int[] ids){
        SharedPreferences.Editor e=FamilyStore.prefs(context).edit();
        for(int id:ids){for(String suffix:new String[]{MODE,TYPE,KIND,ML,OFFSET,ANCHOR,"unknown",MIX_STEP,MIX_BREAST,MIX_PUMPED,MIX_FORMULA,MIX_UNKNOWN}) e.remove(key(id,suffix));}
        e.apply();
        if(!hasWidgets(context)&&!QuickNotification.enabled(context))QuickStatsWorker.unschedule(context);
        ElapsedRefreshReceiver.schedule(context);
    }
    @Override public void onReceive(Context context,Intent intent){
        super.onReceive(context,intent);
        if(intent!=null&&CLICK.equals(intent.getAction())){
            int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
            String action=intent.getStringExtra("command");
            if(id!=AppWidgetManager.INVALID_APPWIDGET_ID&&action!=null)handle(context,id,action);
        }
    }
    private static String key(int id,String name){return WIDGET+id+"_"+name;}
    private static String text(Context c,int id,String name,String fallback){return FamilyStore.prefs(c).getString(key(id,name),fallback);}
    private static int number(Context c,int id,String name,int fallback){return FamilyStore.prefs(c).getInt(key(id,name),fallback);}
    private static PendingIntent command(Context c,int id,int slot,String action){
        Intent i=new Intent(c,HomeWidgetProvider.class).setAction(CLICK)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).putExtra("command",action);
        return PendingIntent.getBroadcast(c,id*32+slot,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent openApp(Context c,int id,boolean feed){
        Intent i=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if(feed)i.putExtra("open_feed_from_widget",true);
        return PendingIntent.getActivity(c,id*32+(feed?30:29),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static boolean isLockWidget(Context c,int id){
        int[] ids=AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,LockWidgetProvider.class));
        for(int other:ids) if(other==id) return true;
        return false;
    }
    private static void update(Context c,AppWidgetManager manager,int id){
        boolean lock=isLockWidget(c,id);
        RemoteViews views=new RemoteViews(c.getPackageName(),lock?R.layout.lock_widget:R.layout.home_widget);
        QuickStats.Summary stats=QuickStats.get(c);
        boolean linked=!FamilyStore.code(c).isEmpty();
        views.setTextViewText(R.id.widget_today,stats.synced
            ?"오늘  모유 "+stats.todayBreastCount+"회  ·  유축 "+stats.todayPumpedMl+"  ·  분유 "+stats.todayFormulaMl
            :"오늘  가족 기록 동기화 대기");
        views.setTextViewText(R.id.widget_yesterday,stats.synced
            ?"어제  모유 "+stats.yesterdayBreastCount+"회  ·  유축 "+stats.yesterdayPumpedMl+"  ·  분유 "+stats.yesterdayFormulaMl
            :"어제  가족 기록 동기화 대기");
        views.setTextViewText(R.id.widget_elapsed,ElapsedTime.display(stats.lastFeed)+" · "+stats.lastFeedAmount);
        views.setTextViewText(R.id.widget_previous_feed,"이전 수유 후 "+ElapsedTime.display(stats.previousFeed)+" · "+stats.previousFeedAmount);
        views.setViewVisibility(R.id.widget_elapsed,View.VISIBLE);
        views.setViewVisibility(R.id.widget_no_feed,View.GONE);
        views.setTextViewText(R.id.widget_diaper,
            "💩 대변 " + ElapsedTime.display(stats.lastPoop)
                + "    💧 소변 " + ElapsedTime.display(stats.lastPee));
        String mode=text(c,id,MODE,MAIN),kind=text(c,id,KIND,FamilyStore.PEE);
        String[] labels;String[] actions;
        String hint="기록 버튼을 눌러주세요";
        if(!linked){
            hint="먼저 앱에서 가족을 연결해주세요";
            labels=new String[]{"아기로그 열기"};actions=new String[]{"open"};
        }else if(TYPES.equals(mode)){
            hint="수유 종류 선택 · 혼합도 위젯에서 기록";
            labels=new String[]{"모유","유축","분유","혼합"};
            actions=new String[]{"breast","pumped","formula","mixed"};
        }else if(AMOUNT.equals(mode)){
            String type=text(c,id,TYPE,FamilyStore.FORMULA);
            int ml=number(c,id,ML,70);
            hint=FamilyStore.typeLabel(type)+" "+ml+"mL · 5mL 단위 조절";
            labels=new String[]{"−5mL","+5mL","다음",FamilyStore.BREAST.equals(type)?"양 미측정":"취소"};
            actions=new String[]{"minus","plus","next",FamilyStore.BREAST.equals(type)?"unknown":"cancel"};
        }else if(MIX.equals(mode)){
            int step=number(c,id,MIX_STEP,0);
            String part=step==0?"유축":"분유";
            int amount=number(c,id,mixField(step),step==0?0:70);
            int pumped=number(c,id,MIX_PUMPED,0),formula=number(c,id,MIX_FORMULA,70);
            hint="혼합 · "+part+" "+amount+"mL (유축 "+pumped+" + 분유 "+formula+")";
            labels=new String[]{"−5mL","+5mL","0mL",step==0?"분유 입력":"시간 선택"};
            actions=new String[]{"mix_minus","mix_plus","mix_zero","mix_next"};
        }else if(TIME.equals(mode)){
            int offset=number(c,id,OFFSET,0);
            long anchor=FamilyStore.prefs(c).getLong(key(id,ANCHOR),System.currentTimeMillis());
            String hhmm=new SimpleDateFormat("HH:mm",Locale.KOREA).format(new Date(anchor-offset*60000L));
            hint="기록 시각 "+hhmm+" · 누적 "+offset+"분 전";
            labels=new String[]{"지금 저장","−5분",offset+"분 전","이전 저장"};
            actions=new String[]{"now","earlier","info","prior"};
        }else if(DIAPER.equals(mode)){
            hint=FamilyStore.kindLabel(kind)+" · 기저귀 양 선택";
            labels=new String[]{"소","중","대","취소"};
            actions=new String[]{"small","medium","large","cancel"};
        }else{
            labels=new String[]{"🍼 수유","💧 소변","💩 대변","💧💩"};
            actions=new String[]{"feed","pee","poop","both"};
        }
        // LockStar widgets have a smaller host area: keep one concise status line.
        if(lock){
            if(MAIN.equals(mode)) hint="수유 / 소변 / 대변 / 동시 기록";
            else if(TYPES.equals(mode)) hint="수유 종류 선택";
            else if(AMOUNT.equals(mode)) hint=FamilyStore.typeLabel(text(c,id,TYPE,FamilyStore.FORMULA))+" "+number(c,id,ML,70)+"mL";
            else if(MIX.equals(mode)){
                int step=number(c,id,MIX_STEP,0);
                hint="혼합 "+(step==0?"유축":"분유")+" " +number(c,id,mixField(step),step==0?0:70)+"mL (총 "+mixTotal(c,id)+"mL)";
            }
            else if(DIAPER.equals(mode)) hint="기저귀 양 선택";
        }
        views.setTextViewText(R.id.widget_state,hint);
        views.setViewVisibility(R.id.widget_back,MAIN.equals(mode)||!linked?View.GONE:View.VISIBLE);
        views.setOnClickPendingIntent(R.id.widget_back,command(c,id,10,"back"));
        views.setOnClickPendingIntent(R.id.widget_open,openApp(c,id,false));
        for(int pos=0;pos<4;pos++){
            boolean visible=pos<labels.length;
            views.setViewVisibility(BUTTONS[pos],visible?View.VISIBLE:View.GONE);
            if(!visible)continue;
            views.setTextViewText(BUTTONS[pos],labels[pos]);
            if("info".equals(actions[pos])) views.setOnClickPendingIntent(BUTTONS[pos],null);
            else if("open".equals(actions[pos]))views.setOnClickPendingIntent(BUTTONS[pos],openApp(c,id,false));
            else views.setOnClickPendingIntent(BUTTONS[pos],command(c,id,pos,actions[pos]));
        }
        manager.updateAppWidget(id,views);
    }
    private static String mixField(int step){return step==0?MIX_PUMPED:MIX_FORMULA;}
    private static int mixTotal(Context c,int id){return number(c,id,MIX_PUMPED,0)+number(c,id,MIX_FORMULA,70);}
    private static void update(Context c,int id){update(c,AppWidgetManager.getInstance(c),id);}
    private static void handle(Context c,int id,String action){
        if(FamilyStore.code(c).isEmpty()){update(c,id);return;}
        String mode=text(c,id,MODE,MAIN);
        SharedPreferences.Editor e=FamilyStore.prefs(c).edit();
        if("back".equals(action)||"cancel".equals(action)){
            if(TIME.equals(mode)) e.putString(key(id,MODE),"mixed".equals(text(c,id,TYPE,""))?MIX:AMOUNT);
            else if(MIX.equals(mode)){
                int step=number(c,id,MIX_STEP,0);
                if(step>0)e.putInt(key(id,MIX_STEP),step-1);
                else e.putString(key(id,MODE),TYPES);
            }else if(AMOUNT.equals(mode))e.putString(key(id,MODE),TYPES);
            else e.putString(key(id,MODE),MAIN);
        }else if(MAIN.equals(mode)){
            if("feed".equals(action))e.putString(key(id,MODE),TYPES);
            else if("pee".equals(action)||"poop".equals(action)||"both".equals(action)){
                e.putString(key(id,MODE),DIAPER).putString(key(id,KIND),action);
            }else return;
        }else if(TYPES.equals(mode)){
            if("mixed".equals(action)){
                e.putString(key(id,MODE),MIX).putString(key(id,TYPE),"mixed")
                    .putInt(key(id,MIX_STEP),0).putInt(key(id,MIX_BREAST),0)
                    .putInt(key(id,MIX_PUMPED),0).putInt(key(id,MIX_FORMULA),70)
                    .putBoolean(key(id,MIX_UNKNOWN),false);
            }else if(FamilyStore.validType(action)){
                e.putString(key(id,MODE),AMOUNT).putString(key(id,TYPE),action).putInt(key(id,ML),70);
            }else return;
        }else if(MIX.equals(mode)){
            int step=number(c,id,MIX_STEP,0);
            String field=mixField(step);
            int value=number(c,id,field,step==0?0:70);
            if("mix_minus".equals(action))e.putInt(key(id,field),Math.max(0,value-5));
            else if("mix_plus".equals(action)){
                if(mixTotal(c,id)+5>1000)return;
                e.putInt(key(id,field),Math.min(1000,value+5));
            }else if("mix_zero".equals(action))e.putInt(key(id,field),0);
            else if("mix_next".equals(action)){
                if(step==0){
                    if(number(c,id,MIX_PUMPED,0)<5){
                        Toast.makeText(c,"혼합 수유는 유축을 5mL 이상 입력하세요.",Toast.LENGTH_SHORT).show();return;
                    }
                    e.putInt(key(id,MIX_STEP),1);
                }else{
                    if(number(c,id,MIX_FORMULA,70)<5||mixTotal(c,id)>1000){
                        Toast.makeText(c,"혼합 수유는 분유를 5mL 이상, 합계 1000mL 이하로 입력하세요.",Toast.LENGTH_SHORT).show();return;
                    }
                    e.putString(key(id,MODE),TIME).putLong(key(id,ANCHOR),System.currentTimeMillis()).putInt(key(id,OFFSET),0);
                }
            }else return;
        }else if(AMOUNT.equals(mode)){
            int ml=number(c,id,ML,70);
            if("minus".equals(action))e.putInt(key(id,ML),Math.max(5,ml-5));
            else if("plus".equals(action))e.putInt(key(id,ML),Math.min(1000,ml+5));
            else if("next".equals(action)||"unknown".equals(action)){
                if("unknown".equals(action)&&!FamilyStore.BREAST.equals(text(c,id,TYPE,FamilyStore.FORMULA)))return;
                e.putString(key(id,MODE),TIME).putLong(key(id,ANCHOR),System.currentTimeMillis())
                    .putInt(key(id,OFFSET),0).putBoolean(key(id,"unknown"),"unknown".equals(action));
            }else return;
        }else if(TIME.equals(mode)){
            int offset=number(c,id,OFFSET,0);
            if("earlier".equals(action))e.putInt(key(id,OFFSET),Math.min(24*60,offset+5));
            else if("now".equals(action)||"prior".equals(action)){
                if("prior".equals(action)&&offset==0)return;
                long at="now".equals(action)?System.currentTimeMillis()
                    :FamilyStore.prefs(c).getLong(key(id,ANCHOR),System.currentTimeMillis())-offset*60000L;
                String type=text(c,id,TYPE,FamilyStore.FORMULA);
                boolean unknown=FamilyStore.prefs(c).getBoolean(key(id,"unknown"),false);
                if("mixed".equals(type)){
                    RecordWorker.queueParts(c,0,number(c,id,MIX_PUMPED,0),
                        number(c,id,MIX_FORMULA,70),false,at);
                }else{
                    int volume=unknown?0:number(c,id,ML,70);
                    RecordWorker.queueParts(c,FamilyStore.BREAST.equals(type)?volume:0,
                        FamilyStore.PUMPED.equals(type)?volume:0,FamilyStore.FORMULA.equals(type)?volume:0,unknown,at);
                }
                e.putString(key(id,MODE),MAIN);
            }else return;
        }else if(DIAPER.equals(mode)){
            if(!FamilyStore.validSize(action))return;
            RecordWorker.queue(c,text(c,id,KIND,FamilyStore.PEE),"",0,action);
            e.putString(key(id,MODE),MAIN);
        }else return;
        e.apply();update(c,id);
        ElapsedRefreshReceiver.schedule(c);
    }
}
