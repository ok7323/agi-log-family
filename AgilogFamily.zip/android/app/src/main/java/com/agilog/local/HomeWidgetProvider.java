package com.agilog.local;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

/** Resizable Samsung/Android home-screen widget. Every widget has its own entry state. */
public final class HomeWidgetProvider extends AppWidgetProvider {
    private static final String CLICK="com.agilog.local.HOME_WIDGET_CLICK";
    private static final String WIDGET="agi_widget_";
    private static final String MODE="mode", TYPE="type", KIND="kind", ML="ml", OFFSET="offset", ANCHOR="anchor";
    private static final String MAIN="main",TYPES="types",AMOUNT="amount",DIAPER="diaper",TIME="time";
    private static final int[] BUTTONS={R.id.widget_btn0,R.id.widget_btn1,R.id.widget_btn2,R.id.widget_btn3};

    static boolean hasWidgets(Context context){
        AppWidgetManager am=AppWidgetManager.getInstance(context);
        return am.getAppWidgetIds(new ComponentName(context,HomeWidgetProvider.class)).length>0;
    }
    static void updateAll(Context context){
        AppWidgetManager am=AppWidgetManager.getInstance(context);
        for(int id:am.getAppWidgetIds(new ComponentName(context,HomeWidgetProvider.class))) update(context,am,id);
    }
    @Override public void onEnabled(Context context){
        QuickStatsWorker.schedule(context);
        QuickStatsWorker.request(context);
    }
    @Override public void onUpdate(Context context,AppWidgetManager manager,int[] ids){
        for(int id:ids)update(context,manager,id);
        QuickStatsWorker.schedule(context);
        QuickStatsWorker.request(context);
    }
    @Override public void onAppWidgetOptionsChanged(Context context,AppWidgetManager manager,int id,Bundle options){
        super.onAppWidgetOptionsChanged(context,manager,id,options);
        update(context,manager,id);
    }
    @Override public void onDeleted(Context context,int[] ids){
        SharedPreferences.Editor e=FamilyStore.prefs(context).edit();
        for(int id:ids){for(String suffix:new String[]{MODE,TYPE,KIND,ML,OFFSET,ANCHOR,"unknown"}) e.remove(key(id,suffix));}
        e.apply();
        if(!hasWidgets(context)&&!QuickNotification.enabled(context))QuickStatsWorker.unschedule(context);
    }
    @Override public void onReceive(Context context,Intent intent){
        super.onReceive(context,intent);
        if(intent!=null&&CLICK.equals(intent.getAction())){
            int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
            String action=intent.getStringExtra("command");
            if(id!=AppWidgetManager.INVALID_APPWIDGET_ID&&action!=null)handle(context,id,action);
        }
    }
    private static String key(int id,String name){return WIDGET+id+"_"+name;}
    private static String text(Context c,int id,String name,String fallback){return FamilyStore.prefs(c).getString(key(id,name),fallback);}
    private static int number(Context c,int id,String name,int fallback){return FamilyStore.prefs(c).getInt(key(id,name),fallback);}
    private static PendingIntent command(Context c,int id,int slot,String action){
        Intent i=new Intent(c,HomeWidgetProvider.class).setAction(CLICK)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).putExtra("command",action);
        return PendingIntent.getBroadcast(c,id*32+slot,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent openApp(Context c,int id,boolean feed){
        Intent i=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if(feed)i.putExtra("open_feed_from_widget",true);
        return PendingIntent.getActivity(c,id*32+(feed?30:29),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void update(Context c,AppWidgetManager manager,int id){
        RemoteViews views=new RemoteViews(c.getPackageName(),R.layout.home_widget);
        QuickStats.Summary stats=QuickStats.get(c);
        boolean linked=!FamilyStore.code(c).isEmpty();
        views.setTextViewText(R.id.widget_today,stats.synced
            ?"오늘  모유 "+stats.todayBreastCount+"회   |   유축+분유 "+stats.todayOtherMl+"mL":"오늘  가족 기록 동기화 대기");
        views.setTextViewText(R.id.widget_yesterday,stats.synced
            ?"어제  모유 "+stats.yesterdayBreastCount+"회   |   유축+분유 "+stats.yesterdayOtherMl+"mL":"어제  가족 기록 동기화 대기");
        if(stats.lastFeed>0){
            long elapsed=Math.max(0,System.currentTimeMillis()-stats.lastFeed);
            views.setViewVisibility(R.id.widget_elapsed,View.VISIBLE);
            views.setViewVisibility(R.id.widget_no_feed,View.GONE);
            views.setChronometer(R.id.widget_elapsed,SystemClock.elapsedRealtime()-elapsed,null,true);
        }else{
            views.setViewVisibility(R.id.widget_elapsed,View.GONE);
            views.setViewVisibility(R.id.widget_no_feed,View.VISIBLE);
            views.setTextViewText(R.id.widget_no_feed,"기록 없음");
        }
        String mode=text(c,id,MODE,MAIN),kind=text(c,id,KIND,FamilyStore.PEE);
        String[] labels;String[] actions;
        String hint="기록 버튼을 눌러주세요";
        if(!linked){
            hint="먼저 앱에서 가족을 연결해주세요";
            labels=new String[]{"아기로그 열기"};actions=new String[]{"open"};
        }else if(TYPES.equals(mode)){
            hint="수유 종류 선택 · 혼합은 앱에서 입력";
            labels=new String[]{"모유","유축","분유","혼합 입력"};
            actions=new String[]{"breast","pumped","formula","mixed"};
        }else if(AMOUNT.equals(mode)){
            String type=text(c,id,TYPE,FamilyStore.FORMULA);
            int ml=number(c,id,ML,70);
            hint=FamilyStore.typeLabel(type)+" "+ml+"mL · 5mL 단위 조절";
            labels=new String[]{"−5mL","+5mL","다음",FamilyStore.BREAST.equals(type)?"양 미측정":"취소"};
            actions=new String[]{"minus","plus","next",FamilyStore.BREAST.equals(type)?"unknown":"cancel"};
        }else if(TIME.equals(mode)){
            int offset=number(c,id,OFFSET,0);
            long anchor=FamilyStore.prefs(c).getLong(key(id,ANCHOR),System.currentTimeMillis());
            String hhmm=new SimpleDateFormat("HH:mm",Locale.KOREA).format(new Date(anchor-offset*60000L));
            hint="기록 시각 "+hhmm+" · 누적 "+offset+"분 전";
            labels=new String[]{"지금 저장","−5분",offset+"분 전","이전 저장"};
            actions=new String[]{"now","earlier","info","prior"};
        }else if(DIAPER.equals(mode)){
            hint=FamilyStore.kindLabel(kind)+" · 기저귀 양 선택";
            labels=new String[]{"소","중","대","취소"};
            actions=new String[]{"small","medium","large","cancel"};
        }else{
            labels=new String[]{"🍼 수유","💧 소변","💩 대변","💧💩"};
            actions=new String[]{"feed","pee","poop","both"};
        }
        views.setTextViewText(R.id.widget_state,hint);
        views.setViewVisibility(R.id.widget_back,MAIN.equals(mode)||!linked?View.GONE:View.VISIBLE);
        views.setOnClickPendingIntent(R.id.widget_back,command(c,id,10,"back"));
        views.setOnClickPendingIntent(R.id.widget_open,openApp(c,id,false));
        for(int pos=0;pos<4;pos++){
            boolean visible=pos<labels.length;
            views.setViewVisibility(BUTTONS[pos],visible?View.VISIBLE:View.GONE);
            if(!visible)continue;
            views.setTextViewText(BUTTONS[pos],labels[pos]);
            if(!"info".equals(actions[pos])){
                if("mixed".equals(actions[pos]))views.setOnClickPendingIntent(BUTTONS[pos],openApp(c,id,true));
                else if("open".equals(actions[pos]))views.setOnClickPendingIntent(BUTTONS[pos],openApp(c,id,false));
                else views.setOnClickPendingIntent(BUTTONS[pos],command(c,id,pos,actions[pos]));
            }
        }
        manager.updateAppWidget(id,views);
    }
    private static void update(Context c,int id){update(c,AppWidgetManager.getInstance(c),id);}
    private static void handle(Context c,int id,String action){
        if(FamilyStore.code(c).isEmpty()){update(c,id);return;}
        String mode=text(c,id,MODE,MAIN);
        SharedPreferences.Editor e=FamilyStore.prefs(c).edit();
        if("back".equals(action)||"cancel".equals(action)){
            String previous=TIME.equals(mode)?AMOUNT:AMOUNT.equals(mode)?TYPES:MAIN;
            e.putString(key(id,MODE),previous);
        }else if(MAIN.equals(mode)){
            if("feed".equals(action))e.putString(key(id,MODE),TYPES);
            else if("pee".equals(action)||"poop".equals(action)||"both".equals(action)){
                e.putString(key(id,MODE),DIAPER).putString(key(id,KIND),action);
            }else return;
        }else if(TYPES.equals(mode)){
            if(!FamilyStore.validType(action))return;
            e.putString(key(id,MODE),AMOUNT).putString(key(id,TYPE),action).putInt(key(id,ML),70);
        }else if(AMOUNT.equals(mode)){
            int ml=number(c,id,ML,70);
            if("minus".equals(action))e.putInt(key(id,ML),Math.max(5,ml-5));
            else if("plus".equals(action))e.putInt(key(id,ML),Math.min(1000,ml+5));
            else if("next".equals(action)||"unknown".equals(action)){
                if("unknown".equals(action)&&!FamilyStore.BREAST.equals(text(c,id,TYPE,FamilyStore.FORMULA)))return;
                e.putString(key(id,MODE),TIME).putLong(key(id,ANCHOR),System.currentTimeMillis())
                    .putInt(key(id,OFFSET),0).putBoolean(key(id,"unknown"),"unknown".equals(action));
            }else return;
        }else if(TIME.equals(mode)){
            int offset=number(c,id,OFFSET,0);
            if("earlier".equals(action))e.putInt(key(id,OFFSET),Math.min(24*60,offset+5));
            else if("now".equals(action)||"prior".equals(action)){
                if("prior".equals(action)&&offset==0)return;
                long at="now".equals(action)?System.currentTimeMillis()
                    :FamilyStore.prefs(c).getLong(key(id,ANCHOR),System.currentTimeMillis())-offset*60000L;
                String type=text(c,id,TYPE,FamilyStore.FORMULA);
                boolean unknown=FamilyStore.prefs(c).getBoolean(key(id,"unknown"),false);
                int volume=unknown?0:number(c,id,ML,70);
                RecordWorker.queueParts(c,FamilyStore.BREAST.equals(type)?volume:0,
                    FamilyStore.PUMPED.equals(type)?volume:0,FamilyStore.FORMULA.equals(type)?volume:0,unknown,at);
                e.putString(key(id,MODE),MAIN);
            }else return;
        }else if(DIAPER.equals(mode)){
            if(!FamilyStore.validSize(action))return;
            RecordWorker.queue(c,text(c,id,KIND,FamilyStore.PEE),"",0,action);
            e.putString(key(id,MODE),MAIN);
        }else return;
        e.apply();update(c,id);
    }
}
