package com.agilog.local;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.WorkManager;
import androidx.work.PeriodicWorkRequest;
import androidx.work.OneTimeWorkRequest;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Source;
import java.util.concurrent.TimeUnit;

/** Background refresh: Android may delay this work while the phone is idle. */
public final class QuickStatsWorker extends Worker {
    private static final String PERIODIC="agi-quick-summary-periodic";
    private static final String ONCE="agi-quick-summary-refresh";
    public QuickStatsWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    private static Constraints connected(){return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();}
    static void schedule(Context c){
        PeriodicWorkRequest task=new PeriodicWorkRequest.Builder(QuickStatsWorker.class,15,TimeUnit.MINUTES)
            .setConstraints(connected()).build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(PERIODIC,ExistingPeriodicWorkPolicy.KEEP,task);
    }
    static void unschedule(Context c){WorkManager.getInstance(c).cancelUniqueWork(PERIODIC);WorkManager.getInstance(c).cancelUniqueWork(ONCE);}
    static void request(Context c){
        if((!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c))||FamilyStore.code(c).isEmpty())return;
        OneTimeWorkRequest task=new OneTimeWorkRequest.Builder(QuickStatsWorker.class).setConstraints(connected()).build();
        WorkManager.getInstance(c).enqueueUniqueWork(ONCE,ExistingWorkPolicy.REPLACE,task);
    }
    // Background query runs on a WorkManager thread, never on the UI/broadcast thread.
    static boolean refreshNow(Context c,String code) throws Exception {
        if(code.isEmpty()||!code.equals(FamilyStore.code(c))
            ||(!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c)))return false;
        if(FamilyStore.uid().isEmpty())return false;
        QuerySnapshot snap=Tasks.await(FamilyStore.db().collection("families").document(code)
            .collection("events").orderBy("at",Query.Direction.DESCENDING).get(Source.SERVER),30,TimeUnit.SECONDS);
        if(!code.equals(FamilyStore.code(c)))return false;
        QuickStats.update(c,snap.getDocuments());
        QuickNotification.show(c);
        HomeWidgetProvider.updateAll(c);
        return true;
    }
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();String code=FamilyStore.code(c);
        if((!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c))||code.isEmpty())return Result.success();
        if(MainActivity.isForeground() || FastFamilySyncService.running())return Result.success(); // A live snapshot listener is active.
        if(FamilyStore.uid().isEmpty())return Result.retry();
        try{return refreshNow(c,code)?Result.success():Result.retry();}
        catch(Exception ex){return Result.retry();}
    }
}
