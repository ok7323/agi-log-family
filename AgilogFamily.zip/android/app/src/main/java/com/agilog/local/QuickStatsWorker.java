package com.agilog.local;

import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.WorkManager;
import androidx.work.PeriodicWorkRequest;
import androidx.work.OneTimeWorkRequest;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Source;
import com.google.firebase.Timestamp;
import java.util.Date;
import androidx.work.OutOfQuotaPolicy;
import java.util.concurrent.TimeUnit;

/** Background refresh: Android may delay this work while the phone is idle. */
public final class QuickStatsWorker extends Worker {
    private static final String PERIODIC="agi-quick-summary-periodic";
    private static final String ONCE="agi-quick-summary-refresh";
    private static final String MANUAL="agi-widget-manual-refresh";
    private static final String IS_MANUAL="widget_manual_refresh";
    public QuickStatsWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    private static Constraints connected(){return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();}
    static void schedule(Context c){
        PeriodicWorkRequest task=new PeriodicWorkRequest.Builder(QuickStatsWorker.class,30,TimeUnit.MINUTES)
            .setConstraints(connected()).build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(PERIODIC,ExistingPeriodicWorkPolicy.UPDATE,task);
    }
    static void unschedule(Context c){
        WorkManager wm=WorkManager.getInstance(c);
        wm.cancelUniqueWork(PERIODIC);
        wm.cancelUniqueWork(ONCE);
        wm.cancelUniqueWork(MANUAL);
    }
    static void request(Context c){
        if((!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c))||FamilyStore.code(c).isEmpty())return;
        OneTimeWorkRequest task=new OneTimeWorkRequest.Builder(QuickStatsWorker.class).setConstraints(connected()).build();
        WorkManager.getInstance(c).enqueueUniqueWork(ONCE,ExistingWorkPolicy.REPLACE,task);
    }
    /** User-triggered refresh bypasses the foreground-service shortcut and fetches
     *  from Firestore SERVER. A separate work name avoids disrupting periodic sync. */
    static void requestManual(Context c){
        if(!HomeWidgetProvider.hasWidgets(c)||!FamilyStore.validCode(FamilyStore.code(c)))return;
        Data input=new Data.Builder().putBoolean(IS_MANUAL,true).build();
        OneTimeWorkRequest.Builder builder=new OneTimeWorkRequest.Builder(QuickStatsWorker.class)
            .setInputData(input).setConstraints(connected());
        // Android 12+ expedited jobs start promptly. Older versions use ordinary
        // OneTimeWork so a foreground-info implementation is not required.
        if(Build.VERSION.SDK_INT>=31)builder.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST);
        OneTimeWorkRequest task=builder.build();
        WorkManager.getInstance(c).enqueueUniqueWork(MANUAL,ExistingWorkPolicy.REPLACE,task);
    }
    // Background query runs on a WorkManager thread, never on the UI/broadcast thread.
    static boolean refreshNow(Context c,String code) throws Exception {
        if(code.isEmpty()||!code.equals(FamilyStore.code(c))
            ||(!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c)))return false;
        if(FamilyStore.uid().isEmpty())return false;
        QuerySnapshot snap=Tasks.await(FamilyStore.db().collection("families").document(code)
            .collection("events")
            .whereGreaterThanOrEqualTo("at",new Timestamp(new Date(System.currentTimeMillis()-QuickStats.RECENT_MS)))
            .orderBy("at",Query.Direction.DESCENDING).get(Source.SERVER),30,TimeUnit.SECONDS);
        if(!code.equals(FamilyStore.code(c)))return false;
        QuickStats.updateRecent(c,snap.getDocuments());
        QuickNotification.show(c);
        HomeWidgetProvider.updateAll(c);
        return true;
    }
    private static void manualFinished(Context c,String message){
        FamilyStore.prefs(c).edit().putBoolean("widget_refresh_busy",false)
            .putString("widget_refresh_status",message)
            .putLong("widget_refresh_status_at",System.currentTimeMillis()).apply();
        HomeWidgetProvider.updateAll(c);
    }
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();String code=FamilyStore.code(c);
        boolean manual=getInputData().getBoolean(IS_MANUAL,false);
        if((!QuickNotification.enabled(c)&&!HomeWidgetProvider.hasWidgets(c))||code.isEmpty()){
            if(manual)manualFinished(c,"갱신 실패 · 위젯/가족 연결 확인");
            return Result.success();
        }
        if(!manual&&(MainActivity.isForeground()||FastFamilySyncService.running()))return Result.success(); // Live listener handles ordinary refreshes.
        if(FamilyStore.uid().isEmpty()){
            if(manual)manualFinished(c,"갱신 실패 · 앱에서 로그인 확인");
            return manual?Result.failure():Result.retry();
        }
        try{
            boolean ok=refreshNow(c,code);
            if(manual)manualFinished(c,ok?"✓ 최신 기록 확인":"갱신 실패 · 가족 연결 확인");
            return ok?Result.success():(manual?Result.failure():Result.retry());
        }catch(Exception ex){
            if(manual)manualFinished(c,"갱신 실패 · 네트워크/권한 확인");
            return manual?Result.failure():Result.retry();
        }
    }
}
