package com.agilog.local;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/** Display-only forecast from measured pump intervals during the previous 72h.
 * No fixed 25mL/hour/10h-to-200mL curve. No estimates persisted in Firestore.
 * The separate upper display limit of 200mL remains in effect. */
final class PumpForecast {
    private static final long HOUR=3_600_000L, WINDOW=72L*HOUR;
    private static final long PAUSE_MS=20L*60_000L;
    private static final double MIN_ACTIVE_HOURS=0.25d, MAX_INTERVAL_HOURS=24d;
    private static final int MIN_SAMPLES=2, MAX_ML=200;

    static final class Event {
        final long at;
        final boolean isPump;
        final int measuredMl;
        Event(long at,boolean isPump,int measuredMl) {
            this.at=at;this.isPump=isPump;this.measuredMl=measuredMl;
        }
    }
    static final class Model {
        final double rate; // measured mL per active hour, not a baseline multiplier
        final int samples;
        Model(double rate,int samples){this.rate=rate;this.samples=samples;}
    }
    private static final class Sample {
        final double rate,weight;
        Sample(double rate,double weight){this.rate=rate;this.weight=weight;}
    }
    static Model analyze(List<Event> history,long nowMs){
        ArrayList<Event> events=new ArrayList<>();
        if(history!=null)for(Event e:history){
            if(e!=null&&e.at>0&&e.at<=nowMs)events.add(e);
        }
        events.sort(Comparator.comparingLong(e->e.at));
        long previous=-1L;
        ArrayList<Sample> samples=new ArrayList<>();
        for(Event e:events){
            if(e.isPump&&e.measuredMl>0&&e.measuredMl<=1000
                &&e.at>=nowMs-WINDOW&&previous>0&&e.at>previous){
                double gapHours=(e.at-previous)/(double)HOUR;
                double activeHours=(e.at-previous-PAUSE_MS)/(double)HOUR;
                if(activeHours>=MIN_ACTIVE_HOURS&&gapHours<=MAX_INTERVAL_HOURS){
                    double ageHours=(nowMs-e.at)/(double)HOUR;
                    double weight=ageHours<24d?1d:ageHours<48d?0.8d:0.6d;
                    samples.add(new Sample(e.measuredMl/activeHours,weight));
                }
            }
            previous=e.at;
        }
        if(samples.size()<MIN_SAMPLES)return new Model(Double.NaN,samples.size());
        samples.sort(Comparator.comparingDouble(s->s.rate));
        double totalWeight=0d;
        for(Sample s:samples)totalWeight+=s.weight;
        double half=totalWeight/2d,accum=0d,median=samples.get(0).rate;
        for(Sample s:samples){
            accum+=s.weight;
            if(accum>=half){median=s.rate;break;}
        }
        double lower=median*0.5d,upper=median*2d,weighted=0d;
        for(Sample s:samples)
            weighted+=Math.max(lower,Math.min(upper,s.rate))*s.weight;
        double rate=weighted/totalWeight;
        return new Model(Double.isFinite(rate)&&rate>0d?rate:Double.NaN,samples.size());
    }
    /** Return -1 if data are insufficient, 0 for the 20-minute pause. */
    static int estimate(long lastTriggerMs,long nowMs,double rate){
        if(lastTriggerMs<=0||nowMs<0||lastTriggerMs>nowMs)return -1;
        long elapsed=nowMs-lastTriggerMs;
        if(elapsed<=PAUSE_MS)return 0;
        if(!Double.isFinite(rate)||rate<=0d)return -1;
        double activeHours=(elapsed-PAUSE_MS)/(double)HOUR;
        return (int)Math.round(Math.max(0d,Math.min(MAX_ML,rate*activeHours)));
    }
    /** The first 72h since the first pump stay blank, as with v2.81. */
    static Map<Long,Integer> historicalEstimates(List<Event> history,long asOfMs){
        ArrayList<Event> timeline=new ArrayList<>();
        if(history!=null)for(Event e:history){
            if(e!=null&&e.at>0&&e.at<=asOfMs)timeline.add(e);
        }
        timeline.sort(Comparator.comparingLong(e->e.at));
        HashMap<Long,Integer> result=new HashMap<>();
        long firstPump=-1L;
        for(Event e:timeline)if(e.isPump){firstPump=e.at;break;}
        if(firstPump<0)return result;
        int windowStart=0;
        for(int i=0;i<timeline.size();){
            long at=timeline.get(i).at;
            int next=i+1;
            while(next<timeline.size()&&timeline.get(next).at==at)next++;
            boolean pumping=false;
            for(int x=i;x<next;x++)if(timeline.get(x).isPump){pumping=true;break;}
            if(pumping&&at-firstPump>=WINDOW){
                while(windowStart<i&&timeline.get(windowStart).at<at-WINDOW)windowStart++;
                ArrayList<Event> before=new ArrayList<>(
                    timeline.subList(Math.max(0,windowStart-1),i));
                Model model=analyze(before,at);
                if(model.samples>=MIN_SAMPLES&&i>0){
                    int estimate=estimate(timeline.get(i-1).at,at,model.rate);
                    if(estimate>=0)result.put(at,estimate);
                }
            }
            i=next;
        }
        return result;
    }
    private PumpForecast(){}
}
