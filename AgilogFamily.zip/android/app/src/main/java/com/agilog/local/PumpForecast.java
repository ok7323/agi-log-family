package com.agilog.local;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Display-only 72-hour pump-history calibration, never stored as a real pumping record. */
final class PumpForecast {
    private static final long HOUR=3_600_000L, WINDOW=72L*HOUR;
    private static final int MAX_ML=200;

    static final class Event {
        final long at;
        final boolean isPump;
        final int measuredMl;
        Event(long at,boolean isPump,int measuredMl) {
            this.at=at;this.isPump=isPump;this.measuredMl=measuredMl;
        }
    }
    static final class Model {
        final double factor;
        final int samples;
        Model(double factor,int samples){this.factor=factor;this.samples=samples;}
    }
    private static double baseline(double hours){
        if(!Double.isFinite(hours))return 0;
        double h=Math.max(0d,hours);
        return Math.min(MAX_ML,h<=1d?h*25d:25d+(h-1d)*175d/9d);
    }
    static Model analyze(List<Event> history,long nowMs){
        ArrayList<Event> events=new ArrayList<>();
        if(history!=null)for(Event e:history){
            if(e!=null&&e.at>0&&e.at<=nowMs+300_000L)events.add(e);
        }
        events.sort(Comparator.comparingLong(e->e.at));
        long previous=-1L;
        double weighted=0d,totalWeight=0d;
        int samples=0;
        for(Event e:events){
            if(e.isPump&&e.measuredMl>0&&e.measuredMl<=1000
                &&e.at>=nowMs-WINDOW&&previous>0){
                double gapHours=(e.at-previous)/(double)HOUR;
                if(gapHours>=0.5d&&gapHours<=16d){
                    double expected=baseline(gapHours);
                    if(expected>=1d){
                        double ratio=Math.max(0.25d,Math.min(2.5d,e.measuredMl/expected));
                        double ageHours=(nowMs-e.at)/(double)HOUR;
                        double weight=ageHours<24d?1d:ageHours<48d?0.8d:0.6d;
                        weighted+=ratio*weight;
                        totalWeight+=weight;
                        samples++;
                    }
                }
            }
            previous=e.at;
        }
        // Pseudo-weight 2 of the baseline prevents huge shifts on very little history.
        return new Model((2d+weighted)/(2d+totalWeight),samples);
    }
    static int estimate(long lastTriggerMs,long nowMs,double factor){
        if(lastTriggerMs<=0||nowMs<0||lastTriggerMs>nowMs+300_000L)return -1;
        if(!Double.isFinite(factor)||factor<=0d)factor=1d;
        double hours=Math.max(0d,(nowMs-lastTriggerMs)/(double)HOUR);
        return (int)Math.round(Math.max(0d,Math.min(MAX_ML,baseline(hours)*factor)));
    }
    static int estimate(long lastTriggerMs,long nowMs){return estimate(lastTriggerMs,nowMs,1d);}
    private PumpForecast(){}
}
