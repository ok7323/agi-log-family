package com.agilog.local;

/** Visual-only estimate of expression if pumping now; never saved as measured volume. */
final class PumpForecast {
    static int estimate(long lastTriggerMs,long nowMs){
        if(lastTriggerMs<=0 || nowMs<0 || lastTriggerMs>nowMs+300_000L)return -1;
        double hours=Math.max(0d,(nowMs-lastTriggerMs)/3_600_000d);
        return (int)Math.round(hours<=1d?hours*25d:
            hours<10d?25d+(hours-1d)*175d/9d:200d);
    }
    private PumpForecast(){}
}
