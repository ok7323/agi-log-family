package com.agilog.local;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.ExistingWorkPolicy;
import androidx.work.WorkManager;
import androidx.work.BackoffPolicy;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.Source;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public final class RecordWorker extends Worker {
    public RecordWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    static void queue(Context c,String kind,String type,int ml,String size){queueFull(c,UUID.randomUUID().toString(),kind,type,ml,size,System.currentTimeMillis(),false);}
    static void queueFull(Context c,String id,String kind,String type,int ml,String size,long at,boolean legacy){
        Data data=new Data.Builder().putString("id",id).putString("family",FamilyStore.code(c))
            .putString("kind",kind).putString("type",type).putInt("ml",ml).putString("size",size)
            .putLong("at",at).putBoolean("legacy",legacy).build();
        OneTimeWorkRequest job=new OneTimeWorkRequest.Builder(RecordWorker.class)
            .setInputData(data)
            .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.SECONDS).build();
        WorkManager.getInstance(c).enqueueUniqueWork("agi-record-"+id,ExistingWorkPolicy.KEEP,job);
    }
    static void queueParts(Context c,int breast,int pumped,int formula,boolean unknown){
        String id=UUID.randomUUID().toString();
        Data data=new Data.Builder().putString("id",id).putString("family",FamilyStore.code(c))
            .putString("kind",FamilyStore.FEED).putString("type",FamilyStore.feedType(breast,pumped,formula,unknown))
            .putInt("ml",breast+pumped+formula).putString("size","")
            .putLong("at",System.currentTimeMillis()).putBoolean("legacy",false)
            .putBoolean("hasParts",true).putInt("breastMl",breast).putInt("pumpedMl",pumped)
            .putInt("formulaMl",formula).putBoolean("breastUnmeasured",unknown).build();
        OneTimeWorkRequest job=new OneTimeWorkRequest.Builder(RecordWorker.class)
            .setInputData(data).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.SECONDS).build();
        WorkManager.getInstance(c).enqueueUniqueWork("agi-record-"+id,ExistingWorkPolicy.KEEP,job);
    }
    @NonNull @Override public Result doWork(){
        String family=getInputData().getString("family"),id=getInputData().getString("id");
        if(family==null||!FamilyStore.validCode(family)||id==null||FamilyStore.uid().isEmpty())return Result.retry();
        String kind=getInputData().getString("kind"),type=getInputData().getString("type"),size=getInputData().getString("size");
        if(kind==null||type==null||size==null)return Result.failure();
        DocumentReference ref=FamilyStore.db().collection("families").document(family).collection("events").document(id);
        try{
            if(Tasks.await(ref.get(Source.SERVER),20,TimeUnit.SECONDS).exists())return Result.success();
            Map<String,Object> event=FamilyStore.event(getApplicationContext(),kind,type,getInputData().getInt("ml",0),size,getInputData().getLong("at",System.currentTimeMillis()),getInputData().getBoolean("legacy",false));
            if(getInputData().getBoolean("hasParts",false))event.put("feedParts",FamilyStore.feedParts(
                getInputData().getInt("breastMl",0),getInputData().getInt("pumpedMl",0),
                getInputData().getInt("formulaMl",0),getInputData().getBoolean("breastUnmeasured",false)));
            Tasks.await(ref.set(event),20,TimeUnit.SECONDS);
            return Result.success();
        }catch(Exception e){return getRunAttemptCount()>=30?Result.failure():Result.retry();}
    }
}
