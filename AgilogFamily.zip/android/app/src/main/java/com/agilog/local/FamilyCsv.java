package com.agilog.local;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Full-family feeding/diaper export; no CSV formulas may execute in spreadsheets. */
final class FamilyCsv {
    static final class Entry {
        final String id;
        final Map<String,Object> data;
        final Date at;
        Entry(String id,Map<String,Object> data,Date at){this.id=id;this.data=data;this.at=at;}
    }
    private static final String[] HEADERS={"기록ID","기록시각 (기기 시간대)","종류","수유종류","모유(mL)","유축(mL)","분유(mL)","모유미측정","수유총측정량(mL)","기저귀양","기록자","출처","예전기록"};
    private static String string(Object o){return o==null?"":String.valueOf(o);}
    private static int number(Object o){return o instanceof Number?((Number)o).intValue():0;}
    private static String kind(String k){switch(k){case "feed":return "수유";case "pee":return "소변";case "poop":return "대변";case "both":return "소+대변";default:return k;}}
    private static String feed(String k){switch(k){case "breast":return "모유";case "pumped":return "유축";case "formula":return "분유";case "mixed":return "혼합";default:return k;}}
    private static String size(String k){switch(k){case "small":return "소";case "medium":return "중";case "large":return "대";default:return "";}}
    static String escape(Object value){
        String s=string(value);
        // A dangerous leading whitespace + =,+,-,@ can still trigger Excel formulas.
        if(s.matches("(?s)^[\\s\\uFEFF]*[=+\\-@].*"))s="'"+s;
        if(s.indexOf(',')!=-1||s.indexOf('"')!=-1||s.indexOf('\r')!=-1||s.indexOf('\n')!=-1)
            return "\""+s.replace("\"","\"\"")+"\"";
        return s;
    }
    private static void addRow(StringBuilder out,Object... fields){
        for(int i=0;i<fields.length;i++){if(i>0)out.append(',');out.append(escape(fields[i]));}
        out.append("\r\n");
    }
    static String serialize(List<Entry> entries){
        StringBuilder out=new StringBuilder(Math.max(1024,entries.size()*140));
        addRow(out,(Object[])HEADERS);
        SimpleDateFormat timestamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss XXX",Locale.KOREA);
        for(Entry entry:entries){
            Map<String,Object> r=entry.data;
            if(r==null)continue;
            String k=string(r.get("kind")),f=string(r.get("feedType"));
            boolean isFeed="feed".equals(k),legacy=Boolean.TRUE.equals(r.get("legacy"));
            Object b="",p="",m="",u="",total="";
            if(isFeed&&!legacy){
                Object parts=r.get("feedParts");
                int breast=0,pumped=0,formula=0;
                boolean unknown=false;
                if(parts instanceof Map){
                    Map<?,?> vals=(Map<?,?>)parts;
                    breast=number(vals.get("breastMl"));pumped=number(vals.get("pumpedMl"));formula=number(vals.get("formulaMl"));
                    unknown=Boolean.TRUE.equals(vals.get("breastUnmeasured"));
                }else{
                    int ml=number(r.get("ml"));
                    if(ml>0){if("breast".equals(f))breast=ml;else if("pumped".equals(f))pumped=ml;else if("formula".equals(f))formula=ml;}
                    unknown="breast".equals(f)&&ml==-1;
                }
                b=breast;p=pumped;m=formula;u=unknown?"예":"아니오";total=breast+pumped+formula;
            }
            addRow(out,entry.id,entry.at==null?"":timestamp.format(entry.at),kind(k),isFeed?feed(f):"",b,p,m,u,total,
                isFeed?"":size(string(r.get("size"))),string(r.get("who")),string(r.get("source")),legacy?"예":"아니오");
        }
        return out.toString();
    }
    private FamilyCsv(){}
}
