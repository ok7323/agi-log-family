package com.agilog.local;

import java.util.TreeSet;

/** Two latest distinct timestamps of direct pumping or breast-feeding.
 * Pumped milk fed to the baby and formula are not included. */
final class PumpHistory {
    private final TreeSet<Long> times = new TreeSet<>();
    void add(long at) { if(at>0L)times.add(at); }
    long latest() { return times.isEmpty() ? -1L : times.last(); }
    long previous() { return times.size()<2 ? -1L : times.lower(times.last()); }
}
