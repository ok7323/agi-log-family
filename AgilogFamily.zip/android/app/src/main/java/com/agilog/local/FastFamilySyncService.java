package com.agilog.local;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.annotation.Nullable;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

/**
 * Opt-in foreground Firebase listener for faster updates to *other* family devices.
 *
 * This is not an exact 3-minute timer: while Android allows this service and the network
 * connection is available, Firestore pushes changes via its snapshot listener. Doze,
 * connectivity and Android 15's dataSync foreground-service time limit can delay updates.
 * Android 15+ dataSync services are limited to six background hours in a 24h window;
 * we proactively stop before the limit. Users explicitly enable it in the app.
 */
public final class FastFamilySyncService extends Service {
    private static final String PREF = "fast_family_sync_opt_in_v219";
    private static final String CHANNEL = "agilog_fast_family_sync_v219";
    private static final String ACTION_STOP = "com.agilog.local.fast_sync.STOP";
    private static final int NOTIFICATION_ID = 32041;
    private static final long MAX_SESSION_MS = 5L * 60L * 60L * 1000L + 30L * 60L * 1000L;

    private static volatile boolean running;
    private ListenerRegistration registration;
    private String observedFamily;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable maxSession = this::stopSelf;

    static boolean enabled(Context c) {
        return FamilyStore.prefs(c).getBoolean(PREF, false);
    }
    static boolean running() {
        return running;
    }
    static void setEnabled(Context c, boolean enabled) {
        FamilyStore.prefs(c).edit().putBoolean(PREF, enabled).apply();
        if (enabled) startIfEnabled(c);
        else c.stopService(new Intent(c, FastFamilySyncService.class));
    }
    /** Call this only from a user-visible Activity, never a boot/background receiver. */
    static void startIfEnabled(Context c) {
        if (!enabled(c) || !FamilyStore.validCode(FamilyStore.code(c))
                || FamilyStore.uid().isEmpty() || running) return;
        Intent service = new Intent(c, FastFamilySyncService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(service);
        else c.startService(service);
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    private Notification notification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "아기로그 빠른 가족 동기화",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("앱이 켜져 있지 않아도 가족 기록을 빨리 받아 위젯을 갱신합니다.");
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openIntent = PendingIntent.getActivity(this, 32101, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, FastFamilySyncService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 32102, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("아기로그 · 가족 빠른 동기화")
                .setContentText("가족 기록을 감시하며 위젯을 갱신합니다 · 3분 목표")
                .setContentIntent(openIntent)
                .addAction(new Notification.Action.Builder(null, "끄기", stopIntent).build())
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            FamilyStore.prefs(this).edit().putBoolean(PREF, false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        String family = FamilyStore.code(this);
        if (!enabled(this) || !FamilyStore.validCode(family) || FamilyStore.uid().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        // Foreground notification must be displayed promptly after startForegroundService().
        try {
            startForeground(NOTIFICATION_ID, notification());
        } catch (RuntimeException denied) {
            // Android may reject a start when the dataSync quota or other FGS limits apply.
            // Fall back to normal WorkManager synchronization, do not crash the app.
            FamilyStore.prefs(this).edit().putBoolean(PREF, false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (registration != null && family.equals(observedFamily)) return START_NOT_STICKY;
        if (registration != null) { registration.remove(); registration = null; }
        observedFamily = family;
        running = true;
        handler.removeCallbacks(maxSession);
        handler.postDelayed(maxSession, MAX_SESSION_MS);
        registration = FamilyStore.db().collection("families").document(family)
                .collection("events")
                .whereGreaterThanOrEqualTo("at",new com.google.firebase.Timestamp(new java.util.Date(System.currentTimeMillis()-QuickStats.RECENT_MS)))
                .orderBy("at",Query.Direction.DESCENDING)
                .addSnapshotListener((snap, error) -> {
                    if (!running || !family.equals(FamilyStore.code(this)) || snap == null || error != null) return;
                    // A server change from another family member rebuilds the summaries immediately.
                    QuickStats.updateRecent(this,snap.getDocuments());
                    if (QuickNotification.enabled(this)) QuickNotification.show(this);
                    HomeWidgetProvider.updateAll(this);
                });
        return START_NOT_STICKY;
    }

    /** Android 15+ dataSync foreground-service quota: stop rather than crash. */
    @Override public void onTimeout(int startId, int fgsType) {
        stopSelf();
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacks(maxSession);
        if (registration != null) { registration.remove(); registration = null; }
        observedFamily = null;
        super.onDestroy();
    }
}
