package com.agilog.local;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import android.view.View;
import android.widget.RemoteViews;

/** One card; all interaction uses BroadcastReceiver rather than launching the app. */
final class QuickNotification {
    private static final String CHANNEL="agi_family_quick_v1",MODE="mode",TYPE="type",KIND="kind",PREFIX="com.agilog.local.quick.";
    private static final String MAIN="main",TYPES="types",SIZE="size",MILK="milk",TIME="time";
    private static final int ID=32003;
    private static final int[] SMALL={R.id.qa,R.id.qb,R.id.qc,R.id.qd},BIG={R.id.bqa,R.id.bqb,R.id.bqc,R.id.bqd};
    private static final int[] MLVIEWS={R.id.ml0,R.id.ml1,R.id.ml2,R.id.ml3,R.id.ml4,R.id.ml5,R.id.ml6,R.id.ml7};
    static boolean enabled(Context c){return FamilyStore.prefs(c).getBoolean("quick",false);}
    static void enabled(Context c,boolean value){FamilyStore.prefs(c).edit().putBoolean("quick",value).apply();if(value){reset(c);QuickStatsWorker.schedule(c);QuickStatsWorker.request(c);show(c);}else{if(!HomeWidgetProvider.hasWidgets(c))QuickStatsWorker.unschedule(c);hide(c);}}
    static boolean canPost(Context c){return Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    static void reset(Context c){FamilyStore.prefs(c).edit().putString(MODE,MAIN).remove(TYPE).remove(KIND).remove("pending_ml").remove("pending_unknown").remove("time_anchor").putInt("time_offset",0).putInt("amount",70).putInt("page",0).apply();}
    private static PendingIntent intent(Context c,String key){Intent i=new Intent(c,QuickReceiver.class).setAction(PREFIX+key);
        return PendingIntent.getBroadcast(c,key.hashCode()&0x7fffffff,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private static String mode(Context c){return FamilyStore.prefs(c).getString(MODE,MAIN);}
    private static String[] names(Context c){String m=mode(c);
        if(TYPES.equals(m))return new String[]{"모유","유축","분유"};
        if(SIZE.equals(m))return new String[]{"소","중","대"};
        if(MILK.equals(m))return new String[]{"−5",FamilyStore.prefs(c).getInt("amount",70)+"mL 다음","+5"};
        if(TIME.equals(m)){
            int minutes=FamilyStore.prefs(c).getInt("time_offset",0);
            return new String[]{"지금 저장","−5분","누적 "+minutes+"분 전","이전 저장"};
        }
        return new String[]{"🍼 수유","💧 소변","💩 대변","💧💩"};
    }
    // Text kept short enough for Samsung's collapsed notification. Expanded labels stay unchanged.
    private static String[] compactNames(Context c){
        String m=mode(c);
        if(TYPES.equals(m))return new String[]{"모유", "유축", "분유"};
        if(SIZE.equals(m))return new String[]{"소", "중", "대"};
        if(MILK.equals(m))return new String[]{"−5", FamilyStore.prefs(c).getInt("amount",70)+"mL→", "+5"};
        if(TIME.equals(m)){
            int minutes=FamilyStore.prefs(c).getInt("time_offset",0);
            return new String[]{"지금", "−5분", minutes+"분 전", "이전저장"};
        }
        return new String[]{"🍼수유", "💧소변", "💩대변", "💧💩"};
    }
    private static String[] actions(Context c){String m=mode(c);
        if(TYPES.equals(m))return new String[]{"breast","pumped","formula"};
        if(SIZE.equals(m))return new String[]{"small","medium","large"};
        if(MILK.equals(m))return new String[]{"minus","save","plus"};
        if(TIME.equals(m))return new String[]{"now","earlier","offset-info","prior"};
        return new String[]{"feed","pee","poop","both"};
    }
    private static String title(Context c){String m=mode(c);
        if(TYPES.equals(m))return "🍼 수유 종류를 선택하세요";
        if(SIZE.equals(m))return "💧 기저귀 양: 소 / 중 / 대";
        if(MILK.equals(m))return "🍼 "+FamilyStore.typeLabel(FamilyStore.prefs(c).getString(TYPE,"formula"))+" · 양 선택";
        if(TIME.equals(m))return "🍼 수유 시간 선택 · 아래에서 저장";
        return "아기로그 · 빠른 기록";
    }
    static void show(Context c){
        if(!enabled(c)||!canPost(c)||FamilyStore.code(c).isEmpty())return;
        // When upgrading from the old 30mL defaults, reset the quick card once.
        if(FamilyStore.prefs(c).getInt("quick_defaults_version",1)<2){
            FamilyStore.prefs(c).edit().putInt("quick_defaults_version",2)
                .putInt("amount",70).putInt("page",0).putString(MODE,MAIN).apply();
        }
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel=new NotificationChannel(CHANNEL,"아기로그 빠른 기록",NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("가족 공유 기록을 잠금 화면 알림에서 입력합니다.");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(channel);
        // Dismiss earlier versions' grouped notifications.
        for(int old:new int[]{211,212,213,20026,22026})nm.cancel(old);
        RemoteViews small=new RemoteViews(c.getPackageName(),R.layout.quick_card);
        RemoteViews big=new RemoteViews(c.getPackageName(),R.layout.quick_large);
        String[] names=names(c),shortNames=compactNames(c),actions=actions(c);
        for(int x=0;x<4;x++){
            boolean visible=x<names.length;
            small.setViewVisibility(SMALL[x],visible?View.VISIBLE:View.GONE);
            big.setViewVisibility(BIG[x],visible?View.VISIBLE:View.GONE);
            if(visible){small.setTextViewText(SMALL[x],shortNames[x]);big.setTextViewText(BIG[x],names[x]);
                if(!"offset-info".equals(actions[x])){
                    small.setOnClickPendingIntent(SMALL[x],intent(c,actions[x]));
                    big.setOnClickPendingIntent(BIG[x],intent(c,actions[x]));
                }else{
                    // This is a read-only accumulated offset label, not a button.
                    small.setTextViewTextSize(SMALL[x],android.util.TypedValue.COMPLEX_UNIT_SP,11);
                    big.setTextViewTextSize(BIG[x],android.util.TypedValue.COMPLEX_UNIT_SP,11);
                }}
        }
        QuickStats.Summary stats=QuickStats.get(c);
        String today=stats.synced?"오늘  모유 "+stats.todayBreastCount+"회 · 유축+분유 "+stats.todayOtherMl+"mL":"오늘  기록 동기화 대기";
        String yesterday=stats.synced?"어제  모유 "+stats.yesterdayBreastCount+"회 · 유축+분유 "+stats.yesterdayOtherMl+"mL":"어제  기록 동기화 대기";
        // Compact text deliberately abbreviates labels for the 48dp collapsed view.
        // The expanded view still carries the full family summaries.
        String compactToday=stats.synced?"오늘 모"+stats.todayBreastCount+"·유분"+stats.todayOtherMl+"mL":"오늘 동기화 대기";
        String compactYesterday=stats.synced?"어제 모"+stats.yesterdayBreastCount+"·유분"+stats.yesterdayOtherMl+"mL":"어제 동기화 대기";
        String totals=today+" / "+yesterday;
        small.setTextViewText(R.id.quick_today_small,compactToday+" | "+compactYesterday);
        big.setTextViewText(R.id.quick_today_big,today);
        big.setTextViewText(R.id.quick_yesterday_big,yesterday);
        small.setTextViewText(R.id.quick_elapsed_small,"🍼 "+ElapsedTime.compact(stats.lastFeed)
            +"  💩 "+ElapsedTime.compact(stats.lastPoop)+"  💧 "+ElapsedTime.compact(stats.lastPee));
        big.setTextViewText(R.id.quick_elapsed_big,ElapsedTime.display(stats.lastFeed));
        big.setTextViewText(R.id.quick_diaper_big,"💩 대변 "+ElapsedTime.display(stats.lastPoop)
            +"   💧 소변 "+ElapsedTime.display(stats.lastPee));
        big.setViewVisibility(R.id.quick_elapsed_big,View.VISIBLE);
        big.setViewVisibility(R.id.quick_empty_big,View.GONE);
        big.setTextViewText(R.id.quick_title,title(c));
        big.setOnClickPendingIntent(R.id.quick_title,intent(c,"back"));
        if(MILK.equals(mode(c))){
            big.setViewVisibility(R.id.quantities,View.VISIBLE);
            int page=FamilyStore.prefs(c).getInt("page",0);int start=5+page*40;
            for(int i=0;i<8;i++){
                int ml=start+i*5;
                big.setViewVisibility(MLVIEWS[i],ml<=1000?View.VISIBLE:View.INVISIBLE);
                if(ml<=1000){big.setTextViewText(MLVIEWS[i],ml+"mL");big.setOnClickPendingIntent(MLVIEWS[i],intent(c,"ml-"+ml));}
            }
            String type=FamilyStore.prefs(c).getString(TYPE,"formula");
            big.setTextViewText(R.id.prev,page>0?"◀ 이전":"↩ 뒤로");big.setOnClickPendingIntent(R.id.prev,intent(c,page>0?"prev":"back"));
            big.setTextViewText(R.id.return_main,FamilyStore.BREAST.equals(type)?"양 미측정":"↩ 종류");
            big.setOnClickPendingIntent(R.id.return_main,intent(c,FamilyStore.BREAST.equals(type)?"unknown":"back"));
            big.setTextViewText(R.id.next,start+40<=1000?"다음 ▶":"↩ 종류");
            big.setOnClickPendingIntent(R.id.next,intent(c,start+40<=1000?"next":"back"));
        }else big.setViewVisibility(R.id.quantities,View.GONE);
        if(TIME.equals(mode(c))){
            int offset=FamilyStore.prefs(c).getInt("time_offset",0);
            long anchor=FamilyStore.prefs(c).getLong("time_anchor",System.currentTimeMillis());
            SimpleDateFormat f=new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA);
            big.setViewVisibility(R.id.selected_time,View.VISIBLE);
            big.setTextViewText(R.id.selected_time,"선택: "+f.format(new Date(anchor-offset*60000L))+(offset>0?" ("+offset+"분 전)":" (현재)"));
            big.setViewVisibility(R.id.change_amount,View.VISIBLE);
            big.setOnClickPendingIntent(R.id.change_amount,intent(c,"editml"));
        }else{
            big.setViewVisibility(R.id.selected_time,View.GONE);
            big.setViewVisibility(R.id.change_amount,View.GONE);
        }
        PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("아기로그 가족").setContentText(totals).setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCustomContentView(small).setCustomBigContentView(big)
            .setStyle(new Notification.DecoratedCustomViewStyle())
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true).setShowWhen(false).build();
        nm.notify(ID,n);
        ElapsedRefreshReceiver.schedule(c);
    }
    static void hide(Context c){((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);ElapsedRefreshReceiver.schedule(c);}
    static void action(Context c,String raw){
        if(!enabled(c)||raw==null||!raw.startsWith(PREFIX))return;
        String key=raw.substring(PREFIX.length()),m=mode(c);
        var e=FamilyStore.prefs(c).edit();
        if(MAIN.equals(m)){
            if("feed".equals(key))e.putString(MODE,TYPES);
            else if("poop".equals(key)||"pee".equals(key)||"both".equals(key))e.putString(MODE,SIZE).putString(KIND,key);
            else return;
        }else if(TYPES.equals(m)){
            if(!FamilyStore.validType(key)){if("back".equals(key))e.putString(MODE,MAIN);else return;}
            else e.putString(MODE,MILK).putString(TYPE,key).putInt("amount",70).putInt("page",0);
        }else if(SIZE.equals(m)){
            if("back".equals(key))e.putString(MODE,MAIN);
            else if(FamilyStore.validSize(key)){
                RecordWorker.queue(c,FamilyStore.prefs(c).getString(KIND,FamilyStore.PEE),"",0,key);e.putString(MODE,MAIN);
            }else return;
        }else if(MILK.equals(m)){
            int amount=FamilyStore.prefs(c).getInt("amount",70),page=FamilyStore.prefs(c).getInt("page",0);
            String type=FamilyStore.prefs(c).getString(TYPE,FamilyStore.FORMULA);
            if("plus".equals(key))e.putInt("amount",Math.min(1000,amount+5));
            else if("minus".equals(key))e.putInt("amount",Math.max(5,amount-5));
            else if("next".equals(key))e.putInt("page",Math.min(24,page+1));
            else if("prev".equals(key))e.putInt("page",Math.max(0,page-1));
            else if("back".equals(key))e.putString(MODE,TYPES);
            else if("unknown".equals(key)&&FamilyStore.BREAST.equals(type)){
                e.putString(MODE,TIME).putInt("pending_ml",-1).putBoolean("pending_unknown",true)
                    .putLong("time_anchor",System.currentTimeMillis()).putInt("time_offset",0);
            }else if("save".equals(key)){
                e.putString(MODE,TIME).putInt("pending_ml",amount).putBoolean("pending_unknown",false)
                    .putLong("time_anchor",System.currentTimeMillis()).putInt("time_offset",0);
            }else if(key.startsWith("ml-")){
                int ml;try{ml=Integer.parseInt(key.substring(3));}catch(NumberFormatException error){return;}
                if(ml<5||ml>1000||ml%5!=0||ml<5+page*40||ml>40+page*40)return;
                e.putString(MODE,TIME).putInt("pending_ml",ml).putBoolean("pending_unknown",false)
                    .putLong("time_anchor",System.currentTimeMillis()).putInt("time_offset",0);
            }else return;
        }else if(TIME.equals(m)){
            int offset=FamilyStore.prefs(c).getInt("time_offset",0);
            if("editml".equals(key))e.putString(MODE,MILK);
            else if("earlier".equals(key))e.putInt("time_offset",Math.min(24*60,offset+5));

            else if("now".equals(key)||"prior".equals(key)){
                long anchor=FamilyStore.prefs(c).getLong("time_anchor",System.currentTimeMillis());
                if("prior".equals(key)&&offset==0)return; // First choose -5 minutes before saving as past.
                long timestamp="now".equals(key)?System.currentTimeMillis():anchor-offset*60000L;
                String type=FamilyStore.prefs(c).getString(TYPE,FamilyStore.FORMULA);
                int ml=FamilyStore.prefs(c).getInt("pending_ml",70);
                int volume=Math.max(0,ml);
                RecordWorker.queueParts(c,FamilyStore.BREAST.equals(type)?volume:0,
                    FamilyStore.PUMPED.equals(type)?volume:0,FamilyStore.FORMULA.equals(type)?volume:0,
                    ml<0,timestamp);
                e.putString(MODE,MAIN).remove("pending_ml").remove("pending_unknown");
            }else return;
        }else return;
        e.commit();show(c);
    }
    private QuickNotification(){}
}
