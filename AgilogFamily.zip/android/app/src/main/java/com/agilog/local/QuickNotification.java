package com.agilog.local;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

/** Notification quick-action buttons deliberately share the exact widget
 * menu and action handler. The notification only renders the same choices;
 * it never implements a second feeding/diaper/pumping state machine. */
final class QuickNotification {
    private static final String CHANNEL="agi_family_quick_v1";
    private static final String PREFIX="com.agilog.local.quick.";
    private static final int ID=32003;
    private static final int[] SMALL={R.id.qa,R.id.qb,R.id.qc,R.id.qd};
    private static final int[] BIG={R.id.bqa,R.id.bqb,R.id.bqc,R.id.bqd};
    static boolean enabled(Context c){return FamilyStore.prefs(c).getBoolean("quick",false);}
    static void enabled(Context c,boolean value){
        FamilyStore.prefs(c).edit().putBoolean("quick",value).apply();
        if(value){reset(c);QuickStatsWorker.schedule(c);QuickStatsWorker.request(c);show(c);}
        else{if(!HomeWidgetProvider.hasWidgets(c))QuickStatsWorker.unschedule(c);hide(c);}
    }
    static boolean canPost(Context c){return Build.VERSION.SDK_INT<33||
        c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    static void reset(Context c){HomeWidgetProvider.resetNotification(c);}
    private static PendingIntent intent(Context c,String action){
        Intent i=new Intent(c,QuickReceiver.class).setAction(PREFIX+action);
        return PendingIntent.getBroadcast(c,action.hashCode()&0x7fffffff,i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static String compact(String label){
        // Compact notifications have much less room than LockStar; only
        // abbreviate the presentation, never change the action it sends.
        String x=label.replace("\n", "").replace("이전 저장","과거저장")
            .replace("지금 저장","지금저장").replace("시간 선택","시간선택")
            .replace("분유 입력","분유입력").replace("양 미측정","미측정")
            .replace("수유","수유").replace("mL 다음","mL→");
        return x;
    }
    static void show(Context c){
        if(!enabled(c)||!canPost(c)||FamilyStore.code(c).isEmpty())return;
        if(FamilyStore.prefs(c).getInt("quick_shared_widget_flow",0)<1){
            reset(c);
            FamilyStore.prefs(c).edit().putInt("quick_shared_widget_flow",1).apply();
        }
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel=new NotificationChannel(CHANNEL,"아기로그 빠른 기록",NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("가족 공유 기록을 잠금 화면 알림에서 입력합니다.");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
        for(int old:new int[]{211,212,213,20026,22026})nm.cancel(old);
        RemoteViews small=new RemoteViews(c.getPackageName(),R.layout.quick_card);
        RemoteViews big=new RemoteViews(c.getPackageName(),R.layout.quick_large);
        HomeWidgetProvider.Menu menu=HomeWidgetProvider.notificationMenu(c);
        for(int pos=0;pos<4;pos++){
            boolean visible=pos<menu.labels.length;
            small.setViewVisibility(SMALL[pos],visible?View.VISIBLE:View.GONE);
            big.setViewVisibility(BIG[pos],visible?View.VISIBLE:View.GONE);
            if(!visible)continue;
            String action=menu.actions[pos];
            small.setTextViewText(SMALL[pos],compact(menu.labels[pos]));
            big.setTextViewText(BIG[pos],menu.labels[pos].replace("\n"," "));
            if(!"info".equals(action)&&!"open".equals(action)){
                small.setOnClickPendingIntent(SMALL[pos],intent(c,action));
                big.setOnClickPendingIntent(BIG[pos],intent(c,action));
            }else{
                small.setOnClickPendingIntent(SMALL[pos],null);
                big.setOnClickPendingIntent(BIG[pos],null);
            }
        }
        QuickStats.Summary stats=QuickStats.get(c);
        String today=stats.synced?"오늘 모유 "+stats.todayBreastCount+"회 · 유축수유 "+stats.todayPumpedMl+" · 분유 "+stats.todayFormulaMl:"오늘 기록 동기화 대기";
        String yesterday=stats.synced?"어제 모유 "+stats.yesterdayBreastCount+"회 · 유축수유 "+stats.yesterdayPumpedMl+" · 분유 "+stats.yesterdayFormulaMl:"어제 기록 동기화 대기";
        small.setTextViewText(R.id.quick_elapsed_small,"🍼"+ElapsedTime.compact(stats.lastFeed)+"·"+QuickStats.compactAmount(stats.lastFeedAmount));
        small.setTextViewText(R.id.quick_previous_small,"🥛"+ElapsedTime.compact(stats.lastPump)+"/"+ElapsedTime.compact(stats.previousPump));
        small.setTextViewText(R.id.quick_poop_small,"💩"+ElapsedTime.compact(stats.lastPoop));
        small.setTextViewText(R.id.quick_pee_small,"💧"+ElapsedTime.compact(stats.lastPee));
        small.setTextViewText(R.id.quick_today_small,stats.synced?"오늘 모"+stats.todayBreastCount+"·유수"+stats.todayPumpedMl+"·분"+stats.todayFormulaMl:"오늘 대기");
        small.setTextViewText(R.id.quick_yesterday_small,stats.synced?"어제 모"+stats.yesterdayBreastCount+"·유수"+stats.yesterdayPumpedMl+"·분"+stats.yesterdayFormulaMl:"어제 대기");
        small.setTextViewText(R.id.quick_pump_small,"🥛"+ElapsedTime.compact(stats.lastPump));
        big.setTextViewText(R.id.quick_today_big,today);
        big.setTextViewText(R.id.quick_yesterday_big,yesterday);
        big.setTextViewText(R.id.quick_elapsed_big,ElapsedTime.display(stats.lastFeed)+" · "+stats.lastFeedAmount);
        big.setTextViewText(R.id.quick_previous_feed_big,"이전 수유 후 "+ElapsedTime.display(stats.previousFeed)+" · "+stats.previousFeedAmount);
        big.setTextViewText(R.id.quick_pump_big,"🥛 마지막 유축·모유 후 "+(stats.lastPump>0?ElapsedTime.display(stats.lastPump):"기록 없음"));
        big.setTextViewText(R.id.quick_previous_pump_big,"🥛 이전 유축·모유 후 "+(stats.previousPump>0?ElapsedTime.display(stats.previousPump):"기록 없음"));
        big.setTextViewText(R.id.quick_diaper_big,"💩 대변 "+ElapsedTime.display(stats.lastPoop)+"   💧 소변 "+ElapsedTime.display(stats.lastPee));
        big.setViewVisibility(R.id.quick_elapsed_big,View.VISIBLE);
        big.setViewVisibility(R.id.quick_empty_big,View.GONE);
        big.setTextViewText(R.id.quick_title,"아기로그 v2.36 · "+menu.hint);
        big.setOnClickPendingIntent(R.id.quick_title,intent(c,"back"));
        // The 8-value notification picker was removed: it disagreed with the
        // widget's +5/-5/next flow. Only the four common widget buttons remain.
        big.setViewVisibility(R.id.quantities,View.GONE);
        boolean subMenu=!"main".equals(menu.mode);
        big.setViewVisibility(R.id.selected_time,subMenu?View.VISIBLE:View.GONE);
        if(subMenu)big.setTextViewText(R.id.selected_time,menu.hint);
        big.setViewVisibility(R.id.change_amount,subMenu?View.VISIBLE:View.GONE);
        if(subMenu){
            big.setTextViewText(R.id.change_amount,"↩ 뒤로 (위젯과 동일)");
            big.setOnClickPendingIntent(R.id.change_amount,intent(c,"back"));
        }
        PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("아기로그 가족 v2.36").setContentText(today+" / "+yesterday)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCustomContentView(small).setCustomBigContentView(big)
            .setStyle(new Notification.DecoratedCustomViewStyle())
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true).setShowWhen(false).build();
        nm.notify(ID,n);
        ElapsedRefreshReceiver.schedule(c);
    }
    static void hide(Context c){
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);
        ElapsedRefreshReceiver.schedule(c);
    }
    static void action(Context c,String raw){
        if(!enabled(c)||raw==null||!raw.startsWith(PREFIX))return;
        HomeWidgetProvider.notificationAction(c,raw.substring(PREFIX.length()));
    }
    private QuickNotification(){}
}
