package com.agilog.local;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

/** Stats-chart-only estimate, based on elapsed real time since last direct
 * breast-feeding or pumping. Does not change Firebase or measured totals. */
final class BreastEstimateCalculator {
    static final class Event {
        final long at;
        final boolean pump, feed, breast, unmeasured;
        Event(long at,boolean pump,boolean feed,boolean breast,boolean unmeasured){
            this.at=at;this.pump=pump;this.feed=feed;this.breast=breast;this.unmeasured=unmeasured;
        }
    }
    private static final long MAX_PRIOR_GAP_MS=12L*3600000L;
    private static final int FIRST_BREAST_ESTIMATE_ML=50;
    /** Local calendar day number; Calendar handles timezone and DST. */
    private static long localDay(long timestamp){
        Calendar c=Calendar.getInstance();c.setTimeInMillis(timestamp);
        return c.get(Calendar.YEAR)*1000L+c.get(Calendar.DAY_OF_YEAR);
    }
    static Map<Long,Integer> bySession(List<Event> raw){
        ArrayList<Event> events=new ArrayList<>(raw);
        Collections.sort(events, (a,b)->{int t=Long.compare(a.at,b.at);
            return t!=0?t:(a.pump==b.pump?0:a.pump?-1:1);
        });
        HashMap<Long,Integer> amounts=new HashMap<>();
        long lastTrigger=-1,anchor=-1;boolean estimatedThisSession=false;
        long lastDirectBreastDay=-1;
        for(Event e:events){
            if(e.pump){lastTrigger=e.at;continue;}
            if(!e.feed)continue;
            if(anchor<0||e.at-anchor>=3600000L){anchor=e.at;estimatedThisSession=false;}
            if(e.unmeasured&&!estimatedThisSession){
                // First direct breastfeeding of EACH local day starts at 50mL.
                // Any stale gap beyond 12 hours also resets to 50mL.
                boolean firstOfDay=lastDirectBreastDay!=localDay(e.at);
                boolean staleGap=lastTrigger<0||e.at-lastTrigger>MAX_PRIOR_GAP_MS;
                int estimate=firstOfDay||staleGap?FIRST_BREAST_ESTIMATE_ML:
                    e.at>lastTrigger?(int)Math.round((e.at-lastTrigger)*25d/3600000d):0;
                if(estimate>0)amounts.put(anchor,amounts.getOrDefault(anchor,0)+estimate);
                estimatedThisSession=true;
            }
            if(e.breast){lastDirectBreastDay=localDay(e.at);lastTrigger=e.at;}
        }
        return amounts;
    }
    private BreastEstimateCalculator(){}
}
