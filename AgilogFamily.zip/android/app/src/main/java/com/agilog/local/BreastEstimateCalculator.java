package com.agilog.local;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Stats-chart-only estimate, based on elapsed real time since last direct
 * breast-feeding or pumping. Does not change Firebase or measured totals. */
final class BreastEstimateCalculator {
    static final class Event {
        final long at;
        final boolean pump, feed, breast, unmeasured;
        Event(long at,boolean pump,boolean feed,boolean breast,boolean unmeasured){
            this.at=at;this.pump=pump;this.feed=feed;this.breast=breast;this.unmeasured=unmeasured;
        }
    }
    static Map<Long,Integer> bySession(List<Event> raw){
        ArrayList<Event> events=new ArrayList<>(raw);
        Collections.sort(events, (a,b)->{int t=Long.compare(a.at,b.at);
            return t!=0?t:(a.pump==b.pump?0:a.pump?-1:1);
        });
        HashMap<Long,Integer> amounts=new HashMap<>();
        long lastTrigger=-1,anchor=-1;boolean estimatedThisSession=false;
        for(Event e:events){
            if(e.pump){lastTrigger=e.at;continue;}
            if(!e.feed)continue;
            if(anchor<0||e.at-anchor>=3600000L){anchor=e.at;estimatedThisSession=false;}
            if(e.unmeasured&&!estimatedThisSession){
                if(lastTrigger>=0&&e.at>lastTrigger){
                    int estimate=(int)Math.round((e.at-lastTrigger)*25d/3600000d);
                    amounts.put(anchor,amounts.containsKey(anchor)?amounts.get(anchor)+estimate:estimate);
                }
                estimatedThisSession=true;
            }
            if(e.breast)lastTrigger=e.at;
        }
        return amounts;
    }
    private BreastEstimateCalculator(){}
}
