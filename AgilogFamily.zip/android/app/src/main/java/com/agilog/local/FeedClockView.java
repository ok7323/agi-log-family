package com.agilog.local;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** One local-calendar-day 12-hour analog face.
 * Inner blue circle = 00:00-11:59; outer pink circle = 12:00-23:59.
 * Individual feed records are shown without 60-minute session grouping. */
final class FeedClockView extends View {
    static final class Mark {
        final long at;
        final int color;
        Mark(long at,int color){this.at=at;this.color=color;}
    }
    private final ArrayList<Mark> marks;
    private final boolean dark;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    FeedClockView(Context context,List<Mark> values,long referenceTime,boolean darkMode){
        super(context);marks=new ArrayList<>(values);dark=darkMode;
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        int morning=0,afternoon=0;
        Calendar calendar=Calendar.getInstance();
        for(Mark m:marks){calendar.setTimeInMillis(m.at);
            if(calendar.get(Calendar.HOUR_OF_DAY)<12)morning++;else afternoon++;}
        setContentDescription("오늘 수유 시계. 안쪽 파란 원은 오전 "+morning+"건, 바깥 분홍 원은 오후 "+afternoon+"건. 아래에 정확한 수유 시각이 있습니다.");
    }
    private void circle(Canvas canvas,float x,float y,float radius,int color,boolean stroke,float width){
        paint.reset();paint.setAntiAlias(true);paint.setColor(color);
        paint.setStyle(stroke?Paint.Style.STROKE:Paint.Style.FILL);paint.setStrokeWidth(width);
        canvas.drawCircle(x,y,radius,paint);
    }
    private void word(Canvas canvas,String text,float x,float y,int size,int color,boolean bold){
        paint.reset();paint.setAntiAlias(true);paint.setColor(color);paint.setTextSize(size);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL));
        canvas.drawText(text,x,y,paint);
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float scale=Math.min(getWidth(),getHeight())/320f;
        if(scale<=0)return;
        canvas.save();canvas.translate((getWidth()-320*scale)/2f,(getHeight()-320*scale)/2f);canvas.scale(scale,scale);
        circle(canvas,160,160,151,dark?0xFF706271:0xFFE2CDD5,false,0);
        circle(canvas,160,160,149,dark?0xFF29262E:0xFFFFF9F6,false,0);
        circle(canvas,160,160,102,dark?0xFF85516A:0xFFF2B8CB,true,14);
        circle(canvas,160,160,70,dark?0xFF43698F:0xFFA7C8ED,true,14);
        for(int hour=1;hour<=12;hour++){
            double angle=(hour%12)*Math.PI/6-Math.PI/2;
            float x=(float)Math.cos(angle),y=(float)Math.sin(angle);
            paint.reset();paint.setAntiAlias(true);paint.setColor(dark?0xFFBCA8B3:0xFFB9A8AF);paint.setStrokeWidth(1.3f);
            canvas.drawLine(160+x*117,160+y*117,160+x*124,160+y*124,paint);
            word(canvas,String.valueOf(hour),160+x*136,165+y*136,16,dark?0xFFF3E5ED:0xFF6D5864,true);
        }
        word(canvas,"오늘 수유",160,148,12,dark?0xFFF3E5ED:0xFF8C6F7B,true);
        word(canvas,marks.size()+"회",160,176,24,dark?0xFFF3E5ED:0xFF624759,true);
        ArrayList<Integer> amAngles=new ArrayList<>(),pmAngles=new ArrayList<>();
        Calendar cal=Calendar.getInstance();
        for(Mark mark:marks){
            cal.setTimeInMillis(mark.at);
            final int hour=cal.get(Calendar.HOUR_OF_DAY);
            final boolean morning=hour<12;
            float minutes=(hour%12)*60+cal.get(Calendar.MINUTE)+cal.get(Calendar.SECOND)/60f;
            double angle=minutes/720d*Math.PI*2-Math.PI/2;
            ArrayList<Integer> used=morning?amAngles:pmAngles;
            int minuteAngle=(int)minutes,collision=0;
            for(int existing:used)if(Math.abs(minuteAngle-existing)<=9)collision++;
            used.add(minuteAngle);
            float radius=(morning?70:102)+(collision%3-1)*6;
            float x=160+(float)Math.cos(angle)*radius,y=160+(float)Math.sin(angle)*radius;
            circle(canvas,x,y,8,dark?0xFF28242C:Color.WHITE,false,0);
            circle(canvas,x,y,6,mark.color,false,0);
        }
        canvas.restore();
    }
}
