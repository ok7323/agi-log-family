package com.agilog.local;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.function.Consumer;

/** v2.76: matches the website clock. Today's individual dots are interactive,
 * while totals count anchored 60-minute sessions. Yesterday is dots only at 30% opacity. */
final class FeedClockView extends View {
    static final class Mark {
        final long at;
        final int color;
        final boolean previous;
        final String detail;
        Mark(long at,int color,boolean previous,String detail){
            this.at=at;this.color=color;this.previous=previous;this.detail=detail;
        }
    }
    private static final class HitPoint {
        final float x,y;
        final Mark mark;
        HitPoint(float x,float y,Mark mark){this.x=x;this.y=y;this.mark=mark;}
    }
    private final ArrayList<Mark> marks;
    private final ArrayList<HitPoint> hits=new ArrayList<>();
    private final boolean dark;
    private final int morning,afternoon,total;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private Consumer<Mark> selectedListener;
    FeedClockView(Context context,List<Mark> values,int total,int morning,int afternoon,boolean darkMode){
        super(context);marks=new ArrayList<>(values);dark=darkMode;
        this.total=total;this.morning=morning;this.afternoon=afternoon;
        setClickable(true);
        setContentDescription("오늘 수유 "+total+"회. 오전 "+morning+"회, 오후 "+afternoon+"회. 수유 후 60분 이내 수유는 한 회차입니다. 전날 점은 70퍼센트 투명한 비교 점입니다.");
    }
    void setOnMarkSelectedListener(Consumer<Mark> listener){selectedListener=listener;}
    private void circle(Canvas canvas,float x,float y,float radius,int color,boolean stroke,float width){
        paint.reset();paint.setAntiAlias(true);paint.setColor(color);
        paint.setStyle(stroke?Paint.Style.STROKE:Paint.Style.FILL);paint.setStrokeWidth(width);
        canvas.drawCircle(x,y,radius,paint);
    }
    private void word(Canvas canvas,String text,float x,float y,int size,int color,boolean bold){
        paint.reset();paint.setAntiAlias(true);paint.setColor(color);paint.setTextSize(size);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL));
        canvas.drawText(text,x,y,paint);
    }
    private void drawMarks(Canvas canvas,boolean yesterday){
        ArrayList<Integer> amAngles=new ArrayList<>(),pmAngles=new ArrayList<>();
        Calendar cal=Calendar.getInstance();
        for(Mark mark:marks){
            if(mark.previous!=yesterday)continue;
            cal.setTimeInMillis(mark.at);
            boolean am=cal.get(Calendar.HOUR_OF_DAY)<12;
            float minutes=(cal.get(Calendar.HOUR_OF_DAY)%12)*60+cal.get(Calendar.MINUTE)+cal.get(Calendar.SECOND)/60f;
            double angle=minutes/720d*Math.PI*2-Math.PI/2;
            ArrayList<Integer> used=am?amAngles:pmAngles;
            int minuteAngle=(int)minutes,collision=0;
            for(int existing:used)if(Math.abs(minuteAngle-existing)<=9)collision++;
            used.add(minuteAngle);
            float radius=(am?70:102)+(collision%3-1)*6;
            float x=160+(float)Math.cos(angle)*radius,y=160+(float)Math.sin(angle)*radius;
            final int alpha=mark.previous?0x4D000000:0xFF000000;
            circle(canvas,x,y,8,alpha|(dark?0x0028242C:0x00FFFFFF),false,0);
            circle(canvas,x,y,6,alpha|(mark.color&0x00FFFFFF),false,0);
            if(!mark.previous)hits.add(new HitPoint(x,y,mark));
        }
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float scale=Math.min(getWidth(),getHeight())/320f;
        if(scale<=0)return;
        canvas.save();canvas.translate((getWidth()-320*scale)/2f,(getHeight()-320*scale)/2f);canvas.scale(scale,scale);
        circle(canvas,160,160,151,dark?0xFF706271:0xFFE2CDD5,false,0);
        circle(canvas,160,160,149,dark?0xFF29262E:0xFFFFF9F6,false,0);
        circle(canvas,160,160,102,dark?0xFF85516A:0xFFF2B8CB,true,14);
        circle(canvas,160,160,70,dark?0xFF43698F:0xFFA7C8ED,true,14);
        for(int hour=1;hour<=12;hour++){
            double angle=(hour%12)*Math.PI/6-Math.PI/2;
            float x=(float)Math.cos(angle),y=(float)Math.sin(angle);
            paint.reset();paint.setAntiAlias(true);paint.setColor(dark?0xFFBCA8B3:0xFFB9A8AF);paint.setStrokeWidth(1.3f);
            canvas.drawLine(160+x*117,160+y*117,160+x*124,160+y*124,paint);
            word(canvas,String.valueOf(hour),160+x*136,165+y*136,16,dark?0xFFF3E5ED:0xFF6D5864,true);
        }
        word(canvas,"오늘 수유",160,148,12,dark?0xFFF3E5ED:0xFF8C6F7B,true);
        word(canvas,total+"회",160,176,24,dark?0xFFF3E5ED:0xFF624759,true);
        hits.clear();
        drawMarks(canvas,true);  // Yesterday: visual comparison only.
        drawMarks(canvas,false); // Today: clickable, full opacity.
        canvas.restore();
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()!=MotionEvent.ACTION_UP)return super.onTouchEvent(event) || event.getAction()==MotionEvent.ACTION_DOWN;
        float scale=Math.min(getWidth(),getHeight())/320f;
        if(scale<=0)return false;
        float x=(event.getX()-(getWidth()-320*scale)/2f)/scale;
        float y=(event.getY()-(getHeight()-320*scale)/2f)/scale;
        HitPoint nearest=null;float distance=13*13;
        for(HitPoint pt:hits){float dx=x-pt.x,dy=y-pt.y,d=dx*dx+dy*dy;
            if(d<=distance){distance=d;nearest=pt;}}
        if(nearest!=null&&selectedListener!=null){selectedListener.accept(nearest.mark);performClick();return true;}
        return super.onTouchEvent(event);
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
