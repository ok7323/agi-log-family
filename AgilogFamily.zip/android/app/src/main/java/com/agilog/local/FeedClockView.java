package com.agilog.local;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** One 12-hour analog face with a ring for each half of a rolling 24-hour window.
 *  Outer ring = [now-12h, now]; inner ring = [now-24h, now-12h).
 *  A dot represents an individual feed record, not a merged feeding session. */
final class FeedClockView extends View {
    static final class Mark {
        final long at;
        final int color;
        Mark(long at, int color) { this.at=at;this.color=color; }
    }
    private final ArrayList<Mark> marks;
    private final long now;
    private final boolean dark;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    FeedClockView(Context c,List<Mark> values,long referenceTime,boolean darkMode) {
        super(c);marks=new ArrayList<>(values);now=referenceTime;dark=darkMode;
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        setContentDescription("지난 24시간 수유 시계. 바깥 원은 최근 12시간, 안쪽 원은 이전 12시간. 수유 "+marks.size()+"건. 아래에서 상세 수유 시각 확인 가능");
    }
    private void circle(Canvas c,float x,float y,float r,int color,boolean stroke,float width) {
        paint.reset();paint.setAntiAlias(true);paint.setColor(color);
        paint.setStyle(stroke?Paint.Style.STROKE:Paint.Style.FILL);paint.setStrokeWidth(width);
        c.drawCircle(x,y,r,paint);
    }
    private void word(Canvas c,String text,float x,float y,int size,int color,boolean bold) {
        paint.reset();paint.setAntiAlias(true);paint.setColor(color);paint.setTextSize(size);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.create(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(text,x,y,paint);
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float scale=Math.min(getWidth(),getHeight())/320f;
        if(scale<=0)return;
        c.save();c.translate((getWidth()-320*scale)/2f,(getHeight()-320*scale)/2f);c.scale(scale,scale);
        circle(c,160,160,151,dark?0xFF706271:0xFFE2CDD5,false,0);
        circle(c,160,160,149,dark?0xFF29262E:0xFFFFF9F6,false,0);
        circle(c,160,160,100,dark?0xFF845366:0xFFF3C0D2,true,14);
        circle(c,160,160,70,dark?0xFF69678D:0xFFC7C6DF,true,14);
        for(int hour=1;hour<=12;hour++){
            double a=(hour%12)*Math.PI/6-Math.PI/2;
            float x=(float)Math.cos(a),y=(float)Math.sin(a);
            paint.reset();paint.setAntiAlias(true);paint.setColor(dark?0xFFBCA8B3:0xFFB9A8AF);paint.setStrokeWidth(1.3f);
            c.drawLine(160+x*118,160+y*118,160+x*124,160+y*124,paint);
            word(c,String.valueOf(hour),160+x*135,165+y*135,15,dark?0xFFF3E5ED:0xFF6D5864,true);
        }
        word(c,"최근 24시간",160,154,12,dark?0xFFF3E5ED:0xFF8C6F7B,true);
        word(c,marks.size()+"건",160,178,22,dark?0xFFF3E5ED:0xFF624759,true);
        ArrayList<Integer> recentAngles=new ArrayList<>(),earlierAngles=new ArrayList<>();
        Calendar cal=Calendar.getInstance();
        for(Mark item:marks){
            long elapsed=now-item.at;
            if(elapsed<0||elapsed>24L*60*60*1000)continue;
            boolean recent=elapsed<=12L*60*60*1000;
            cal.setTimeInMillis(item.at);
            float minute=(cal.get(Calendar.HOUR_OF_DAY)%12)*60+cal.get(Calendar.MINUTE)+cal.get(Calendar.SECOND)/60f;
            double a=minute/720d*Math.PI*2-Math.PI/2;
            int angleMinute=(int)minute;
            ArrayList<Integer> used=recent?recentAngles:earlierAngles;
            int same=0;for(int existing:used){if(Math.abs(angleMinute-existing)<=7)same++;}
            used.add(angleMinute);
            float radius=(recent?100:70)+(same%3-1)*6;
            float x=160+(float)Math.cos(a)*radius,y=160+(float)Math.sin(a)*radius;
            circle(c,x,y,7,dark?0xFF28242C:Color.WHITE,false,0);
            circle(c,x,y,5.5f,item.color,false,0);
        }
        c.restore();
    }
}
