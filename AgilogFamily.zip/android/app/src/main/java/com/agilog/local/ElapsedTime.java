package com.agilog.local;

/** Whole elapsed minutes since a saved event; no seconds in any UI. */
final class ElapsedTime {
    static String display(long timestamp) {
        if (timestamp <= 0) return "기록 없음";
        long minutes = Math.max(0L, (System.currentTimeMillis() - timestamp) / 60000L);
        return (minutes / 60L) + "시간 " + (minutes % 60L) + "분";
    }
    static String compact(long timestamp) {
        if (timestamp <= 0) return "없음";
        long minutes = Math.max(0L, (System.currentTimeMillis() - timestamp) / 60000L);
        return (minutes / 60L) + "시간" + (minutes % 60L) + "분";
    }
    private ElapsedTime() { }
}
