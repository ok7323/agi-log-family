package com.agilog.local;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Duration is hours:minutes, clock time is HH:mm; seconds never rendered. */
final class ElapsedTime {
    static String display(long timestamp) {
        if(timestamp<=0)return "--:--";
        long mins=Math.max(0L,(System.currentTimeMillis()-timestamp)/60000L);
        return String.format(Locale.ROOT,"%02d:%02d",mins/60L,mins%60L);
    }
    // Compact displays omit the leading zero in hours to save horizontal space.
    static String compact(long timestamp) {
        if(timestamp<=0)return "--:--";
        long mins=Math.max(0L,(System.currentTimeMillis()-timestamp)/60000L);
        return String.format(Locale.ROOT,"%d:%02d",mins/60L,mins%60L);
    }
    static String clock(long timestamp) {
        if(timestamp<=0)return "--:--";
        return new SimpleDateFormat("HH:mm",Locale.KOREA).format(new Date(timestamp));
    }
    private ElapsedTime(){}
}
