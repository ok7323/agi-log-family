package com.agilog.local;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.firestore.DocumentSnapshot;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/** Persisted, read-only summary of the latest synced family events for the notification. */
final class QuickStats {
    static final class Summary {
        final boolean synced;
        final long lastFeed;
        final int todayMl, yesterdayMl;
        Summary(boolean synced,long lastFeed,int todayMl,int yesterdayMl){
            this.synced=synced;this.lastFeed=lastFeed;this.todayMl=todayMl;this.yesterdayMl=yesterdayMl;
        }
    }
    private static long todayStart(){
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }
    private static long yesterdayStart(){
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_MONTH,-1);return c.getTimeInMillis();
    }
    static void update(Context c,List<DocumentSnapshot> events){
        long today=todayStart(),yesterday=yesterdayStart(),now=System.currentTimeMillis();
        int tm=0,ym=0;long last=-1;
        for(DocumentSnapshot snap:events){
            Date date=snap.getDate("at");String kind=snap.getString("kind");
            if(date==null||!FamilyStore.FEED.equals(kind))continue;
            long ts=date.getTime();if(ts>now+300000)continue;
            if(ts>last)last=ts;
            Map<String,Object> r=snap.getData();int ml=r==null?0:FamilyStore.knownMl(r);
            if(ts>=today)tm+=ml;
            else if(ts>=yesterday)ym+=ml;
        }
        FamilyStore.prefs(c).edit().putString("quick_stats_family",FamilyStore.code(c))
            .putBoolean("quick_stats_synced",true).putLong("quick_stats_day",today)
            .putLong("quick_stats_last_feed",last)
            .putInt("quick_stats_today_ml",tm).putInt("quick_stats_yesterday_ml",ym).apply();
    }
    static Summary get(Context c){
        SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString("quick_stats_family",""))||!p.getBoolean("quick_stats_synced",false))
            return new Summary(false,-1,0,0);
        long day=p.getLong("quick_stats_day",0),today=todayStart(),yesterday=yesterdayStart();
        int t=p.getInt("quick_stats_today_ml",0),y=p.getInt("quick_stats_yesterday_ml",0);
        if(day==yesterday){y=t;t=0;}
        else if(day!=today){t=0;y=0;}
        return new Summary(true,p.getLong("quick_stats_last_feed",-1),t,y);
    }
    private QuickStats(){}
}
