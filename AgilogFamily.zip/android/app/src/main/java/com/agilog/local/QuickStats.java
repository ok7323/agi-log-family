package com.agilog.local;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.firestore.DocumentSnapshot;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Cached local widget summary. Recent 3h refreshes merge with earlier locally
 *  observed records so today's/yesterday's totals don't reset on each poll. */
final class QuickStats {
    private static final String CACHE="quick_stats_recent_cache_v225";
    private static final String CACHE_FAMILY="quick_stats_cache_family_v225";
    static final long RECENT_MS=3L*60*60*1000;
    static final class Summary {
        final boolean synced;
        final long lastFeed, previousFeed, lastPoop, lastPee;
        final String lastFeedAmount, previousFeedAmount;
        final int todayBreastCount, yesterdayBreastCount;
        final int todayPumpedMl, yesterdayPumpedMl, todayFormulaMl, yesterdayFormulaMl;
        Summary(boolean synced, long lastFeed, long previousFeed, long lastPoop, long lastPee,
                String lastFeedAmount, String previousFeedAmount,
                int todayBreastCount, int yesterdayBreastCount,
                int todayPumpedMl, int yesterdayPumpedMl, int todayFormulaMl, int yesterdayFormulaMl) {
            this.synced=synced; this.lastFeed=lastFeed; this.previousFeed=previousFeed;
            this.lastFeedAmount=lastFeedAmount; this.previousFeedAmount=previousFeedAmount;
            this.lastPoop=lastPoop; this.lastPee=lastPee;
            this.todayBreastCount=todayBreastCount; this.yesterdayBreastCount=yesterdayBreastCount;
            this.todayPumpedMl=todayPumpedMl; this.yesterdayPumpedMl=yesterdayPumpedMl;
            this.todayFormulaMl=todayFormulaMl; this.yesterdayFormulaMl=yesterdayFormulaMl;
        }
    }
    private static final class Entry {
        String id,kind,amount;
        long at;
        boolean breast;
        int pumped,formula;
        JSONObject json(){
            JSONObject j=new JSONObject();
            try{j.put("id",id);j.put("kind",kind);j.put("at",at);j.put("amount",amount);
                j.put("breast",breast);j.put("pumped",pumped);j.put("formula",formula);}catch(Exception ignored){}
            return j;
        }
        Entry(JSONObject j){id=j.optString("id","");kind=j.optString("kind","");at=j.optLong("at",0);
            amount=j.optString("amount","미측정");breast=j.optBoolean("breast",false);
            pumped=j.optInt("pumped",0);formula=j.optInt("formula",0);}
        Entry(DocumentSnapshot d){
            id=d.getId();Date date=d.getDate("at");at=date==null?0:date.getTime();
            Map<String,Object> row=d.getData();if(row==null)row=Collections.emptyMap();
            kind=String.valueOf(row.get("kind"));
            boolean legacy=Boolean.TRUE.equals(row.get("legacy"));
            Object parts=row.get("feedParts");
            int measured=0;boolean unmeasured=false;
            if(parts instanceof Map){Map<?,?> p=(Map<?,?>)parts;
                int b=Math.max(0,FamilyStore.number(p.get("breastMl")));
                pumped=Math.max(0,FamilyStore.number(p.get("pumpedMl")));
                formula=Math.max(0,FamilyStore.number(p.get("formulaMl")));
                unmeasured=Boolean.TRUE.equals(p.get("breastUnmeasured"));
                breast=b>0||unmeasured; measured=b+pumped+formula;
            }else if(!legacy){
                int ml=FamilyStore.number(row.get("ml"));String type=String.valueOf(row.get("feedType"));
                breast=FamilyStore.BREAST.equals(type);
                if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
                unmeasured=breast&&ml==-1;measured=Math.max(0,ml);
            }
            if(legacy){breast=false;pumped=0;formula=0;measured=0;unmeasured=false;}
            amount=measured==0?"미측정":measured+"mL"+(unmeasured?"+모유 미측정":"");
        }
    }
    private static long startOfDay(int offset){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);
        c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_MONTH,offset);return c.getTimeInMillis();}
    static String compactAmount(String full){if(full==null||full.isEmpty())return "--";
        return full.replace("mL","").replace("+모유 미측정","+?").replace("미측정","?");}
    private static Map<String,Entry> load(Context c){
        HashMap<String,Entry> out=new HashMap<>();SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString(CACHE_FAMILY,"")))return out;
        try{JSONArray a=new JSONArray(p.getString(CACHE,"[]"));for(int i=0;i<a.length();i++){
            Entry e=new Entry(a.getJSONObject(i));if(!e.id.isEmpty())out.put(e.id,e);
        }}catch(Exception ignored){}
        return out;
    }
    /** Foreground full-history result: replace the local cache with the most recent 3 days. */
    static synchronized void update(Context c,List<DocumentSnapshot> all){merge(c,all,false);}
    /** Auto/manual refresh: only recent 3h docs are fetched and merged. */
    static synchronized void updateRecent(Context c,List<DocumentSnapshot> recent){merge(c,recent,true);}
    private static void merge(Context c,List<DocumentSnapshot> docs,boolean partial){
        long now=System.currentTimeMillis();long keepFrom=startOfDay(-2);
        Map<String,Entry> map=partial?load(c):new HashMap<>();
        if(partial){long cutoff=now-RECENT_MS;
            // Recent server results are authoritative for this sliding interval:
            // this also removes recent records deleted on another device.
            map.values().removeIf(e->e.at>=cutoff);
        }
        for(DocumentSnapshot doc:docs){Entry e=new Entry(doc);
            if(e.at>=keepFrom&&e.at<=now+300000L)map.put(e.id,e);
        }
        map.values().removeIf(e->e.at<keepFrom||e.at>now+300000L);
        ArrayList<Entry> entries=new ArrayList<>(map.values());
        entries.sort(Comparator.comparingLong(e->e.at));
        JSONArray json=new JSONArray();for(Entry e:entries)json.put(e.json());
        long today=startOfDay(0),yesterday=startOfDay(-1);
        int tb=0,yb=0,tp=0,yp=0,tf=0,yf=0;
        long last=-1,prev=-1,lastPoop=-1,lastPee=-1,sessionStart=-1;
        String lastAmount="--",prevAmount="--";boolean sessionHasBreast=false;
        int sessionDay=0;
        for(Entry e:entries){
            if(FamilyStore.POOP.equals(e.kind)||FamilyStore.BOTH.equals(e.kind))lastPoop=Math.max(lastPoop,e.at);
            if(FamilyStore.PEE.equals(e.kind)||FamilyStore.BOTH.equals(e.kind))lastPee=Math.max(lastPee,e.at);
            if(!FamilyStore.FEED.equals(e.kind))continue;
            prev=last;prevAmount=lastAmount;last=e.at;lastAmount=e.amount;
            if(e.at>=today){tp+=e.pumped;tf+=e.formula;}
            else if(e.at>=yesterday){yp+=e.pumped;yf+=e.formula;}
            if(sessionStart<0||e.at-sessionStart>=60*60*1000L){
                if(sessionHasBreast){if(sessionDay==1)tb++;else if(sessionDay==2)yb++;}
                sessionStart=e.at;sessionHasBreast=e.breast;
                sessionDay=e.at>=today?1:e.at>=yesterday?2:0;
            }else if(e.breast)sessionHasBreast=true;
        }
        if(sessionHasBreast){if(sessionDay==1)tb++;else if(sessionDay==2)yb++;}
        FamilyStore.prefs(c).edit().putString(CACHE_FAMILY,FamilyStore.code(c)).putString(CACHE,json.toString())
            .putString("quick_stats_family",FamilyStore.code(c)).putBoolean("quick_stats_synced_v210",true)
            .putLong("quick_stats_day",today)
            .putLong("quick_stats_last_feed",last).putLong("quick_stats_previous_feed",prev)
            .putString("quick_stats_last_amount",lastAmount).putString("quick_stats_previous_amount",prevAmount)
            .putLong("quick_stats_last_poop",lastPoop).putLong("quick_stats_last_pee",lastPee)
            .putInt("quick_today_breast_count",tb).putInt("quick_yesterday_breast_count",yb)
            .putInt("quick_today_pumped_ml",tp).putInt("quick_yesterday_pumped_ml",yp)
            .putInt("quick_today_formula_ml",tf).putInt("quick_yesterday_formula_ml",yf)
            .apply();
    }
    static Summary get(Context c){
        SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString("quick_stats_family",""))||!p.getBoolean("quick_stats_synced_v210",false))
            return new Summary(false,-1,-1,-1,-1,"--","--",0,0,0,0,0,0);
        long day=p.getLong("quick_stats_day",0),today=startOfDay(0),yesterday=startOfDay(-1);
        int tb=p.getInt("quick_today_breast_count",0),yb=p.getInt("quick_yesterday_breast_count",0);
        int tp=p.getInt("quick_today_pumped_ml",0),yp=p.getInt("quick_yesterday_pumped_ml",0);
        int tf=p.getInt("quick_today_formula_ml",0),yf=p.getInt("quick_yesterday_formula_ml",0);
        if(day==yesterday){yb=tb;yp=tp;yf=tf;tb=0;tp=0;tf=0;}
        else if(day!=today){tb=0;yb=0;tp=0;yp=0;tf=0;yf=0;}
        return new Summary(true,p.getLong("quick_stats_last_feed",-1),p.getLong("quick_stats_previous_feed",-1),
            p.getLong("quick_stats_last_poop",-1),p.getLong("quick_stats_last_pee",-1),
            p.getString("quick_stats_last_amount","--"),p.getString("quick_stats_previous_amount","--"),
            tb,yb,tp,yp,tf,yf);
    }
    private QuickStats(){}
}
