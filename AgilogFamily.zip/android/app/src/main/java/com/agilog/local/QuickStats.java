package com.agilog.local;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.firestore.DocumentSnapshot;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/** Family summary in the tablet's local timezone, with individual milk sources. */
final class QuickStats {
    static final class Summary {
        final boolean synced;
        final long lastFeed, previousFeed, lastPoop, lastPee;
        final String lastFeedAmount, previousFeedAmount;
        final int todayBreastCount, yesterdayBreastCount;
        final int todayPumpedMl, yesterdayPumpedMl, todayFormulaMl, yesterdayFormulaMl;
        Summary(boolean synced, long lastFeed, long previousFeed, long lastPoop, long lastPee,
                String lastFeedAmount, String previousFeedAmount,
                int todayBreastCount, int yesterdayBreastCount,
                int todayPumpedMl, int yesterdayPumpedMl, int todayFormulaMl, int yesterdayFormulaMl) {
            this.synced=synced; this.lastFeed=lastFeed; this.previousFeed=previousFeed;
            this.lastFeedAmount=lastFeedAmount; this.previousFeedAmount=previousFeedAmount;
            this.lastPoop=lastPoop; this.lastPee=lastPee;
            this.todayBreastCount=todayBreastCount; this.yesterdayBreastCount=yesterdayBreastCount;
            this.todayPumpedMl=todayPumpedMl; this.yesterdayPumpedMl=yesterdayPumpedMl;
            this.todayFormulaMl=todayFormulaMl; this.yesterdayFormulaMl=yesterdayFormulaMl;
        }
    }

    private static long startOfDay(int daysFromToday) {
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_MONTH,daysFromToday);
        return c.getTimeInMillis();
    }
    private static boolean isBreastFeeding(Map<String,Object> row) {
        if(Boolean.TRUE.equals(row.get("legacy")))return false;
        Object parts=row.get("feedParts");
        if(parts instanceof Map) {
            Map<?,?> p=(Map<?,?>)parts;
            return FamilyStore.number(p.get("breastMl"))>0 || Boolean.TRUE.equals(p.get("breastUnmeasured"));
        }
        return FamilyStore.BREAST.equals(row.get("feedType"));
    }
    private static int part(Map<String,Object> row,String partKey,String legacyType) {
        if(Boolean.TRUE.equals(row.get("legacy")))return 0;
        Object parts=row.get("feedParts");
        if(parts instanceof Map) {
            return Math.max(0,FamilyStore.number(((Map<?,?>)parts).get(partKey)));
        }
        // Compatibility with old single-type entries which predate feedParts.
        return legacyType.equals(row.get("feedType"))
            ? Math.max(0,FamilyStore.number(row.get("ml"))) : 0;
    }
    /** Display the measured total from an individual feeding, never inventing an
     * amount for unmeasured direct breastfeeding or older legacy events. */
    private static String feedAmount(Map<String,Object> row) {
        if(row==null || Boolean.TRUE.equals(row.get("legacy")))return "미측정";
        int measured=FamilyStore.knownMl(row);
        boolean unmeasured=FamilyStore.unknownBreast(row);
        if(measured<=0)return "미측정";
        return measured+"mL"+(unmeasured?"+모유 미측정":"");
    }
    static String compactAmount(String full) {
        if(full==null || full.isEmpty())return "--";
        return full.replace("mL","").replace("+모유 미측정","+?").replace("미측정","?");
    }
    static void update(Context c,List<DocumentSnapshot> events) {
        long today=startOfDay(0),yesterday=startOfDay(-1),now=System.currentTimeMillis();
        int todayBreast=0,yesterdayBreast=0,todayPumped=0,yesterdayPumped=0,todayFormula=0,yesterdayFormula=0;
        long last=-1,previous=-1,lastPoop=-1,lastPee=-1;
        String lastAmount="--",previousAmount="--";
        for(DocumentSnapshot snap:events) {
            Date date=snap.getDate("at");
            if(date==null)continue;
            long ts=date.getTime();
            if(ts>now+300000)continue;
            String kind=snap.getString("kind");
            if(FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))lastPoop=Math.max(lastPoop,ts);
            if(FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))lastPee=Math.max(lastPee,ts);
            if(!FamilyStore.FEED.equals(kind))continue;
            // Keep the amount attached to the same event as its timestamp.
            // Two different feed documents can share an identical timestamp.
            Map<String,Object> row=snap.getData();
            if(row==null)continue;
            String quantity=feedAmount(row);
            if(ts>=last){
                previous=last; previousAmount=lastAmount;
                last=ts; lastAmount=quantity;
            }else if(ts>previous){
                previous=ts; previousAmount=quantity;
            }
            if(ts>=today) {
                todayPumped+=part(row,"pumpedMl",FamilyStore.PUMPED);
                todayFormula+=part(row,"formulaMl",FamilyStore.FORMULA);
            }else if(ts>=yesterday){
                yesterdayPumped+=part(row,"pumpedMl",FamilyStore.PUMPED);
                yesterdayFormula+=part(row,"formulaMl",FamilyStore.FORMULA);
            }
        }
        for(FeedSessions.Session session:FeedSessions.group(events)) {
            if(!session.includesBreast)continue;
            if(session.startedAt>=today)todayBreast++;
            else if(session.startedAt>=yesterday)yesterdayBreast++;
        }
        FamilyStore.prefs(c).edit().putString("quick_stats_family",FamilyStore.code(c))
            .putBoolean("quick_stats_synced_v210",true).putLong("quick_stats_day",today)
            .putLong("quick_stats_last_feed",last).putLong("quick_stats_previous_feed",previous)
            .putString("quick_stats_last_amount",lastAmount).putString("quick_stats_previous_amount",previousAmount)
            .putLong("quick_stats_last_poop",lastPoop).putLong("quick_stats_last_pee",lastPee)
            .putInt("quick_today_breast_count",todayBreast).putInt("quick_yesterday_breast_count",yesterdayBreast)
            .putInt("quick_today_pumped_ml",todayPumped).putInt("quick_yesterday_pumped_ml",yesterdayPumped)
            .putInt("quick_today_formula_ml",todayFormula).putInt("quick_yesterday_formula_ml",yesterdayFormula)
            .apply();
    }
    static Summary get(Context c) {
        SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString("quick_stats_family",""))||!p.getBoolean("quick_stats_synced_v210",false))
            return new Summary(false,-1,-1,-1,-1,"--","--",0,0,0,0,0,0);
        long day=p.getLong("quick_stats_day",0),today=startOfDay(0),yesterday=startOfDay(-1);
        int tb=p.getInt("quick_today_breast_count",0),yb=p.getInt("quick_yesterday_breast_count",0);
        int tp=p.getInt("quick_today_pumped_ml",0),yp=p.getInt("quick_yesterday_pumped_ml",0);
        int tf=p.getInt("quick_today_formula_ml",0),yf=p.getInt("quick_yesterday_formula_ml",0);
        // On midnight transition, old today figures are yesterday figures until next sync.
        if(day==yesterday){yb=tb;yp=tp;yf=tf;tb=0;tp=0;tf=0;}
        else if(day!=today){tb=0;yb=0;tp=0;yp=0;tf=0;yf=0;}
        return new Summary(true,p.getLong("quick_stats_last_feed",-1),
            p.getLong("quick_stats_previous_feed",-1),
            p.getLong("quick_stats_last_poop",-1),p.getLong("quick_stats_last_pee",-1),
            p.getString("quick_stats_last_amount","--"), p.getString("quick_stats_previous_amount","--"),
            tb,yb,tp,yp,tf,yf);
    }
    private QuickStats(){}
}
