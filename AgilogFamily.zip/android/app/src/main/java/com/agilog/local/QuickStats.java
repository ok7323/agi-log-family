package com.agilog.local;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.firestore.DocumentSnapshot;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/** Per-day lock-screen summaries (local timezone). Breast sessions are counted once per event. */
final class QuickStats {
    static final class Summary {
        final boolean synced;
        final long lastFeed, lastPoop, lastPee;
        final int todayBreastCount, yesterdayBreastCount, todayOtherMl, yesterdayOtherMl;
        Summary(boolean synced,long lastFeed,long lastPoop,long lastPee,int todayBreastCount,int yesterdayBreastCount,int todayOtherMl,int yesterdayOtherMl){
            this.synced=synced;this.lastFeed=lastFeed;this.lastPoop=lastPoop;this.lastPee=lastPee;
            this.todayBreastCount=todayBreastCount;this.yesterdayBreastCount=yesterdayBreastCount;
            this.todayOtherMl=todayOtherMl;this.yesterdayOtherMl=yesterdayOtherMl;
        }
    }
    private static long startOfDay(int daysFromToday){
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_MONTH,daysFromToday);return c.getTimeInMillis();
    }
    private static boolean isBreastFeeding(Map<String,Object> row){
        if(Boolean.TRUE.equals(row.get("legacy")))return false;
        Object parts=row.get("feedParts");
        if(parts instanceof Map){
            Map<?,?> p=(Map<?,?>)parts;
            return FamilyStore.number(p.get("breastMl"))>0 || Boolean.TRUE.equals(p.get("breastUnmeasured"));
        }
        // Older single-type events without feedParts are still counted.
        return FamilyStore.BREAST.equals(row.get("feedType"));
    }
    private static int expressedAndFormula(Map<String,Object> row){
        if(Boolean.TRUE.equals(row.get("legacy")))return 0;
        Object parts=row.get("feedParts");
        if(parts instanceof Map){
            Map<?,?> p=(Map<?,?>)parts;
            return Math.max(0,FamilyStore.number(p.get("pumpedMl")))
                + Math.max(0,FamilyStore.number(p.get("formulaMl")));
        }
        String type=(String)row.get("feedType");
        return FamilyStore.PUMPED.equals(type)||FamilyStore.FORMULA.equals(type)
            ? Math.max(0,FamilyStore.number(row.get("ml"))) : 0;
    }
    static void update(Context c,List<DocumentSnapshot> events){
        long today=startOfDay(0),yesterday=startOfDay(-1),now=System.currentTimeMillis();
        int todayBreast=0,yesterdayBreast=0,todayOther=0,yesterdayOther=0;
        long last=-1,lastPoop=-1,lastPee=-1;
        for(DocumentSnapshot snap:events){
            Date date=snap.getDate("at");
            if(date==null)continue;
            long ts=date.getTime();if(ts>now+300000)continue;
            String kind=snap.getString("kind");
            if(FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))lastPoop=Math.max(lastPoop,ts);
            if(FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))lastPee=Math.max(lastPee,ts);
            if(!FamilyStore.FEED.equals(kind))continue;
            if(ts>last)last=ts;
            Map<String,Object> row=snap.getData();if(row==null)continue;
            if(ts>=today){if(isBreastFeeding(row))todayBreast++;todayOther+=expressedAndFormula(row);}
            else if(ts>=yesterday){if(isBreastFeeding(row))yesterdayBreast++;yesterdayOther+=expressedAndFormula(row);}
        }
        FamilyStore.prefs(c).edit().putString("quick_stats_family",FamilyStore.code(c))
            .putBoolean("quick_stats_synced_v29",true).putLong("quick_stats_day",today)
            .putLong("quick_stats_last_feed",last)
            .putLong("quick_stats_last_poop",lastPoop).putLong("quick_stats_last_pee",lastPee)
            .putInt("quick_today_breast_count",todayBreast).putInt("quick_yesterday_breast_count",yesterdayBreast)
            .putInt("quick_today_other_ml",todayOther).putInt("quick_yesterday_other_ml",yesterdayOther).apply();
    }
    static Summary get(Context c){
        SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString("quick_stats_family",""))||!p.getBoolean("quick_stats_synced_v29",false))
            return new Summary(false,-1,-1,-1,0,0,0,0);
        long day=p.getLong("quick_stats_day",0),today=startOfDay(0),yesterday=startOfDay(-1);
        int tb=p.getInt("quick_today_breast_count",0),yb=p.getInt("quick_yesterday_breast_count",0);
        int tm=p.getInt("quick_today_other_ml",0),ym=p.getInt("quick_yesterday_other_ml",0);
        // If midnight passed before background refresh, yesterday's today values remain useful.
        if(day==yesterday){yb=tb;ym=tm;tb=0;tm=0;}
        else if(day!=today){tb=0;yb=0;tm=0;ym=0;}
        return new Summary(true,p.getLong("quick_stats_last_feed",-1),
            p.getLong("quick_stats_last_poop",-1),p.getLong("quick_stats_last_pee",-1),tb,yb,tm,ym);
    }
    private QuickStats(){}
}
