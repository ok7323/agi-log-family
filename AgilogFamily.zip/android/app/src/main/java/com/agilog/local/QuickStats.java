package com.agilog.local;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.firestore.DocumentSnapshot;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Cached local widget summary. A rolling 72-hour refresh supplies the
 *  measured pumping history for both widget estimation and daily totals. */
final class QuickStats {
    private static final String CACHE="quick_stats_recent_cache_v225";
    private static final String CACHE_FAMILY="quick_stats_cache_family_v225";
    static final long RECENT_MS=72L*60*60*1000;
    static final class Summary {
        final boolean synced;
        final long lastFeed, previousFeed, lastPoop, lastPee, lastPump, previousPump;
        final String lastFeedAmount, previousFeedAmount;
        final int todayBreastCount, yesterdayBreastCount;
        final int todayPumpedMl, yesterdayPumpedMl, todayFormulaMl, yesterdayFormulaMl;
        final double pumpFactor;
        final int pumpSamples;
        Summary(boolean synced, long lastFeed, long previousFeed, long lastPoop, long lastPee, long lastPump, long previousPump,
                String lastFeedAmount, String previousFeedAmount,
                int todayBreastCount, int yesterdayBreastCount,
                int todayPumpedMl, int yesterdayPumpedMl, int todayFormulaMl, int yesterdayFormulaMl,
                double pumpFactor,int pumpSamples) {
            this.synced=synced; this.lastFeed=lastFeed; this.previousFeed=previousFeed;
            this.lastFeedAmount=lastFeedAmount; this.previousFeedAmount=previousFeedAmount;
            this.lastPoop=lastPoop; this.lastPee=lastPee; this.lastPump=lastPump; this.previousPump=previousPump;
            this.todayBreastCount=todayBreastCount; this.yesterdayBreastCount=yesterdayBreastCount;
            this.todayPumpedMl=todayPumpedMl; this.yesterdayPumpedMl=yesterdayPumpedMl;
            this.todayFormulaMl=todayFormulaMl; this.yesterdayFormulaMl=yesterdayFormulaMl;
            this.pumpFactor=pumpFactor;this.pumpSamples=pumpSamples;
        }
    }
    private static final class Entry {
        String id,kind,amount;
        long at;
        boolean breast,isMeasuredPump;
        int pumpMl,pumped,formula;
        JSONObject json(){
            JSONObject j=new JSONObject();
            try{j.put("id",id);j.put("kind",kind);j.put("at",at);j.put("amount",amount);
                j.put("breast",breast);j.put("pumpMl",pumpMl);j.put("isMeasuredPump",isMeasuredPump);
                j.put("pumped",pumped);j.put("formula",formula);}catch(Exception ignored){}
            return j;
        }
        Entry(JSONObject j){id=j.optString("id","");kind=j.optString("kind","");at=j.optLong("at",0);
            amount=j.optString("amount","미측정");breast=j.optBoolean("breast",false);
            pumpMl=j.optInt("pumpMl",0);isMeasuredPump=j.optBoolean("isMeasuredPump",false);
            pumped=j.optInt("pumped",0);formula=j.optInt("formula",0);}
        Entry(DocumentSnapshot d){
            id=d.getId();Date date=d.getDate("at");at=date==null?0:date.getTime();
            Map<String,Object> row=d.getData();if(row==null)row=Collections.emptyMap();
            kind=String.valueOf(row.get("kind"));
            pumpMl=FamilyStore.PUMP.equals(kind)?Math.max(0,FamilyStore.number(row.get("ml"))):0;
            isMeasuredPump=pumpMl>0;
            boolean legacy=Boolean.TRUE.equals(row.get("legacy"));
            Object parts=row.get("feedParts");
            int measured=0;boolean unmeasured=false;
            if(parts instanceof Map){Map<?,?> p=(Map<?,?>)parts;
                int b=Math.max(0,FamilyStore.number(p.get("breastMl")));
                pumped=Math.max(0,FamilyStore.number(p.get("pumpedMl")));
                formula=Math.max(0,FamilyStore.number(p.get("formulaMl")));
                unmeasured=Boolean.TRUE.equals(p.get("breastUnmeasured"));
                breast=b>0||unmeasured; measured=b+pumped+formula;
            }else if(!legacy){
                int ml=FamilyStore.number(row.get("ml"));String type=String.valueOf(row.get("feedType"));
                breast=FamilyStore.BREAST.equals(type);
                if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
                unmeasured=breast&&ml==-1;measured=Math.max(0,ml);
            }
            if(legacy){breast=false;pumped=0;formula=0;measured=0;unmeasured=false;}
            amount=measured==0?"미측정":measured+"mL"+(unmeasured?"+모유 미측정":"");
        }
    }
    private static long startOfDay(int offset){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);
        c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_MONTH,offset);return c.getTimeInMillis();}
    static String compactAmount(String full){if(full==null||full.isEmpty())return "--";
        return full.replace("mL","").replace("+모유 미측정","+?").replace("미측정","?");}
    private static Map<String,Entry> load(Context c){
        HashMap<String,Entry> out=new HashMap<>();SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString(CACHE_FAMILY,"")))return out;
        try{JSONArray a=new JSONArray(p.getString(CACHE,"[]"));for(int i=0;i<a.length();i++){
            Entry e=new Entry(a.getJSONObject(i));if(!e.id.isEmpty())out.put(e.id,e);
        }}catch(Exception ignored){}
        return out;
    }
    /** Foreground full-history result: replace the local cache with a rolling 72-hour window. */
    static synchronized void update(Context c,List<DocumentSnapshot> all){merge(c,all,false);}
    /** Auto/manual refresh: rolling 72-hour docs are fetched and merged. */
    static synchronized void updateRecent(Context c,List<DocumentSnapshot> recent){merge(c,recent,true);}
    private static void merge(Context c,List<DocumentSnapshot> docs,boolean partial){
        long now=System.currentTimeMillis();long keepFrom=now-RECENT_MS;
        Map<String,Entry> map=partial?load(c):new HashMap<>();
        if(partial){long cutoff=now-RECENT_MS;
            // Recent server results are authoritative for this sliding interval:
            // this also removes recent records deleted on another device.
            map.values().removeIf(e->e.at>=cutoff);
        }
        for(DocumentSnapshot doc:docs){Entry e=new Entry(doc);
            if(e.at>=keepFrom&&e.at<=now+300000L)map.put(e.id,e);
        }
        map.values().removeIf(e->e.at<keepFrom||e.at>now+300000L);
        ArrayList<Entry> entries=new ArrayList<>(map.values());
        entries.sort(Comparator.comparingLong(e->e.at));
        JSONArray json=new JSONArray();for(Entry e:entries)json.put(e.json());
        long today=startOfDay(0),yesterday=startOfDay(-1);
        int tb=0,yb=0,tp=0,yp=0,tf=0,yf=0;
        long last=-1,prev=-1,lastPoop=-1,lastPee=-1,lastPump=-1,previousPump=-1,sessionStart=-1;
        PumpHistory pumpTimes=new PumpHistory();
        ArrayList<PumpForecast.Event> pumpForecastEvents=new ArrayList<>();
        String lastAmount="--",prevAmount="--";boolean sessionHasBreast=false;
        int sessionDay=0;
        for(Entry e:entries){
            if(FamilyStore.POOP.equals(e.kind)||FamilyStore.BOTH.equals(e.kind))lastPoop=Math.max(lastPoop,e.at);
            if(FamilyStore.PEE.equals(e.kind)||FamilyStore.BOTH.equals(e.kind))lastPee=Math.max(lastPee,e.at);
            // Reset after pumping OR feeding directly from the breast, including
            // a mixed feed with a direct-breast component.
            if(FamilyStore.PUMP.equals(e.kind)
                ||(FamilyStore.FEED.equals(e.kind)&&e.breast)){
                pumpTimes.add(e.at);
                pumpForecastEvents.add(new PumpForecast.Event(e.at,
                    FamilyStore.PUMP.equals(e.kind),e.isMeasuredPump?e.pumpMl:0));
            }
            if(!FamilyStore.FEED.equals(e.kind))continue;
            prev=last;prevAmount=lastAmount;last=e.at;lastAmount=e.amount;
            if(e.at>=today){tp+=e.pumped;tf+=e.formula;}
            else if(e.at>=yesterday){yp+=e.pumped;yf+=e.formula;}
            if(sessionStart<0||e.at-sessionStart>=60*60*1000L){
                if(sessionHasBreast){if(sessionDay==1)tb++;else if(sessionDay==2)yb++;}
                sessionStart=e.at;sessionHasBreast=e.breast;
                sessionDay=e.at>=today?1:e.at>=yesterday?2:0;
            }else if(e.breast)sessionHasBreast=true;
        }
        if(sessionHasBreast){if(sessionDay==1)tb++;else if(sessionDay==2)yb++;}
        if(!partial){
            // The foreground query can contain old pump records beyond the 3-day summary cache.
            for(DocumentSnapshot doc:docs){
                Entry e=new Entry(doc);
                if((FamilyStore.PUMP.equals(e.kind)||
                    (FamilyStore.FEED.equals(e.kind)&&e.breast))
                    &&e.at>0&&e.at<=now+300000L)pumpTimes.add(e.at);
            }
        }else if(FamilyStore.code(c).equals(FamilyStore.prefs(c).getString("quick_stats_family",""))){
            // Preserve a previous milk-removal event older than 72h when polling the 72h window.
            // If a recent pump was deleted, it is not resurrected from old preferences.
            long prior=FamilyStore.prefs(c).getLong("quick_stats_last_pump",-1L);
            long older=FamilyStore.prefs(c).getLong("quick_stats_previous_pump",-1L);
            if(prior>0&&prior<now-RECENT_MS)pumpTimes.add(prior);
            if(older>0&&older<now-RECENT_MS)pumpTimes.add(older);
        }
        lastPump=pumpTimes.latest();
        previousPump=pumpTimes.previous();
        PumpForecast.Model pumpModel=PumpForecast.analyze(pumpForecastEvents,now);
        FamilyStore.prefs(c).edit().putString(CACHE_FAMILY,FamilyStore.code(c)).putString(CACHE,json.toString())
            .putString("quick_stats_family",FamilyStore.code(c)).putBoolean("quick_stats_synced_v210",true)
            .putLong("quick_stats_day",today)
            .putLong("quick_stats_last_feed",last).putLong("quick_stats_previous_feed",prev)
            .putString("quick_stats_last_amount",lastAmount).putString("quick_stats_previous_amount",prevAmount)
            .putLong("quick_stats_last_poop",lastPoop).putLong("quick_stats_last_pee",lastPee)
            .putLong("quick_stats_last_pump",lastPump).putLong("quick_stats_previous_pump",previousPump)
            .putFloat("quick_stats_pump_factor_v282",(float)pumpModel.factor)
            .putInt("quick_stats_pump_samples_v282",pumpModel.samples)
            .putInt("quick_today_breast_count",tb).putInt("quick_yesterday_breast_count",yb)
            .putInt("quick_today_pumped_ml",tp).putInt("quick_yesterday_pumped_ml",yp)
            .putInt("quick_today_formula_ml",tf).putInt("quick_yesterday_formula_ml",yf)
            .apply();
    }
    static Summary get(Context c){
        SharedPreferences p=FamilyStore.prefs(c);
        if(!FamilyStore.code(c).equals(p.getString("quick_stats_family",""))||!p.getBoolean("quick_stats_synced_v210",false))
            return new Summary(false,-1,-1,-1,-1,-1,-1,"--","--",0,0,0,0,0,0,1d,0);
        long day=p.getLong("quick_stats_day",0),today=startOfDay(0),yesterday=startOfDay(-1);
        int tb=p.getInt("quick_today_breast_count",0),yb=p.getInt("quick_yesterday_breast_count",0);
        int tp=p.getInt("quick_today_pumped_ml",0),yp=p.getInt("quick_yesterday_pumped_ml",0);
        int tf=p.getInt("quick_today_formula_ml",0),yf=p.getInt("quick_yesterday_formula_ml",0);
        if(day==yesterday){yb=tb;yp=tp;yf=tf;tb=0;tp=0;tf=0;}
        else if(day!=today){tb=0;yb=0;tp=0;yp=0;tf=0;yf=0;}
        return new Summary(true,p.getLong("quick_stats_last_feed",-1),p.getLong("quick_stats_previous_feed",-1),
            p.getLong("quick_stats_last_poop",-1),p.getLong("quick_stats_last_pee",-1),
            p.getLong("quick_stats_last_pump",-1),p.getLong("quick_stats_previous_pump",-1),
            p.getString("quick_stats_last_amount","--"),p.getString("quick_stats_previous_amount","--"),
            tb,yb,tp,yp,tf,yf,
            p.getFloat("quick_stats_pump_factor_v282",1f),p.getInt("quick_stats_pump_samples_v282",0));
    }
    private QuickStats(){}
}
