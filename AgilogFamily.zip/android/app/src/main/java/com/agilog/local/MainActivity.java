package com.agilog.local;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.view.View;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebResourceResponse;
import android.webkit.CookieManager;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.Source;
import com.google.firebase.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private final int BACK=0xFFFFF9F6,INK=0xFF644B56,MUTED=0xFF9F8993,BLUSH=0xFFF6E0E8;
    private final ArrayList<DocumentSnapshot> events=new ArrayList<>();
    private ListenerRegistration listener;
    private static volatile boolean foregroundActive=false;
    static boolean isForeground(){return foregroundActive;}
    private String state="loading";
    private String status="가족 연결 준비 중...";
    private TextView dailyFeed, dailyPoop, dailyPee, lastFeed, lastFeedAmount, previousFeed, previousFeedAmount, lastPoop, lastPee, yesterdayFeed;
    private TextView todayBreast, todayPumped, todayFormula, dailyDiapers, yesterdayDiapers;
    private boolean olderRecordsExpanded=false;
    private int olderRecordsVisible=100;
    private String pendingFamilyCsv=null;
    private int pendingFamilyCsvCount=0;
    private static final int FAMILY_CSV_REQUEST=8125;
    private boolean statisticsTab=false;
    private boolean toolsTab=false;
    private ToolCloudSync toolSync;
    private ValueCallback<Uri[]> toolFileCallback;
    private static final int TOOL_FILE_REQUEST=8124;
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent result){
        super.onActivityResult(requestCode,resultCode,result);
        if(requestCode==TOOL_FILE_REQUEST){
            ValueCallback<Uri[]> cb=toolFileCallback;toolFileCallback=null;
            if(cb!=null){Uri uri=(resultCode==RESULT_OK&&result!=null)?result.getData():null;
                cb.onReceiveValue(uri==null?null:new Uri[]{uri});}
        }
        if(requestCode==FAMILY_CSV_REQUEST){
            String csv=pendingFamilyCsv;pendingFamilyCsv=null;
            if(resultCode==RESULT_OK&&result!=null&&result.getData()!=null&&csv!=null){
                try(OutputStream out=getContentResolver().openOutputStream(result.getData())){
                    if(out==null)throw new IllegalStateException("파일을 열 수 없습니다");
                    out.write(("\uFEFF"+csv).getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"가족 전체 "+pendingFamilyCsvCount+"건 CSV 저장 완료",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(this,"CSV 파일 저장 실패: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }
        }
    }
    private void exportAllFamilyRecords(Button trigger){
        String code=FamilyStore.code(this);
        if(!"ready".equals(state)||code.isEmpty()){
            Toast.makeText(this,"먼저 가족에 연결해 주세요.",Toast.LENGTH_LONG).show();return;
        }
        trigger.setEnabled(false);trigger.setText("Firebase에서 전체 기록 조회 중…");
        FamilyStore.db().collection("families").document(code).collection("events")
            .orderBy("at",Query.Direction.DESCENDING).get(Source.SERVER)
            .addOnSuccessListener(snapshot->{
                trigger.setEnabled(true);trigger.setText("📥 가족 전체 기록 CSV 저장");
                if(!code.equals(FamilyStore.code(this)))return; // Family changed while loading.
                try{
                    ArrayList<FamilyCsv.Entry> rows=new ArrayList<>();
                    for(DocumentSnapshot d:snapshot.getDocuments())rows.add(new FamilyCsv.Entry(d.getId(),d.getData(),d.getDate("at")));
                    pendingFamilyCsv=FamilyCsv.serialize(rows);
                    pendingFamilyCsvCount=rows.size();
                    String name="AgilogFamily_AllRecords_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new Date())+".csv";
                    Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType("text/csv");save.putExtra(Intent.EXTRA_TITLE,name);
                    startActivityForResult(save,FAMILY_CSV_REQUEST);
                }catch(Exception ex){pendingFamilyCsv=null;Toast.makeText(this,"CSV 준비 실패: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }).addOnFailureListener(e->{
                trigger.setEnabled(true);trigger.setText("📥 가족 전체 기록 CSV 저장");
                Toast.makeText(this,"CSV 조회 실패 · 인터넷/가족 권한 확인: "+e.getMessage(),Toast.LENGTH_LONG).show();
            });
    }
    private void saveToolDownload(String name,String body,String mime){
        try{
            if(Build.VERSION.SDK_INT>=29){
                ContentValues values=new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME,name.replaceAll("[^A-Za-z0-9._-]","_"));
                values.put(MediaStore.MediaColumns.MIME_TYPE,mime.startsWith("text/csv")?"text/csv":"application/json");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/");
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                if(uri==null)throw new Exception("다운로드 폴더에 저장 실패");
                try(OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new Exception("저장 공간에 접근할 수 없습니다");
                    out.write(body.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this,"다운로드 폴더에 저장됨: "+name,Toast.LENGTH_LONG).show();
            }else{
                Intent share=new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,body);
                startActivity(Intent.createChooser(share,"백업 내용 공유"));
            }
        }catch(Exception e){Toast.makeText(this,"백업 저장 실패: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private int statisticsPeriod=7;
    private TextView yesterdayBreast, yesterdayPumped, yesterdayFormula, yesterdayPoop, yesterdayPee;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable elapsedTick=new Runnable(){@Override public void run(){if("ready".equals(state))updateSummary();timer.postDelayed(this,60000L);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);
        // v2.25 switches to battery-friendly 30-minute sync by default.
        // Previous fast-sync opt-in is cleared once; users can explicitly turn it back on.
        if(!FamilyStore.prefs(this).getBoolean("sync_mode_v225_initialized",false)){
            FastFamilySyncService.setEnabled(this,false);
            FamilyStore.prefs(this).edit().putBoolean("sync_mode_v225_initialized",true).apply();
        }
        draw();
        if(FirebaseAuth.getInstance().getCurrentUser()!=null)afterAuth();
        else FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(a->afterAuth()).addOnFailureListener(e->fail("로그인 실패: "+e.getMessage()));
    }
    @Override protected void onResume(){
        super.onResume();
        foregroundActive=true;
        timer.removeCallbacks(elapsedTick);
        timer.post(elapsedTick); // Foreground-only minute update; never runs when paused.
        startForegroundListener();
        if("ready".equals(state))startFastFamilySyncIfWanted();
        if(QuickNotification.enabled(this))QuickNotification.show(this);
        openFeedFromWidgetIfRequested();
    }
    @Override protected void onPause(){
        foregroundActive=false;
        timer.removeCallbacks(elapsedTick);
        stopForegroundListener(); // No Firestore live stream while screen/app is inactive.
        super.onPause();
    }
    @Override protected void onDestroy(){
        timer.removeCallbacks(elapsedTick);
        stopForegroundListener();
        if(toolSync!=null){toolSync.close();toolSync=null;}
        super.onDestroy();
    }
    private void stopForegroundListener(){
        if(listener!=null){listener.remove();listener=null;}
    }
    private void startForegroundListener(){
        if(!foregroundActive||listener!=null||!"ready".equals(state)||FamilyStore.code(this).isEmpty())return;
        listener=FamilyStore.db().collection("families").document(FamilyStore.code(this)).collection("events")
            .orderBy("at", Query.Direction.DESCENDING)
            .addSnapshotListener((snap,error)->{
                if(!foregroundActive)return;
                if(error!=null){status="기록 불러오기 오류: "+error.getMessage();draw();return;}
                events.clear();
                if(snap!=null){events.addAll(snap.getDocuments());QuickStats.update(this,snap.getDocuments());}
                if(!toolsTab)draw();
                QuickNotification.show(this);
                HomeWidgetProvider.updateAll(this);
            });
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(3),dp(top),dp(3),dp(bottom));return p;}
    private LinearLayout.LayoutParams flex(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1f);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private TextView text(String val,int size,boolean bold){TextView t=new TextView(this);t.setText(val);t.setTextSize(size);t.setTextColor(INK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String title){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextSize(14);b.setTextColor(INK);b.setBackground(bg(BLUSH));return b;}
    private LinearLayout card(){LinearLayout l=col();l.setPadding(dp(17),dp(18),dp(17),dp(18));l.setBackground(bg(Color.WHITE));return l;}
    private void fail(String message){status=message;Toast.makeText(this,message,Toast.LENGTH_LONG).show();draw();}
    private void afterAuth(){String code=FamilyStore.code(this);
        if(!code.isEmpty()){
            FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid())
                .get().addOnSuccessListener(d->{if(d.exists())connected();else{state="connect";draw();}})
                .addOnFailureListener(e->{state="connect";fail("가족 확인 실패: "+e.getMessage());});
        }else{state="connect";draw();}
    }
    private void connect(boolean create,String name,String code){
        name=name.trim();code=code.trim().toUpperCase().replaceAll("[\\s-]","");
        if(name.isEmpty()||name.length()>40){fail("이름은 1~40자로 입력해 주세요.");return;}
        if(create)code=FamilyStore.randomCode();
        if(!FamilyStore.validCode(code)){fail("가족 코드를 20자리로 입력해 주세요.");return;}
        final String family=code,who=name;
        status="가족 연결 중...";draw();
        if(create){Map<String,Object> familyData=new HashMap<>();familyData.put("createdBy",FamilyStore.uid());familyData.put("createdAt",FieldValue.serverTimestamp());
            FamilyStore.db().collection("families").document(family).set(familyData)
                .addOnSuccessListener(v->addMember(family,who))
                .addOnFailureListener(e->{state="connect";fail("가족 만들기 실패: "+e.getMessage());});
        }else addMember(family,who);
    }
    private void addMember(String code,String who){
        Map<String,Object> member=new HashMap<>();member.put("name",who);member.put("joinedAt",FieldValue.serverTimestamp());
        var ref=FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid());
        ref.set(member).addOnSuccessListener(v->{FamilyStore.setFamily(this,code,who);connected();})
           .addOnFailureListener(e->ref.get().addOnSuccessListener(existing->{
               if(existing.exists()){FamilyStore.setFamily(this,code,who);connected();}
               else{state="connect";fail("가족 코드를 확인해 주세요: "+e.getMessage());}
           }).addOnFailureListener(e2->{state="connect";fail("가입 실패: "+e.getMessage());}));
    }
    private void connected(){state="ready";status="";draw();
        if(QuickNotification.enabled(this)||HomeWidgetProvider.hasWidgets(this)){
            QuickStatsWorker.schedule(this);
            if(!foregroundActive)QuickStatsWorker.request(this); // The foreground listener already gets fresh data.
        }
        QuickNotification.show(this);
        HomeWidgetProvider.updateAll(this);
        openFeedFromWidgetIfRequested();
        stopForegroundListener();
        startForegroundListener();
        startFastFamilySyncIfWanted();
    }
    private void startFastFamilySyncIfWanted(){
        try{FastFamilySyncService.startIfEnabled(this);}
        catch(RuntimeException ex){
            Toast.makeText(this,"빠른 동기화를 시작할 수 없습니다. 절약 모드로 동작합니다.",Toast.LENGTH_LONG).show();
        }
    }
    private void toggleFastFamilySync(){
        if(FastFamilySyncService.enabled(this)){
            FastFamilySyncService.setEnabled(this,false);
            draw();
        }else{
            new AlertDialog.Builder(this).setTitle("가족 위젯 빠른 동기화")
                .setMessage("다른 가족의 기록을 빠르게 받아 위젯을 갱신합니다(3분 이내 목표). 사용 중에는 지속 알림이 뜨고 배터리가 더 소모될 수 있습니다. 잠금/절전 중에는 3분을 보장할 수 없으며 Android 15 이상에서는 사용 시간이 제한됩니다.")
                .setNegativeButton("취소",null)
                .setPositiveButton("빠른 동기화 켜기",(d,w)->{
                    try{FastFamilySyncService.setEnabled(this,true);draw();}
                    catch(RuntimeException ex){
                        FastFamilySyncService.setEnabled(this,false);
                        Toast.makeText(this,"빠른 동기화를 시작할 수 없습니다.",Toast.LENGTH_LONG).show();
                        draw();
                    }
                }).show();
        }
    }
    private void draw(){
        if(toolSync!=null){toolSync.close();toolSync=null;}
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BACK);
        LinearLayout root=col();root.setPadding(dp(15),dp(27),dp(15),dp(50));scroll.addView(root);setContentView(scroll);
        root.addView(text("우리 아이 하루를 함께",12,false));
        LinearLayout header=row();
        header.addView(text("아기로그 가족 🍼",26,true),flex(90));
        Button settingsButton=button("⚙ 설정");settingsButton.setTextSize(11);settingsButton.setPadding(dp(7),dp(5),dp(7),dp(5));
        settingsButton.setOnClickListener(v->showFeedSettings());header.addView(settingsButton,margin(79,34,0,0));
        root.addView(header,margin(-1,-2,3,8));
        if(status!=null&&!status.isEmpty()){TextView message=text(status,12,false);message.setTextColor(MUTED);root.addView(message,margin(-1,-2,0,18));}
        if("loading".equals(state))return;
        if("connect".equals(state)){
            LinearLayout c=card();c.addView(text("가족 코드로 연결하기",20,true),margin(-1,-2,0,10));
            EditText name=new EditText(this);name.setSingleLine(true);name.setHint("이름: 엄마, 아빠 등");name.setText(FamilyStore.name(this));c.addView(name);
            Button create=button("새 가족 만들기");create.setOnClickListener(v->connect(true,name.getText().toString(),""));c.addView(create,margin(-1,50,8,15));
            EditText code=new EditText(this);code.setSingleLine(true);code.setHint("가족 초대 코드 20자리");c.addView(code);
            Button join=button("가족 코드로 참여하기");join.setOnClickListener(v->connect(false,name.getText().toString(),code.getText().toString()));c.addView(join,margin(-1,50,8,0));
            root.addView(c);return;
        }
        // Native screen tabs. Keep the selected screen during Firestore snapshot refreshes.
        LinearLayout tabs=row();
        Button recordsTab=button("🍼 기록"),statsTab=button("📊 통계"),toolButton=button("🧸 육아 도구");
        recordsTab.setTextSize(12);statsTab.setTextSize(12);toolButton.setTextSize(12);
        recordsTab.setTextColor((statisticsTab||toolsTab)?INK:Color.WHITE);
        statsTab.setTextColor(statisticsTab?Color.WHITE:INK);
        toolButton.setTextColor(toolsTab?Color.WHITE:INK);
        if(!statisticsTab&&!toolsTab)recordsTab.setBackground(bg(0xFFD88692));
        if(statisticsTab)statsTab.setBackground(bg(0xFFD88692));
        if(toolsTab)toolButton.setBackground(bg(0xFFD88692));
        recordsTab.setOnClickListener(v->{statisticsTab=false;toolsTab=false;draw();});
        statsTab.setOnClickListener(v->{statisticsTab=true;toolsTab=false;draw();});
        toolButton.setOnClickListener(v->{statisticsTab=false;toolsTab=true;draw();});
        tabs.addView(recordsTab,flex(47));tabs.addView(statsTab,flex(47));tabs.addView(toolButton,flex(47));
        root.addView(tabs,margin(-1,-2,0,12));
        if(toolsTab){
            root.removeView(tabs);
            LinearLayout page=col();page.setBackgroundColor(BACK);
            page.setPadding(dp(11),dp(20),dp(11),dp(5));
            LinearLayout toolsHeader=row();toolsHeader.addView(text("아기로그 가족 🍼",23,true),flex(90));
            Button toolsSettings=button("⚙ 설정");toolsSettings.setTextSize(11);
            toolsSettings.setOnClickListener(v->showFeedSettings());toolsHeader.addView(toolsSettings,margin(79,34,0,0));
            page.addView(toolsHeader,margin(-1,-2,0,6));
            page.addView(tabs,margin(-1,-2,0,5));
            WebView toolWeb=new WebView(this);toolWeb.setBackgroundColor(BACK);
            // This WebView holds a native Firebase bridge. Never allow it to load
            // untrusted pages, local files, or third-party resources.
            WebSettings toolSettings=toolWeb.getSettings();
            toolSettings.setJavaScriptEnabled(true); // required for bundled tools UI
            toolSettings.setDomStorageEnabled(true);
            toolSettings.setAllowFileAccess(false);
            toolSettings.setAllowContentAccess(false);
            toolSettings.setAllowFileAccessFromFileURLs(false);
            toolSettings.setAllowUniversalAccessFromFileURLs(false);
            toolSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            toolSettings.setSupportMultipleWindows(false);
            toolSettings.setSaveFormData(false);
            if(Build.VERSION.SDK_INT>=26)toolSettings.setSafeBrowsingEnabled(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(toolWeb,false);
            toolWeb.setWebViewClient(new WebViewClient(){
                @Override public WebResourceResponse shouldInterceptRequest(WebView view,android.webkit.WebResourceRequest req){
                    // All HTML/CSS/JS is embedded locally; no remote requests are needed.
                    // In particular a malicious subframe must never gain the JS bridge.
                    Uri uri=req.getUrl();
                    if("about".equalsIgnoreCase(uri.getScheme()))return null;
                    return new WebResourceResponse("text/plain","UTF-8",
                        new ByteArrayInputStream(new byte[0]));
                }
                @Override public void onPageFinished(WebView view,String url){
                    if(toolSync!=null)toolSync.close();
                    toolSync=new ToolCloudSync(MainActivity.this,toolWeb,FamilyStore.code(MainActivity.this));
                    toolSync.start();
                }
                @Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){
                    return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
                }
            });
            toolWeb.addJavascriptInterface(new Object(){
                @JavascriptInterface public void download(String name,String contents,String mime){
                    // Bound native bridge arguments to prevent memory/storage exhaustion.
                    if(name==null||name.length()>100||contents==null||contents.length()>2_000_000
                        ||mime==null||!(mime.startsWith("application/json")||mime.startsWith("text/csv")))return;
                    runOnUiThread(()->saveToolDownload(name,contents,mime));
                }
                @JavascriptInterface public void toolChange(String json){
                    if(json==null||json.length()>32_768)return;
                    runOnUiThread(()->{if(toolSync!=null)toolSync.write(json);});
                }
            },"AgilogNative");
            toolWeb.setWebChromeClient(new WebChromeClient(){
                @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                    if(toolFileCallback!=null)toolFileCallback.onReceiveValue(null);
                    toolFileCallback=callback;
                    try{Intent open=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        open.setType("application/json");open.addCategory(Intent.CATEGORY_OPENABLE);
                        startActivityForResult(open,TOOL_FILE_REQUEST);return true;
                    }catch(Exception ex){toolFileCallback=null;callback.onReceiveValue(null);return false;}
                }
            });
            page.addView(toolWeb,new LinearLayout.LayoutParams(-1,0,1));
            setContentView(page);
            try(InputStream input=getAssets().open("parenting-tools.html")){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                byte[] buffer=new byte[8192];int count;
                while((count=input.read(buffer))!=-1)bytes.write(buffer,0,count);
                toolWeb.loadDataWithBaseURL("https://appassets.androidplatform.net/",
                    new String(bytes.toByteArray(),StandardCharsets.UTF_8),"text/html","UTF-8",null);
            }catch(Exception exc){toolWeb.loadData("<p>육아 도구 화면을 열 수 없습니다.</p>","text/html","UTF-8");}
            return;
        }
        if(statisticsTab){drawStatistics(root);return;}
        // Ordering: latest elapsed times -> quick record -> today -> yesterday -> history -> invitation.
        LinearLayout elapsed=card();elapsed.setPadding(dp(16),dp(12),dp(16),dp(11));elapsed.addView(text("마지막 기록으로부터",18,true));
        LinearLayout feedingTimes=row();
        TextView[] current=feedSummaryTile(feedingTimes,"🍼 마지막 수유");
        lastFeed=current[0];lastFeedAmount=current[1];
        TextView[] previous=feedSummaryTile(feedingTimes,"🍼 이전 수유");
        previousFeed=previous[0];previousFeedAmount=previous[1];
        elapsed.addView(feedingTimes);
        LinearLayout diaperTimes=row();
        lastPoop=summaryTile(diaperTimes,"💩 대변","기록 없음",true);
        lastPee=summaryTile(diaperTimes,"💧 소변","기록 없음",true);
        elapsed.addView(diaperTimes);root.addView(elapsed,margin(-1,-2,0,12));
        root.addView(text("빠른 기록 +",20,true),margin(-1,-2,0,6));
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH};
        for(int j=0;j<2;j++){
            LinearLayout actions=row();
            for(int i=j*2;i<j*2+2;i++){
                String kind=kinds[i];Button b=button(FamilyStore.icon(kind)+"\n"+FamilyStore.kindLabel(kind));
                b.setOnClickListener(v->{if(FamilyStore.FEED.equals(kind))pickFeed();else pickDiaper(kind);});actions.addView(b,flex(72));
            }root.addView(actions,margin(-1,-2,0,4));
        }
        LinearLayout today=card();today.setPadding(dp(15),dp(12),dp(15),dp(12));today.addView(text("오늘 누적 기록",18,true));
        LinearLayout todayMilks=row();
        todayBreast=summaryTile(todayMilks,"🍼 모유","0회");
        todayPumped=summaryTile(todayMilks,"🍼 유축","0mL");
        todayFormula=summaryTile(todayMilks,"🍼 분유","0mL");
        today.addView(todayMilks);
        LinearLayout todayDiapers=row();
        dailyPoop=summaryTile(todayDiapers,"💩 대변","0회");
        dailyPee=summaryTile(todayDiapers,"💧 소변","0회");
        dailyDiapers=summaryTile(todayDiapers,"🧷 기저귀","0개");
        today.addView(todayDiapers);
        dailyFeed=text("수유 총 0회 · 측정량 0mL",13,true);
        today.addView(dailyFeed,margin(-1,-2,5,0));
        root.addView(today,margin(-1,-2,6,15));

        LinearLayout yesterdayCard=card();yesterdayCard.setPadding(dp(15),dp(12),dp(15),dp(12));yesterdayCard.addView(text("어제 누적 기록",18,true));
        LinearLayout yesterdayMilks=row();
        yesterdayBreast=summaryTile(yesterdayMilks,"🍼 모유","0회");
        yesterdayPumped=summaryTile(yesterdayMilks,"🍼 유축","0mL");
        yesterdayFormula=summaryTile(yesterdayMilks,"🍼 분유","0mL");
        yesterdayCard.addView(yesterdayMilks);
        LinearLayout yesterdayDiaperRow=row();
        yesterdayPoop=summaryTile(yesterdayDiaperRow,"💩 대변","0회");
        yesterdayPee=summaryTile(yesterdayDiaperRow,"💧 소변","0회");
        yesterdayDiapers=summaryTile(yesterdayDiaperRow,"🧷 기저귀","0개");
        yesterdayCard.addView(yesterdayDiaperRow);
        yesterdayFeed=text("수유 총 0회 · 측정량 0mL",13,true);
        yesterdayCard.addView(yesterdayFeed,margin(-1,-2,5,0));
        root.addView(yesterdayCard,margin(-1,-2,0,16));
        updateSummary();
        LinearLayout lock=card();lock.addView(text("🔒 잠금 화면 기록 (알림 1개)",17,true));
        lock.addView(text("잠금 화면에 마지막 수유 후 경과시간, 오늘·어제 모유수유 횟수와 유축+분유 총 mL를 표시합니다. 수유 용량 선택 뒤 현재 시간 또는 이전 시간(−5분 누적)을 저장할 수 있어요. 혼합 수유는 위젯에서 유축 + 분유만 입력합니다. 다른 사람이 잠금 화면에서 이 정보를 볼 수 있습니다.",12,false),margin(-1,-2,7,12));
        Button enabled=button(QuickNotification.enabled(this)?"빠른 기록 끄기":"잠금 화면 빠른 기록 켜기");enabled.setOnClickListener(v->toggle());
        lock.addView(enabled,margin(-1,48,0,0));root.addView(lock,margin(-1,-2,0,12));
        LinearLayout fast=card();fast.setPadding(dp(17),dp(13),dp(17),dp(13));
        fast.addView(text("⚡ 가족 위젯 빠른 동기화 · 3분 목표",17,true));
        fast.addView(text("켜면 가족 기록 변경을 실시간으로 받아 잠금화면·홈 위젯을 바로 갱신합니다. 지속 알림 및 추가 배터리 사용이 있으며, 절전/연결 끊김이나 Android 15의 사용 시간 제한 중에는 3분 보장이 불가능합니다.",12,false),margin(-1,-2,5,6));
        Button faster=button(FastFamilySyncService.enabled(this)?"빠른 동기화 끄기":"빠른 동기화 켜기");
        faster.setOnClickListener(v->toggleFastFamilySync());
        fast.addView(faster,margin(-1,46,0,0));
        root.addView(fast,margin(-1,-2,0,18));
        root.addView(text("가족 최근 기록 · 최근 24시간",19,true),margin(-1,-2,0,9));
        SimpleDateFormat fmt=new SimpleDateFormat("MM월 dd일 HH:mm",Locale.KOREAN);
        long cutoff=System.currentTimeMillis()-24L*60L*60L*1000L;
        ArrayList<DocumentSnapshot> recent=new ArrayList<>(),past=new ArrayList<>();
        for(DocumentSnapshot snap:events){
            Date when=snap.getDate("at");
            if(when!=null&&when.getTime()>=cutoff&&when.getTime()<=System.currentTimeMillis()+300000L)recent.add(snap);
            else past.add(snap);
        }
        TextView count=text("최근 24시간 "+recent.size()+"건 · 이전 기록 "+past.size()+"건",12,false);
        count.setTextColor(MUTED);root.addView(count,margin(-1,-2,0,7));
        if(recent.isEmpty())root.addView(text("최근 24시간 내 기록이 없어요 🌱",15,false));
        for(DocumentSnapshot snap:recent)appendFamilyRecord(root,snap,fmt);
        if(!past.isEmpty()){
            Button toggle=button("");toggle.setTextSize(13);root.addView(toggle,margin(-1,43,5,5));
            LinearLayout pastBox=col();root.addView(pastBox,margin(-1,-2,0,4));
            Button more=button("");more.setTextSize(12);root.addView(more,margin(-1,42,0,9));
            final Runnable[] renderPast=new Runnable[1];
            renderPast[0]=()->{
                toggle.setText(olderRecordsExpanded?"이전 기록 접기 ("+past.size()+"건)":"이전 기록 펼치기 ("+past.size()+"건)");
                pastBox.removeAllViews();
                pastBox.setVisibility(olderRecordsExpanded?View.VISIBLE:View.GONE);
                int shown=olderRecordsExpanded?Math.min(olderRecordsVisible,past.size()):0;
                for(int i=0;i<shown;i++)appendFamilyRecord(pastBox,past.get(i),fmt);
                int remain=past.size()-shown;
                more.setVisibility(olderRecordsExpanded&&remain>0?View.VISIBLE:View.GONE);
                if(remain>0)more.setText("이전 기록 "+Math.min(100,remain)+"건 더 보기 ("+remain+"건 남음)");
            };
            toggle.setOnClickListener(v->{olderRecordsExpanded=!olderRecordsExpanded;olderRecordsVisible=100;renderPast[0].run();});
            more.setOnClickListener(v->{olderRecordsVisible+=100;renderPast[0].run();});
            renderPast[0].run();
        }
        TextView note=text("기존 아기로그 앱은 삭제하지 마세요. 새 가족 앱의 기록부터 공유됩니다.",11,false);note.setTextColor(MUTED);root.addView(note,margin(-1,-2,18,0));
        LinearLayout info=card();info.addView(text("👨‍👩‍👧 가족 초대 코드",17,true));
        TextView code=text(FamilyStore.code(this),17,true);code.setTextIsSelectable(true);info.addView(code,margin(-1,-2,8,4));
        Button share=button("초대 코드 공유");share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"아기로그 가족 코드: "+FamilyStore.code(this));startActivity(Intent.createChooser(i,"가족에게 보내기"));});
        info.addView(share,margin(-1,44,5,0));root.addView(info,margin(-1,-2,16,0));
        // Deliberately placed at the very bottom of the Records tab.
        LinearLayout exportCard=card();exportCard.addView(text("📥 가족 전체 기록 CSV 다운로드",17,true));
        exportCard.addView(text("접혀 있는 예전 기록까지 모두 포함합니다. Firebase에서 전체 수유·기저귀 기록을 조회해 CSV로 저장합니다. 육아 도구 기록은 육아 도구에서 별도 내보내세요.",12,false),margin(-1,-2,7,10));
        Button export=button("📥 가족 전체 기록 CSV 저장");
        export.setOnClickListener(v->exportAllFamilyRecords(export));
        exportCard.addView(export,margin(-1,48,0,8));
        TextView privacy=text("파일에 가족 기록이 포함되니 저장·공유에 주의해 주세요.",11,false);
        privacy.setTextColor(MUTED);exportCard.addView(privacy);
        root.addView(exportCard,margin(-1,-2,10,0));
    }
    private void appendFamilyRecord(LinearLayout root,DocumentSnapshot snap,SimpleDateFormat fmt){
        Map<String,Object> map=snap.getData();if(map==null)return;
        String kind=snap.getString("kind");Date when=snap.getDate("at");
        LinearLayout line=card();line.addView(text(FamilyStore.icon(kind)+" "+FamilyStore.kindLabel(kind)+" · "+fmt.format(when==null?new Date():when),15,true));
        TextView second=text(FamilyStore.detail(map)+" · "+snap.getString("who"),12,false);second.setTextColor(MUTED);line.addView(second,margin(-1,-2,5,0));
        line.setOnClickListener(v->editRecord(snap));
        TextView tap=text("눌러서 시간·양 수정",11,false);tap.setTextColor(0xFFBD8498);line.addView(tap,margin(-1,-2,4,0));
        if(FamilyStore.uid().equals(snap.getString("createdBy")))line.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("가족 기록에서 삭제할까요?")
            .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->snap.getReference().delete().addOnFailureListener(e->fail(e.getMessage()))).show();return true;});
        root.addView(line,margin(-1,-2,0,8));
    }
    private void drawStatistics(LinearLayout root){
        root.addView(text("📊 일별 통계",21,true),margin(-1,-2,4,9));
        LinearLayout period=row();Button week=button("최근 7일"),month=button("최근 30일");
        if(statisticsPeriod==7){week.setBackground(bg(0xFFD88692));week.setTextColor(Color.WHITE);}
        else{month.setBackground(bg(0xFFD88692));month.setTextColor(Color.WHITE);}
        week.setOnClickListener(v->{statisticsPeriod=7;draw();});
        month.setOnClickListener(v->{statisticsPeriod=30;draw();});
        period.addView(week,flex(45));period.addView(month,flex(45));root.addView(period);
        ArrayList<DailyStatistics.Day> days=DailyStatistics.collect(events,statisticsPeriod);
        int feeds=0,breast=0,pumped=0,formula=0,measured=0,diapers=0,poop=0,pee=0;
        for(DailyStatistics.Day d:days){feeds+=d.feedCount;breast+=d.breastCount;pumped+=d.pumpedMl;
            formula+=d.formulaMl;measured+=d.measured;diapers+=d.diapers;poop+=d.poop;pee+=d.pee;}
        LinearLayout overall=card();overall.setPadding(dp(14),dp(13),dp(14),dp(12));
        overall.addView(text("기간별 종합",18,true));
        LinearLayout overview1=row();summaryTile(overview1,"🍼 모유",breast+"회");
        summaryTile(overview1,"🍼 유축",pumped+"mL");summaryTile(overview1,"🍼 분유",formula+"mL");
        overall.addView(overview1);
        LinearLayout overview2=row();summaryTile(overview2,"수유 측정",measured+"mL");
        summaryTile(overview2,"🧷 기저귀",diapers+"개");overview2.addView(text("",1,false),flex(64));
        overall.addView(overview2);
        overall.addView(text("수유 "+feeds+"회 · 대변 "+poop+"회 · 소변 "+pee+"회 · 하루 평균 기저귀 "+String.format(Locale.KOREA,"%.1f",(double)diapers/statisticsPeriod)+"개",12,false),margin(-1,-2,8,0));
        root.addView(overall,margin(-1,-2,8,12));
        LinearLayout milks=card();milks.addView(text("일별 수유량 (mL)",18,true));
        milks.addView(text("■ 분유(분홍)  ■ 유축(파랑)  ■ 모유 측정량(노랑)",11,false),margin(-1,-2,7,2));
        milks.addView(statChart(days,true),margin(-1,-2,3,0));root.addView(milks,margin(-1,-2,0,12));
        LinearLayout diapersCard=card();diapersCard.addView(text("일별 기저귀 사용 (개)",18,true));
        diapersCard.addView(text("소변 1개 · 대변 1개 · 소+대변 1개",12,false),margin(-1,-2,5,0));
        diapersCard.addView(statChart(days,false),margin(-1,-2,3,0));
        root.addView(diapersCard,margin(-1,-2,0,12));
        LinearLayout detail=card();detail.addView(text("날짜별 상세",18,true));
        detail.addView(text("모유는 횟수 / 유축·분유는 mL",12,false),margin(-1,-2,4,8));
        SimpleDateFormat fmt=new SimpleDateFormat("MM/dd",Locale.KOREA);
        for(int i=days.size()-1;i>=0;i--){DailyStatistics.Day d=days.get(i);
            LinearLayout line=col();line.setPadding(dp(5),dp(9),dp(5),dp(9));
            line.addView(text(fmt.format(d.date)+"   모유 "+d.breastCount+"회 · 유축 "+d.pumpedMl+" · 분유 "+d.formulaMl,13,true));
            TextView second=text("수유 "+d.feedCount+"회 · 대변 "+d.poop+"회 · 소변 "+d.pee+"회 · 기저귀 "+d.diapers+"개",12,false);
            second.setTextColor(MUTED);line.addView(second,margin(-1,-2,3,0));detail.addView(line);
        }
        root.addView(detail,margin(-1,-2,0,16));
    }
    /** Uses ordinary Android views so chart bars are visible even on devices
     *  where a custom Canvas view in a nested ScrollView fails to paint. */
    private LinearLayout statChart(ArrayList<DailyStatistics.Day> days,boolean milk){
        LinearLayout outer=col();
        int max=1;
        for(DailyStatistics.Day d:days){
            int value=milk?d.breastMl+d.pumpedMl+d.formulaMl:d.diapers;
            max=Math.max(max,value);
        }
        TextView axis=text((milk?"최대 ":"최대 ")+max+(milk?"mL":"개")+"  ·  날짜별 사용량",11,false);
        axis.setTextColor(MUTED);
        outer.addView(axis,margin(-1,-2,4,4));
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout bars=row();bars.setGravity(Gravity.BOTTOM);
        final int graphHeight=132;
        for(DailyStatistics.Day d:days){
            int amount=milk?d.breastMl+d.pumpedMl+d.formulaMl:d.diapers;
            LinearLayout column=col();column.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView top=text(amount>0?String.valueOf(amount):" ",10,true);
            top.setGravity(Gravity.CENTER);top.setTextColor(INK);
            column.addView(top,new LinearLayout.LayoutParams(dp(46),dp(18)));
            // Stack colored native Views vertically, resting against baseline.
            android.widget.FrameLayout chartCell=new android.widget.FrameLayout(this);
            LinearLayout segments=col();segments.setGravity(Gravity.BOTTOM);
            int totalHeight=(int)Math.round(graphHeight*(amount/(double)max));
            int[] values=milk?new int[]{d.breastMl,d.pumpedMl,d.formulaMl}:new int[]{d.diapers};
            int[] colors=milk?new int[]{0xFFEAC276,0xFF77A6D5,0xFFD88692}:new int[]{0xFF69B59F};
            int used=0;
            // Native vertical stack: last segment appears at bottom, first on top.
            for(int j=0;j<values.length;j++){
                if(values[j]<=0)continue;
                int height=(int)Math.round(graphHeight*(values[j]/(double)max));
                if(j==values.length-1)height=Math.max(1,totalHeight-used);
                height=Math.max(1,height);used+=height;
                View block=new View(this);block.setBackgroundColor(colors[j]);
                segments.addView(block,new LinearLayout.LayoutParams(dp(27),dp(height)));
            }
            if(amount==0){View baseline=new View(this);baseline.setBackgroundColor(0xFFEFE4E7);
                segments.addView(baseline,new LinearLayout.LayoutParams(dp(27),dp(1)));}
            android.widget.FrameLayout.LayoutParams bottom=new android.widget.FrameLayout.LayoutParams(dp(27),dp(graphHeight),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            chartCell.addView(segments,bottom);
            column.addView(chartCell,new LinearLayout.LayoutParams(dp(46),dp(graphHeight)));
            Calendar date=Calendar.getInstance();date.setTime(d.date);
            TextView label=text(String.valueOf(date.get(Calendar.DAY_OF_MONTH)),11,false);
            label.setTextColor(MUTED);label.setGravity(Gravity.CENTER);
            column.addView(label,new LinearLayout.LayoutParams(dp(46),dp(24)));
            bars.addView(column,new LinearLayout.LayoutParams(dp(46),dp(174)));
        }
        scroll.addView(bars,new android.widget.FrameLayout.LayoutParams(dp(days.size()*46),dp(174)));
        outer.addView(scroll,new LinearLayout.LayoutParams(-1,dp(184)));
        return outer;
    }
    private long startToday(){java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private void record(String kind,String type,int ml,String size){RecordWorker.queue(this,kind,type,ml,size);Toast.makeText(this,"기록 전송 대기 중 · 연결되면 가족에게 표시돼요",Toast.LENGTH_SHORT).show();}
    private void pickDiaper(String kind){String[] labels={"소 · 적음","중 · 보통","대 · 많음"},sizes={"small","medium","large"};
        new AlertDialog.Builder(this).setTitle(FamilyStore.kindLabel(kind)+" 양").setItems(labels,(d,i)->record(kind,"",0,sizes[i])).show();}
    private TextView summaryTile(LinearLayout row,String title,String value){
        return summaryTile(row,title,value,false);
    }
    private TextView summaryTile(LinearLayout row,String title,String value,boolean compact){
        LinearLayout tile=col();tile.setPadding(dp(5),dp(7),dp(5),dp(7));tile.setBackground(bg(0xFFFFF0E7));
        TextView label=text(title,12,true);label.setGravity(Gravity.CENTER);tile.addView(label);
        TextView data=text(value,13,true);data.setGravity(Gravity.CENTER);tile.addView(data,margin(-1,-2,3,0));
        row.addView(tile,flex(compact?60:64));return data;
    }
    /** The feeding tiles keep elapsed time prominent and each event's measured amount below it. */
    private TextView[] feedSummaryTile(LinearLayout parent,String label){
        LinearLayout tile=col();tile.setPadding(dp(7),dp(7),dp(7),dp(7));tile.setBackground(bg(0xFFFFF0E7));
        TextView name=text(label,12,true);name.setGravity(Gravity.CENTER);tile.addView(name);
        TextView time=text("기록 없음",19,true);time.setGravity(Gravity.CENTER);tile.addView(time,margin(-1,-2,2,0));
        TextView amount=text("수유량 없음",12,false);amount.setGravity(Gravity.CENTER);
        amount.setTextColor(0xFF78606D);tile.addView(amount,margin(-1,-2,2,0));
        parent.addView(tile,flex(91));return new TextView[]{time,amount};
    }
    private String since(Date date){
        return ElapsedTime.display(date==null?-1:date.getTime());
    }
    private String feedingAmountText(DocumentSnapshot snap){
        if(snap==null)return "수유량 없음";
        Map<String,Object> item=snap.getData();if(item==null||Boolean.TRUE.equals(item.get("legacy")))return "수유량 정보 없음";
        int total=FamilyStore.knownMl(item);
        int breast=sourceAmount(item,"breastMl",FamilyStore.BREAST);
        int pumped=sourceAmount(item,"pumpedMl",FamilyStore.PUMPED);
        int formula=sourceAmount(item,"formulaMl",FamilyStore.FORMULA);
        boolean unknown=FamilyStore.unknownBreast(item);
        ArrayList<String> parts=new ArrayList<>();
        if(breast>0)parts.add("모유 "+breast);
        if(unknown)parts.add("모유 미측정");
        if(pumped>0)parts.add("유축 "+pumped);
        if(formula>0)parts.add("분유 "+formula);
        if(total==0)return unknown?"모유 미측정":"수유량 정보 없음";
        return android.text.TextUtils.join(" + ",parts)+" · 합계 "+total+"mL";
    }
    /** Count breast sessions and milk volumes individually, including older single-source events. */
    private boolean hasBreast(Map<String,Object> item){
        if(Boolean.TRUE.equals(item.get("legacy")))return false;
        Object raw=item.get("feedParts");
        if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
            return FamilyStore.number(p.get("breastMl"))>0||Boolean.TRUE.equals(p.get("breastUnmeasured"));
        }
        return FamilyStore.BREAST.equals(item.get("feedType"));
    }
    private int sourceAmount(Map<String,Object> item,String key,String oldType){
        if(Boolean.TRUE.equals(item.get("legacy")))return 0;
        Object raw=item.get("feedParts");
        if(raw instanceof Map)return Math.max(0,FamilyStore.number(((Map<?,?>)raw).get(key)));
        return oldType.equals(item.get("feedType"))?Math.max(0,FamilyStore.number(item.get("ml"))):0;
    }
    private void updateSummary(){
        if(dailyFeed==null||dailyPoop==null||dailyPee==null||todayBreast==null)return;
        int[] feeds=new int[2], totals=new int[2], breasts=new int[2], pumped=new int[2], formula=new int[2];
        int[] poops=new int[2], pees=new int[2], diapers=new int[2];
        Date lf=null,lp=null,lu=null;
        DocumentSnapshot newestFeed=null,olderFeed=null;
        long day=startToday(),now=System.currentTimeMillis();
        Calendar previous=Calendar.getInstance();previous.setTimeInMillis(day);previous.add(Calendar.DAY_OF_MONTH,-1);
        long yesterday=previous.getTimeInMillis();
        for(DocumentSnapshot snap:events){
            Date date=snap.getDate("at");if(date==null||date.getTime()>now+300000L)continue;
            String kind=snap.getString("kind");if(kind==null)continue;
            if(FamilyStore.FEED.equals(kind)){
                if(newestFeed==null||date.after(newestFeed.getDate("at"))){
                    olderFeed=newestFeed;newestFeed=snap;
                }else if(olderFeed==null||date.after(olderFeed.getDate("at"))){
                    olderFeed=snap;
                }
            }
            if(FamilyStore.FEED.equals(kind)&&(lf==null||date.after(lf)))lf=date;
            if((FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))&&(lp==null||date.after(lp)))lp=date;
            if((FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))&&(lu==null||date.after(lu)))lu=date;
            long at=date.getTime();
            int d=at>=day?0:(at>=yesterday?1:-1);
            if(d<0)continue;
            if(FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))pees[d]++;
            if(FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))poops[d]++;
            if(FamilyStore.PEE.equals(kind)||FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))diapers[d]++;
            if(FamilyStore.FEED.equals(kind)){
                Map<String,Object> item=snap.getData();if(item==null)continue;
                totals[d]+=FamilyStore.knownMl(item);
                pumped[d]+=sourceAmount(item,"pumpedMl",FamilyStore.PUMPED);
                formula[d]+=sourceAmount(item,"formulaMl",FamilyStore.FORMULA);
            }
        }
        // 1-hour sessions are anchored at the first feed. Subsequent feeds
        // within the window contribute milk volume but not another session.
        for(FeedSessions.Session session:FeedSessions.group(events)) {
            int bucket=session.startedAt>=day?0:(session.startedAt>=yesterday?1:-1);
            if(bucket>=0){feeds[bucket]++;if(session.includesBreast)breasts[bucket]++;}
        }
        todayBreast.setText(breasts[0]+"회");todayPumped.setText(pumped[0]+"mL");todayFormula.setText(formula[0]+"mL");
        yesterdayBreast.setText(breasts[1]+"회");yesterdayPumped.setText(pumped[1]+"mL");yesterdayFormula.setText(formula[1]+"mL");
        dailyPoop.setText(poops[0]+"회");dailyPee.setText(pees[0]+"회");
        yesterdayPoop.setText(poops[1]+"회");yesterdayPee.setText(pees[1]+"회");
        dailyDiapers.setText(diapers[0]+"개");yesterdayDiapers.setText(diapers[1]+"개");
        dailyFeed.setText("수유 총 "+feeds[0]+"회 · 측정량 "+totals[0]+"mL");
        yesterdayFeed.setText("수유 총 "+feeds[1]+"회 · 측정량 "+totals[1]+"mL");
        if(lastFeed!=null)lastFeed.setText(since(newestFeed==null?null:newestFeed.getDate("at")));
        if(lastFeedAmount!=null)lastFeedAmount.setText(feedingAmountText(newestFeed));
        if(previousFeed!=null)previousFeed.setText(since(olderFeed==null?null:olderFeed.getDate("at")));
        if(previousFeedAmount!=null)previousFeedAmount.setText(feedingAmountText(olderFeed));
        if(lastPoop!=null)lastPoop.setText(since(lp));
        if(lastPee!=null)lastPee.setText(since(lu));
    }
    private static class FeedInputs {
        EditText breast,pumped,formula;CheckBox unknown;
    }
    private EditText amountLine(LinearLayout parent,String label,int current){
        parent.addView(text(label+" (mL)",14,true),margin(-1,-2,9,0));
        LinearLayout line=row();EditText input=new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setSingleLine(true);
        input.setText(String.valueOf(current));input.setSelectAllOnFocus(true);
        Button minus=button("−5"),plus=button("+5");
        minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(0,n-5)));});
        plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        line.addView(minus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,dp(54),1);mid.setMargins(dp(8),0,dp(8),0);line.addView(input,mid);
        line.addView(plus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        parent.addView(line);return input;
    }
    private int parseAmount(EditText input){try{return Integer.parseInt(input.getText().toString().trim());}catch(Exception e){return 0;}}
    private FeedInputs feedInputs(LinearLayout parent,Map<String,Object> item,boolean isExisting){
        int breast=0,pumped=isExisting?0:FamilyStore.defaultPumpedMl(this),formula=isExisting?0:FamilyStore.defaultFormulaMl(this);boolean unknown=false;
        if(isExisting&&item!=null){Object raw=item.get("feedParts");
            if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
                breast=FamilyStore.number(p.get("breastMl"));pumped=FamilyStore.number(p.get("pumpedMl"));
                formula=FamilyStore.number(p.get("formulaMl"));unknown=Boolean.TRUE.equals(p.get("breastUnmeasured"));
            }else{
                int ml=FamilyStore.number(item.get("ml"));String type=String.valueOf(item.get("feedType"));
                if(FamilyStore.BREAST.equals(type)){if(ml<0)unknown=true;else breast=ml;}
                else if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                else if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
            }
        }
        parent.addView(text("모유는 별도 수유, 새 혼합은 유축 + 분유만 입력 · 5mL 단위",12,false));
        FeedInputs f=new FeedInputs();f.breast=amountLine(parent,"모유",breast);
        f.pumped=amountLine(parent,"유축",pumped);f.formula=amountLine(parent,"분유",formula);
        f.unknown=new CheckBox(this);f.unknown.setText("직접 모유 수유 · 양 미측정 포함");f.unknown.setChecked(unknown);parent.addView(f.unknown);
        return f;
    }
    private Map<String,Object> checkedFeed(FeedInputs f){
        String[] values={f.breast.getText().toString().trim(),f.pumped.getText().toString().trim(),f.formula.getText().toString().trim()};
        int[] amounts=new int[3];int total=0;
        for(int i=0;i<3;i++){try{amounts[i]=Integer.parseInt(values[i]);}catch(Exception ex){throw new IllegalArgumentException("각 용량에 숫자를 입력하세요.");}
            if(amounts[i]<0||amounts[i]>1000||amounts[i]%5!=0)throw new IllegalArgumentException("수유량은 0~1000mL, 5mL 단위로 입력하세요.");
            total+=amounts[i];}
        if(total>1000||(total==0&&!f.unknown.isChecked()))throw new IllegalArgumentException("수유량 합계는 1000mL 이하로, 5mL 단위로 입력하세요. 미측정만 기록할 수도 있어요.");
        Map<String,Object> data=new HashMap<>();data.put("feedType",FamilyStore.feedType(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));
        data.put("ml",total);data.put("size","");data.put("feedParts",FamilyStore.feedParts(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));return data;
    }
    private void chooseFeedTime(Map<String,Object> data){
        final int[] minutes={0};
        LinearLayout layout=col();layout.setPadding(dp(15),dp(8),dp(15),dp(5));
        layout.addView(text("언제 수유했나요? 현재 또는 이전 시간을 고르세요.",14,true));
        LinearLayout choices=row();Button now=button("현재 시간"),earlier=button("이전 시간");
        choices.addView(now,flex(50));choices.addView(earlier,flex(50));layout.addView(choices);
        TextView selection=text("",15,true);selection.setGravity(Gravity.CENTER);layout.addView(selection,margin(-1,46,7,3));
        LinearLayout adjustment=row();Button minus=button("−5분");
        TextView accumulated=text("누적 0분 전",16,true);accumulated.setGravity(Gravity.CENTER);
        accumulated.setBackground(bg(0xFFFFEFBA));accumulated.setTextColor(0xFF163046);
        adjustment.addView(minus,flex(46));adjustment.addView(accumulated,flex(46));layout.addView(adjustment);
        SimpleDateFormat fmt=new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA);
        Runnable refresh=()->{
            selection.setText("기록할 시각: "+fmt.format(new Date(System.currentTimeMillis()-minutes[0]*60000L))
                +(minutes[0]==0?" · 현재":" · "+minutes[0]+"분 전"));
            accumulated.setText("누적 "+minutes[0]+"분 전");
        };
        now.setOnClickListener(v->{minutes[0]=0;refresh.run();});
        earlier.setOnClickListener(v->{if(minutes[0]==0)minutes[0]=5;refresh.run();});
        minus.setOnClickListener(v->{minutes[0]=Math.min(1440,minutes[0]+5);refresh.run();});
        refresh.run();
        new AlertDialog.Builder(this).setTitle("🍼 마지막 단계 · 수유 시간")
            .setView(layout).setNegativeButton("취소",null)
            .setPositiveButton("이 시간으로 기록",(dialog,which)->{
                Map<?,?> p=(Map<?,?>)data.get("feedParts");
                long at=System.currentTimeMillis()-minutes[0]*60000L;
                RecordWorker.queueParts(this,FamilyStore.number(p.get("breastMl")),FamilyStore.number(p.get("pumpedMl")),
                    FamilyStore.number(p.get("formulaMl")),Boolean.TRUE.equals(p.get("breastUnmeasured")),at);
                Toast.makeText(this,"수유 시간 저장 · 가족에게 전송 대기 중",Toast.LENGTH_SHORT).show();
            }).show();
    }
    /** New feeds distinguish direct breastfeeding from pumped milk + formula mixing. */
    private void showFeedSettings(){
        LinearLayout pane=col();pane.setPadding(dp(16),dp(7),dp(16),dp(2));
        pane.addView(text("각 수유 종류의 기본 용량",16,true));
        pane.addView(text("유축·분유 각각 5mL 단위 · 이 기기에만 저장 · 기존 기록 유지",12,false));
        final EditText[] fields=new EditText[2];
        final int[] initial={FamilyStore.defaultPumpedMl(this),FamilyStore.defaultFormulaMl(this)};
        final String[] labels={"유축", "분유"};
        for(int i=0;i<2;i++){
            pane.addView(text(labels[i]+" 기본값",14,true),margin(-1,-2,10,2));
            LinearLayout controls=row();
            Button minus=button("−5"),plus=button("+5");
            EditText input=new EditText(this);input.setSingleLine(true);
            input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setGravity(Gravity.CENTER);
            input.setTextSize(21);input.setText(String.valueOf(initial[i]));fields[i]=input;
            controls.addView(minus,flex(22));controls.addView(input,flex(56));controls.addView(plus,flex(22));
            pane.addView(controls,margin(-1,-2,5,5));
            minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(5,n-5)));});
            plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        }
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("⚙ 아기로그 설정")
            .setView(pane).setNegativeButton("취소",null).setPositiveButton("저장",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{
            int[] values=new int[2];
            for(int i=0;i<2;i++){
                String raw=fields[i].getText().toString().trim();
                try{values[i]=Integer.parseInt(raw);}catch(NumberFormatException e){values[i]=-1;}
                if(values[i]<5||values[i]>1000||values[i]%5!=0){
                    fields[i].setError("5~1000mL, 5mL 단위로 입력해 주세요.");return;
                }
            }
            FamilyStore.setDefaultVolumes(this,values[0],values[1]);
            QuickNotification.reset(this);QuickNotification.show(this);
            HomeWidgetProvider.updateAll(this);
            Toast.makeText(this,"유축 "+values[0]+"mL · 분유 "+values[1]+"mL 저장됨",Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        }));
        dialog.show();
    }
    private void pickFeed(){
        new AlertDialog.Builder(this).setTitle("🍼 수유 종류")
            .setItems(new String[]{"모유수유","유축","분유","혼합 (유축 + 분유)"},
                (dialog,which)->pickFeedOfType(which)).show();
    }
    private void pickFeedOfType(int choice){
        ScrollView scroll=new ScrollView(this);LinearLayout root=col();
        root.setPadding(dp(17),dp(10),dp(17),dp(10));scroll.addView(root);
        EditText breast=null,pumped=null,formula=null;CheckBox unknown=null;
        if(choice==0){
            breast=amountLine(root,"모유",0);
            unknown=new CheckBox(this);unknown.setText("모유수유 양 미측정");unknown.setChecked(true);root.addView(unknown);
        }else if(choice==1){pumped=amountLine(root,"유축",FamilyStore.defaultPumpedMl(this));
        }else if(choice==2){formula=amountLine(root,"분유",FamilyStore.defaultFormulaMl(this));
        }else{
            root.addView(text("혼합은 유축 + 분유만 기록합니다. 각각 5mL 이상 입력해 주세요.",13,true));
            pumped=amountLine(root,"유축",FamilyStore.defaultPumpedMl(this));formula=amountLine(root,"분유",FamilyStore.defaultFormulaMl(this));
        }
        final EditText bInput=breast,pInput=pumped,fInput=formula;final CheckBox unknownBox=unknown;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🍼 수유 기록 · 5mL 단위")
            .setView(scroll).setNegativeButton("취소",null).setPositiveButton("다음: 시간 선택",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int b=bInput==null?0:parseAmount(bInput);
            int p=pInput==null?0:parseAmount(pInput);
            int f=fInput==null?0:parseAmount(fInput);
            boolean isUnknown=unknownBox!=null&&unknownBox.isChecked();
            if(isUnknown)b=0; // Unmeasured direct breastfeeding cannot have a numeric amount.
            int total=b+p+f;
            if(b<0||p<0||f<0||b%5!=0||p%5!=0||f%5!=0||total>1000){
                Toast.makeText(this,"수유량은 합계 1000mL 이하, 5mL 단위로 입력하세요.",Toast.LENGTH_LONG).show();return;
            }
            if(choice==3&&(p<5||f<5)){
                Toast.makeText(this,"혼합은 유축과 분유를 각각 5mL 이상 입력해야 합니다.",Toast.LENGTH_LONG).show();return;
            }
            if(choice!=3&&total==0&&!isUnknown){
                Toast.makeText(this,"수유량을 입력하거나 모유 양 미측정을 선택하세요.",Toast.LENGTH_LONG).show();return;
            }
            Map<String,Object> data=new HashMap<>();
            data.put("feedType",FamilyStore.feedType(b,p,f,isUnknown));data.put("ml",total);data.put("size","");
            data.put("feedParts",FamilyStore.feedParts(b,p,f,isUnknown));
            dialog.dismiss();chooseFeedTime(data);
        }));dialog.show();
    }
    private Spinner spinner(String[] items,int selected){
        Spinner result=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        result.setAdapter(adapter);result.setSelection(selected);return result;
    }
    private int indexOf(String[] values,String value,int fallback){for(int i=0;i<values.length;i++)if(values[i].equals(value))return i;return fallback;}
    private void editRecord(DocumentSnapshot snap){
        Map<String,Object> item=snap.getData();if(item==null)return;
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH};
        String[] types={FamilyStore.BREAST,FamilyStore.PUMPED,FamilyStore.FORMULA};
        String[] sizes={FamilyStore.SMALL,FamilyStore.MEDIUM,FamilyStore.LARGE};
        Calendar when=Calendar.getInstance();Date old=snap.getDate("at");if(old!=null)when.setTime(old);
        ScrollView scroll=new ScrollView(this);LinearLayout form=col();form.setPadding(dp(18),dp(8),dp(18),dp(8));scroll.addView(form);
        form.addView(text("기록 종류",14,true));Spinner kind=spinner(new String[]{"수유","소변","대변","소+대변"},indexOf(kinds,snap.getString("kind"),0));form.addView(kind);
        form.addView(text("기록 날짜·시간",14,true),margin(-1,-2,12,3));
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA);
        Button time=button(fmt.format(when.getTime()));form.addView(time,margin(-1,49,3,10));
        time.setOnClickListener(v->new DatePickerDialog(this,(view,y,m,d)->{
            when.set(y,m,d);
            new TimePickerDialog(this,(t,h,min)->{when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,min);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);time.setText(fmt.format(when.getTime()));},when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show();
        },when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show());
        LinearLayout feedBox=col();FeedInputs feed=feedInputs(feedBox,item,FamilyStore.FEED.equals(snap.getString("kind")));form.addView(feedBox);
        LinearLayout diaperBox=col();diaperBox.addView(text("기저귀 양 (소+대변은 같은 양 적용)",13,true));
        Spinner size=spinner(new String[]{"소","중","대"},indexOf(sizes,snap.getString("size"),1));diaperBox.addView(size);form.addView(diaperBox);
        kind.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id){boolean feed=position==0;feedBox.setVisibility(feed?View.VISIBLE:View.GONE);diaperBox.setVisibility(feed?View.GONE:View.VISIBLE);}
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("시간·양 수정").setView(scroll)
            .setNegativeButton("취소",null).setPositiveButton("수정 저장",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long timeMs=when.getTimeInMillis();Calendar first=Calendar.getInstance();first.set(2020,0,1,0,0,0);
            if(timeMs<first.getTimeInMillis()||timeMs>System.currentTimeMillis()+300000L){Toast.makeText(this,"시간은 2020년부터 현재까지 입력하세요.",Toast.LENGTH_LONG).show();return;}
            String k=kinds[kind.getSelectedItemPosition()];Map<String,Object> changes=new HashMap<>();
            changes.put("kind",k);changes.put("at",new Timestamp(new Date(timeMs)));changes.put("legacy",false);
            if(FamilyStore.FEED.equals(k)){
                try{changes.putAll(checkedFeed(feed));}
                catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            }else{
                changes.put("feedType","");changes.put("ml",0);changes.put("size",sizes[size.getSelectedItemPosition()]);
                changes.put("feedParts",FieldValue.delete());
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            snap.getReference().update(changes).addOnSuccessListener(ok->{Toast.makeText(this,"수정 완료 · 가족에게 반영됩니다.",Toast.LENGTH_SHORT).show();dialog.dismiss();})
                .addOnFailureListener(err->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);fail("수정 실패: "+err.getMessage());});
        }));
        dialog.show();
    }
    private void openFeedFromWidgetIfRequested(){
        Intent intent=getIntent();
        if(intent!=null&&"ready".equals(state)&&intent.getBooleanExtra("open_feed_from_widget",false)){
            intent.removeExtra("open_feed_from_widget");
            pickFeed();
        }
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        openFeedFromWidgetIfRequested();
    }
    private void toggle(){if(QuickNotification.enabled(this)){QuickNotification.enabled(this,false);draw();return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);return;}
        QuickNotification.enabled(this,true);draw();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);
        if(request==99){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)QuickNotification.enabled(this,true);
            else Toast.makeText(this,"알림 권한이 필요합니다",Toast.LENGTH_LONG).show();draw();}}
}
