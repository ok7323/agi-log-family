package com.agilog.local;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.view.View;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebResourceResponse;
import android.webkit.CookieManager;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.Source;
import com.google.firebase.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final String THEME_PREF="ui_theme_v245";
    private boolean darkMode=false;
    private int BACK=0xFFFFF9F6,INK=0xFF644B56,MUTED=0xFF9F8993,BLUSH=0xFFF6E0E8,SURFACE=Color.WHITE;
    /** Visual preference is device-local and never written to Firebase. */
    private boolean isDarkRequested(){
        String pref=FamilyStore.prefs(this).getString(THEME_PREF,"system");
        if("dark".equals(pref))return true;
        if("light".equals(pref))return false;
        return (getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
    }
    private void configureColors(){
        darkMode=isDarkRequested();
        BACK=darkMode?0xFF19171D:0xFFFFF9F6;
        INK=darkMode?0xFFF4E6EE:0xFF644B56;
        MUTED=darkMode?0xFFD2BBC9:0xFF9F8993;
        BLUSH=darkMode?0xFF493847:0xFFF6E0E8;
        SURFACE=darkMode?0xFF29262E:Color.WHITE;
    }
    private int thematicColor(int color){
        if(!darkMode)return color;
        if(color==Color.WHITE)return SURFACE;
        if(color==0xFFFFF0E7||color==0xFFFFF9F6)return 0xFF39313B;
        if(color==0xFFFFEFBA)return 0xFF675436;
        if(color==0xFFF6E0E8)return BLUSH;
        if(color==0xFFD88692)return 0xFFBA657F;
        return color;
    }
    private final ArrayList<DocumentSnapshot> events=new ArrayList<>();
    private ListenerRegistration listener;
    private static volatile boolean foregroundActive=false;
    static boolean isForeground(){return foregroundActive;}
    private String state="loading";
    private String status="가족 연결 준비 중...";
    private TextView dailyFeed, dailyPoop, dailyPee, lastFeed, lastFeedAmount, previousFeed, previousFeedAmount, lastPoop, lastPee, lastPump, previousPump, yesterdayFeed;
    private TextView pumpNowEstimate;
    private TextView todayBreast, todayPumped, todayFormula, dailyDiapers, yesterdayDiapers, todayPumpVolume, yesterdayPumpVolume;
    private boolean olderRecordsExpanded=false;
    private int olderRecordsVisible=100;
    private String pendingFamilyCsv=null;
    private int pendingFamilyCsvCount=0;
    private static final int FAMILY_CSV_REQUEST=8125;
    private boolean statisticsTab=false;
    private boolean toolsTab=false;
    private ToolCloudSync toolSync;
    private ValueCallback<Uri[]> toolFileCallback;
    private static final int TOOL_FILE_REQUEST=8124;
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent result){
        super.onActivityResult(requestCode,resultCode,result);
        if(requestCode==TOOL_FILE_REQUEST){
            ValueCallback<Uri[]> cb=toolFileCallback;toolFileCallback=null;
            if(cb!=null){Uri uri=(resultCode==RESULT_OK&&result!=null)?result.getData():null;
                cb.onReceiveValue(uri==null?null:new Uri[]{uri});}
        }
        if(requestCode==FAMILY_CSV_REQUEST){
            String csv=pendingFamilyCsv;pendingFamilyCsv=null;
            if(resultCode==RESULT_OK&&result!=null&&result.getData()!=null&&csv!=null){
                try(OutputStream out=getContentResolver().openOutputStream(result.getData())){
                    if(out==null)throw new IllegalStateException("파일을 열 수 없습니다");
                    out.write(("\uFEFF"+csv).getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"가족 전체 "+pendingFamilyCsvCount+"건 CSV 저장 완료",Toast.LENGTH_LONG).show();
                }catch(Exception ex){Toast.makeText(this,"CSV 파일 저장 실패: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }
        }
    }
    private void exportAllFamilyRecords(Button trigger){
        String code=FamilyStore.code(this);
        if(!"ready".equals(state)||code.isEmpty()){
            Toast.makeText(this,"먼저 가족에 연결해 주세요.",Toast.LENGTH_LONG).show();return;
        }
        trigger.setEnabled(false);trigger.setText("Firebase에서 전체 기록 조회 중…");
        FamilyStore.db().collection("families").document(code).collection("events")
            .orderBy("at",Query.Direction.DESCENDING).get(Source.SERVER)
            .addOnSuccessListener(snapshot->{
                trigger.setEnabled(true);trigger.setText("📥 가족 전체 기록 CSV 저장");
                if(!code.equals(FamilyStore.code(this)))return; // Family changed while loading.
                try{
                    ArrayList<FamilyCsv.Entry> rows=new ArrayList<>();
                    for(DocumentSnapshot d:snapshot.getDocuments())rows.add(new FamilyCsv.Entry(d.getId(),d.getData(),d.getDate("at")));
                    pendingFamilyCsv=FamilyCsv.serialize(rows);
                    pendingFamilyCsvCount=rows.size();
                    String name="AgilogFamily_AllRecords_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.US).format(new Date())+".csv";
                    Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType("text/csv");save.putExtra(Intent.EXTRA_TITLE,name);
                    startActivityForResult(save,FAMILY_CSV_REQUEST);
                }catch(Exception ex){pendingFamilyCsv=null;Toast.makeText(this,"CSV 준비 실패: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }).addOnFailureListener(e->{
                trigger.setEnabled(true);trigger.setText("📥 가족 전체 기록 CSV 저장");
                Toast.makeText(this,"CSV 조회 실패 · 인터넷/가족 권한 확인: "+e.getMessage(),Toast.LENGTH_LONG).show();
            });
    }
    private void saveToolDownload(String name,String body,String mime){
        try{
            if(Build.VERSION.SDK_INT>=29){
                ContentValues values=new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME,name.replaceAll("[^A-Za-z0-9._-]","_"));
                values.put(MediaStore.MediaColumns.MIME_TYPE,mime.startsWith("text/csv")?"text/csv":"application/json");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/");
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                if(uri==null)throw new Exception("다운로드 폴더에 저장 실패");
                try(OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new Exception("저장 공간에 접근할 수 없습니다");
                    out.write(body.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this,"다운로드 폴더에 저장됨: "+name,Toast.LENGTH_LONG).show();
            }else{
                Intent share=new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,body);
                startActivity(Intent.createChooser(share,"백업 내용 공유"));
            }
        }catch(Exception e){Toast.makeText(this,"백업 저장 실패: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private int statisticsPeriod=7;
    private TextView yesterdayBreast, yesterdayPumped, yesterdayFormula, yesterdayPoop, yesterdayPee;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable elapsedTick=new Runnable(){@Override public void run(){if("ready".equals(state))updateSummary();timer.postDelayed(this,60000L);}};
    @Override public void onCreate(Bundle b){
        // Apply native Material dark/light theme BEFORE Android inflates dialogs and inputs.
        configureColors();
        setTheme(darkMode?R.style.AgilogDark:R.style.AgilogLight);
        super.onCreate(b);
        getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);
        int systemUi=darkMode?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setSystemUiVisibility(systemUi);
        // v2.25 switches to battery-friendly 30-minute sync by default.
        // Previous fast-sync opt-in is cleared once; users can explicitly turn it back on.
        if(!FamilyStore.prefs(this).getBoolean("sync_mode_v225_initialized",false)){
            FastFamilySyncService.setEnabled(this,false);
            FamilyStore.prefs(this).edit().putBoolean("sync_mode_v225_initialized",true).apply();
        }
        draw();
        if(FirebaseAuth.getInstance().getCurrentUser()!=null)afterAuth();
        else FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(a->afterAuth()).addOnFailureListener(e->fail("로그인 실패: "+e.getMessage()));
    }
    @Override protected void onResume(){
        super.onResume();
        foregroundActive=true;
        timer.removeCallbacks(elapsedTick);
        timer.post(elapsedTick); // Foreground-only minute update; never runs when paused.
        startForegroundListener();
        if("ready".equals(state))startFastFamilySyncIfWanted();
        if(QuickNotification.enabled(this))QuickNotification.show(this);
        openFeedFromWidgetIfRequested();
    }
    @Override protected void onPause(){
        foregroundActive=false;
        timer.removeCallbacks(elapsedTick);
        stopForegroundListener(); // No Firestore live stream while screen/app is inactive.
        super.onPause();
    }
    @Override protected void onDestroy(){
        timer.removeCallbacks(elapsedTick);
        stopForegroundListener();
        if(toolSync!=null){toolSync.close();toolSync=null;}
        super.onDestroy();
    }
    private void stopForegroundListener(){
        if(listener!=null){listener.remove();listener=null;}
    }
    private void startForegroundListener(){
        if(!foregroundActive||listener!=null||!"ready".equals(state)||FamilyStore.code(this).isEmpty())return;
        listener=FamilyStore.db().collection("families").document(FamilyStore.code(this)).collection("events")
            .orderBy("at", Query.Direction.DESCENDING)
            .addSnapshotListener((snap,error)->{
                if(!foregroundActive)return;
                if(error!=null){status="기록 불러오기 오류: "+error.getMessage();draw();return;}
                events.clear();
                if(snap!=null){events.addAll(snap.getDocuments());QuickStats.update(this,snap.getDocuments());}
                if(!toolsTab)draw();
                QuickNotification.show(this);
                HomeWidgetProvider.updateAll(this);
            });
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(thematicColor(color));d.setCornerRadius(dp(16));return d;}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(3),dp(top),dp(3),dp(bottom));return p;}
    private LinearLayout.LayoutParams flex(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1f);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private TextView text(String val,int size,boolean bold){TextView t=new TextView(this);t.setText(val);t.setTextSize(size);t.setTextColor(INK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String title){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextSize(14);b.setTextColor(INK);b.setBackground(bg(BLUSH));return b;}
    private LinearLayout card(){LinearLayout l=col();l.setPadding(dp(17),dp(18),dp(17),dp(18));l.setBackground(bg(SURFACE));return l;}
    private void fail(String message){status=message;Toast.makeText(this,message,Toast.LENGTH_LONG).show();draw();}
    private void afterAuth(){String code=FamilyStore.code(this);
        if(!code.isEmpty()){
            FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid())
                .get().addOnSuccessListener(d->{if(d.exists())connected();else{state="connect";draw();}})
                .addOnFailureListener(e->{state="connect";fail("가족 확인 실패: "+e.getMessage());});
        }else{state="connect";draw();}
    }
    private void connect(boolean create,String name,String code){
        name=name.trim();code=code.trim().toUpperCase().replaceAll("[\\s-]","");
        if(name.isEmpty()||name.length()>40){fail("이름은 1~40자로 입력해 주세요.");return;}
        if(create)code=FamilyStore.randomCode();
        if(!FamilyStore.validCode(code)){fail("가족 코드를 20자리로 입력해 주세요.");return;}
        final String family=code,who=name;
        status="가족 연결 중...";draw();
        if(create){Map<String,Object> familyData=new HashMap<>();familyData.put("createdBy",FamilyStore.uid());familyData.put("createdAt",FieldValue.serverTimestamp());
            FamilyStore.db().collection("families").document(family).set(familyData)
                .addOnSuccessListener(v->addMember(family,who))
                .addOnFailureListener(e->{state="connect";fail("가족 만들기 실패: "+e.getMessage());});
        }else addMember(family,who);
    }
    private void addMember(String code,String who){
        Map<String,Object> member=new HashMap<>();member.put("name",who);member.put("joinedAt",FieldValue.serverTimestamp());
        var ref=FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid());
        ref.set(member).addOnSuccessListener(v->{FamilyStore.setFamily(this,code,who);connected();})
           .addOnFailureListener(e->ref.get().addOnSuccessListener(existing->{
               if(existing.exists()){FamilyStore.setFamily(this,code,who);connected();}
               else{state="connect";fail("가족 코드를 확인해 주세요: "+e.getMessage());}
           }).addOnFailureListener(e2->{state="connect";fail("가입 실패: "+e.getMessage());}));
    }
    private void connected(){state="ready";status="";draw();
        if(QuickNotification.enabled(this)||HomeWidgetProvider.hasWidgets(this)){
            QuickStatsWorker.schedule(this);
            if(!foregroundActive)QuickStatsWorker.request(this); // The foreground listener already gets fresh data.
        }
        QuickNotification.show(this);
        HomeWidgetProvider.updateAll(this);
        openFeedFromWidgetIfRequested();
        stopForegroundListener();
        startForegroundListener();
        startFastFamilySyncIfWanted();
    }
    private void startFastFamilySyncIfWanted(){
        try{FastFamilySyncService.startIfEnabled(this);}
        catch(RuntimeException ex){
            Toast.makeText(this,"빠른 동기화를 시작할 수 없습니다. 절약 모드로 동작합니다.",Toast.LENGTH_LONG).show();
        }
    }
    private void toggleFastFamilySync(){
        if(FastFamilySyncService.enabled(this)){
            FastFamilySyncService.setEnabled(this,false);
            draw();
        }else{
            new AlertDialog.Builder(this).setTitle("가족 위젯 빠른 동기화")
                .setMessage("다른 가족의 기록을 빠르게 받아 위젯을 갱신합니다(3분 이내 목표). 사용 중에는 지속 알림이 뜨고 배터리가 더 소모될 수 있습니다. 잠금/절전 중에는 3분을 보장할 수 없으며 Android 15 이상에서는 사용 시간이 제한됩니다.")
                .setNegativeButton("취소",null)
                .setPositiveButton("빠른 동기화 켜기",(d,w)->{
                    try{FastFamilySyncService.setEnabled(this,true);draw();}
                    catch(RuntimeException ex){
                        FastFamilySyncService.setEnabled(this,false);
                        Toast.makeText(this,"빠른 동기화를 시작할 수 없습니다.",Toast.LENGTH_LONG).show();
                        draw();
                    }
                }).show();
        }
    }
    private void draw(){
        if(toolSync!=null){toolSync.close();toolSync=null;}
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BACK);
        LinearLayout root=col();root.setPadding(dp(15),dp(27),dp(15),dp(50));scroll.addView(root);setContentView(scroll);
        root.addView(text("우리 아이 하루를 함께",12,false));
        LinearLayout header=row();
        header.addView(text("아기로그 가족 🍼",26,true),flex(90));
        Button settingsButton=button("⚙ 설정");settingsButton.setTextSize(11);settingsButton.setPadding(dp(7),dp(5),dp(7),dp(5));
        settingsButton.setOnClickListener(v->showFeedSettings());header.addView(settingsButton,margin(79,34,0,0));
        root.addView(header,margin(-1,-2,3,8));
        if(status!=null&&!status.isEmpty()){TextView message=text(status,12,false);message.setTextColor(MUTED);root.addView(message,margin(-1,-2,0,18));}
        if("loading".equals(state))return;
        if("connect".equals(state)){
            LinearLayout c=card();c.addView(text("가족 코드로 연결하기",20,true),margin(-1,-2,0,10));
            EditText name=new EditText(this);name.setSingleLine(true);name.setHint("이름: 엄마, 아빠 등");name.setText(FamilyStore.name(this));c.addView(name);
            Button create=button("새 가족 만들기");create.setOnClickListener(v->connect(true,name.getText().toString(),""));c.addView(create,margin(-1,50,8,15));
            EditText code=new EditText(this);code.setSingleLine(true);code.setHint("가족 초대 코드 20자리");c.addView(code);
            Button join=button("가족 코드로 참여하기");join.setOnClickListener(v->connect(false,name.getText().toString(),code.getText().toString()));c.addView(join,margin(-1,50,8,0));
            root.addView(c);return;
        }
        // Native screen tabs. Keep the selected screen during Firestore snapshot refreshes.
        LinearLayout tabs=row();
        Button recordsTab=button("🍼 기록"),statsTab=button("📊 통계"),toolButton=button("🧸 육아 도구");
        recordsTab.setTextSize(12);statsTab.setTextSize(12);toolButton.setTextSize(12);
        recordsTab.setTextColor((statisticsTab||toolsTab)?INK:Color.WHITE);
        statsTab.setTextColor(statisticsTab?Color.WHITE:INK);
        toolButton.setTextColor(toolsTab?Color.WHITE:INK);
        if(!statisticsTab&&!toolsTab)recordsTab.setBackground(bg(0xFFD88692));
        if(statisticsTab)statsTab.setBackground(bg(0xFFD88692));
        if(toolsTab)toolButton.setBackground(bg(0xFFD88692));
        recordsTab.setOnClickListener(v->{statisticsTab=false;toolsTab=false;draw();});
        statsTab.setOnClickListener(v->{statisticsTab=true;toolsTab=false;draw();});
        toolButton.setOnClickListener(v->{statisticsTab=false;toolsTab=true;draw();});
        tabs.addView(recordsTab,flex(47));tabs.addView(statsTab,flex(47));tabs.addView(toolButton,flex(47));
        root.addView(tabs,margin(-1,-2,0,12));
        if(toolsTab){
            root.removeView(tabs);
            LinearLayout page=col();page.setBackgroundColor(BACK);
            page.setPadding(dp(11),dp(20),dp(11),dp(5));
            LinearLayout toolsHeader=row();toolsHeader.addView(text("아기로그 가족 🍼",23,true),flex(90));
            Button toolsSettings=button("⚙ 설정");toolsSettings.setTextSize(11);
            toolsSettings.setOnClickListener(v->showFeedSettings());toolsHeader.addView(toolsSettings,margin(79,34,0,0));
            page.addView(toolsHeader,margin(-1,-2,0,6));
            page.addView(tabs,margin(-1,-2,0,5));
            WebView toolWeb=new WebView(this);toolWeb.setBackgroundColor(BACK);
            // This WebView holds a native Firebase bridge. Never allow it to load
            // untrusted pages, local files, or third-party resources.
            WebSettings toolSettings=toolWeb.getSettings();
            toolSettings.setJavaScriptEnabled(true); // required for bundled tools UI
            toolSettings.setDomStorageEnabled(true);
            toolSettings.setAllowFileAccess(false);
            toolSettings.setAllowContentAccess(false);
            toolSettings.setAllowFileAccessFromFileURLs(false);
            toolSettings.setAllowUniversalAccessFromFileURLs(false);
            toolSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            toolSettings.setSupportMultipleWindows(false);
            toolSettings.setSaveFormData(false);
            if(Build.VERSION.SDK_INT>=26)toolSettings.setSafeBrowsingEnabled(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(toolWeb,false);
            toolWeb.setWebViewClient(new WebViewClient(){
                @Override public WebResourceResponse shouldInterceptRequest(WebView view,android.webkit.WebResourceRequest req){
                    // All HTML/CSS/JS is embedded locally; no remote requests are needed.
                    // In particular a malicious subframe must never gain the JS bridge.
                    Uri uri=req.getUrl();
                    if("about".equalsIgnoreCase(uri.getScheme()))return null;
                    // Allow only fixed, bundled pixel-game assets (never arbitrary files or URLs).
                    // This also makes the Android WebView wardrobe and action sprites work offline.
                    String path=uri.getPath();
                    boolean bundledGameAsset=path!=null&&(
                        path.matches("/game-frames/nooni-[0-8]\\.webp")
                        ||path.matches("/nooni-hd/(?:sprite-[0-7]|room-(?:day|night))\\.webp")
                        ||path.matches("/nooni-looks/look-(?:[0-9]|1[0-9]|2[0-3])-[0-7]\\.webp")
                        ||path.matches("/nooni-reactions/(?:feed|soothe|diaper|play|sleep|practice)-[0-4]\\.webp")
                        ||path.matches("/nooni-wardrobe/(?:outfit|ribbon|toy)/(?:[0-9]|1[0-5])-[0-7]\\.webp")
                        ||path.matches("/nooni-wardrobe/thumb/(?:outfit|ribbon|toy)-(?:[0-9]|1[0-5])\\.webp")
                        ||path.matches("/nooni-wardrobe/care/(?:feed|soothe|diaper|play|sleep|practice)-[0-4]\\.webp")
                        ||path.matches("/nooni-wardrobe/background/[0-7]\\.webp"));
                    if("https".equalsIgnoreCase(uri.getScheme())
                        &&"appassets.androidplatform.net".equals(uri.getHost())
                        &&bundledGameAsset){
                        try{
                            InputStream image=getAssets().open(path.substring(1));
                            return new WebResourceResponse("image/webp",null,image);
                        }catch(Exception ignored){/* invalid/missing asset: block below */}
                    }
                    return new WebResourceResponse("text/plain","UTF-8",
                        new ByteArrayInputStream(new byte[0]));
                }
                @Override public void onPageFinished(WebView view,String url){
                    // Keep the native tool WebView in the same theme, even if
                    // the phone's system mode differs from the app preference.
                    view.evaluateJavascript("window.agilogApplyTheme && window.agilogApplyTheme('"+(darkMode?"dark":"light")+"')",null);
                    if(toolSync!=null)toolSync.close();
                    toolSync=new ToolCloudSync(MainActivity.this,toolWeb,FamilyStore.code(MainActivity.this));
                    toolSync.start();
                }
                @Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){
                    return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
                }
            });
            toolWeb.addJavascriptInterface(new Object(){
                @JavascriptInterface public void download(String name,String contents,String mime){
                    // Bound native bridge arguments to prevent memory/storage exhaustion.
                    if(name==null||name.length()>100||contents==null||contents.length()>2_000_000
                        ||mime==null||!(mime.startsWith("application/json")||mime.startsWith("text/csv")))return;
                    runOnUiThread(()->saveToolDownload(name,contents,mime));
                }
                @JavascriptInterface public void toolChange(String json){
                    if(json==null||json.length()>32_768)return;
                    runOnUiThread(()->{if(toolSync!=null)toolSync.write(json);});
                }
            },"AgilogNative");
            toolWeb.setWebChromeClient(new WebChromeClient(){
                @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                    if(toolFileCallback!=null)toolFileCallback.onReceiveValue(null);
                    toolFileCallback=callback;
                    try{Intent open=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        open.setType("application/json");open.addCategory(Intent.CATEGORY_OPENABLE);
                        startActivityForResult(open,TOOL_FILE_REQUEST);return true;
                    }catch(Exception ex){toolFileCallback=null;callback.onReceiveValue(null);return false;}
                }
            });
            page.addView(toolWeb,new LinearLayout.LayoutParams(-1,0,1));
            setContentView(page);
            try(InputStream input=getAssets().open("parenting-tools.html")){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                byte[] buffer=new byte[8192];int count;
                while((count=input.read(buffer))!=-1)bytes.write(buffer,0,count);
                toolWeb.loadDataWithBaseURL("https://appassets.androidplatform.net/",
                    new String(bytes.toByteArray(),StandardCharsets.UTF_8),"text/html","UTF-8",null);
            }catch(Exception exc){toolWeb.loadData("<p>육아 도구 화면을 열 수 없습니다.</p>","text/html","UTF-8");}
            return;
        }
        if(statisticsTab){drawStatistics(root);return;}
        // Ordering: latest elapsed times -> quick record -> today -> yesterday -> history -> invitation.
        LinearLayout elapsed=card();elapsed.setPadding(dp(16),dp(12),dp(16),dp(11));elapsed.addView(text("마지막 기록으로부터 · v2.65",18,true));
        LinearLayout feedingTimes=row();
        TextView[] current=feedSummaryTile(feedingTimes,"🍼 마지막 수유");
        lastFeed=current[0];lastFeedAmount=current[1];
        TextView[] previous=feedSummaryTile(feedingTimes,"🍼 이전 수유");
        previousFeed=previous[0];previousFeedAmount=previous[1];
        elapsed.addView(feedingTimes);
        LinearLayout diaperTimes=row();
        lastPoop=summaryTile(diaperTimes,"💩 대변","기록 없음",true);
        lastPee=summaryTile(diaperTimes,"💧 소변","기록 없음",true);
        elapsed.addView(diaperTimes);
        LinearLayout pumpTimes=row();
        lastPump=summaryTile(pumpTimes,"🥛 마지막 유축·모유","기록 없음",true);
        previousPump=summaryTile(pumpTimes,"🥛 이전 유축·모유","기록 없음",true);
        elapsed.addView(pumpTimes,margin(-1,-2,8,1));
        pumpNowEstimate=text("🥛 지금 유축 예상량 · 기록 없음",16,true);
        pumpNowEstimate.setTextColor(darkMode?0xFFFFC4DF:0xFFAD507A);
        elapsed.addView(pumpNowEstimate,margin(-1,-2,8,2));
        elapsed.addView(text("참고용 · 1시간 25mL → 10시간 200mL · 최대 200mL",11,false),margin(-1,-2,1,1));
        root.addView(elapsed,margin(-1,-2,0,12));
        root.addView(text("빠른 기록 +",20,true),margin(-1,-2,0,6));
        LinearLayout actions=row();
        Button feedsButton=button("🍼\n수유");feedsButton.setOnClickListener(v->pickFeed());
        Button diaperButton=button("🧷\n기저귀");diaperButton.setOnClickListener(v->pickDiaperType());
        Button pumpButton=button("🥛\n유축 시작");pumpButton.setOnClickListener(v->pickPumpStart());
        actions.addView(feedsButton,flex(72));actions.addView(diaperButton,flex(72));actions.addView(pumpButton,flex(72));
        root.addView(actions,margin(-1,-2,0,4));
        LinearLayout today=card();today.setPadding(dp(15),dp(12),dp(15),dp(12));today.addView(text("오늘 누적 기록",18,true));
        LinearLayout todayMilks=row();
        todayBreast=summaryTile(todayMilks,"🍼 모유","0회");
        todayPumped=summaryTile(todayMilks,"🍼 유축수유","0mL");
        todayFormula=summaryTile(todayMilks,"🍼 분유","0mL");
        today.addView(todayMilks);
        LinearLayout todayDiapers=row();
        dailyPoop=summaryTile(todayDiapers,"💩 대변","0회");
        dailyPee=summaryTile(todayDiapers,"💧 소변","0회");
        dailyDiapers=summaryTile(todayDiapers,"🧷 기저귀","0개");
        today.addView(todayDiapers);
        dailyFeed=text("수유 총 0회 · 측정량 0mL",13,true);
        today.addView(dailyFeed,margin(-1,-2,5,0));
        todayPumpVolume=text("🥛 유축 시작 0회 · 직접 유축량 0mL",12,true);
        today.addView(todayPumpVolume,margin(-1,-2,5,0));
        root.addView(today,margin(-1,-2,6,15));

        LinearLayout yesterdayCard=card();yesterdayCard.setPadding(dp(15),dp(12),dp(15),dp(12));yesterdayCard.addView(text("어제 누적 기록",18,true));
        LinearLayout yesterdayMilks=row();
        yesterdayBreast=summaryTile(yesterdayMilks,"🍼 모유","0회");
        yesterdayPumped=summaryTile(yesterdayMilks,"🍼 유축수유","0mL");
        yesterdayFormula=summaryTile(yesterdayMilks,"🍼 분유","0mL");
        yesterdayCard.addView(yesterdayMilks);
        LinearLayout yesterdayDiaperRow=row();
        yesterdayPoop=summaryTile(yesterdayDiaperRow,"💩 대변","0회");
        yesterdayPee=summaryTile(yesterdayDiaperRow,"💧 소변","0회");
        yesterdayDiapers=summaryTile(yesterdayDiaperRow,"🧷 기저귀","0개");
        yesterdayCard.addView(yesterdayDiaperRow);
        yesterdayFeed=text("수유 총 0회 · 측정량 0mL",13,true);
        yesterdayCard.addView(yesterdayFeed,margin(-1,-2,5,0));
        yesterdayPumpVolume=text("🥛 유축 시작 0회 · 직접 유축량 0mL",12,true);
        yesterdayCard.addView(yesterdayPumpVolume,margin(-1,-2,5,0));
        root.addView(yesterdayCard,margin(-1,-2,0,16));
        updateSummary();
        LinearLayout lock=card();lock.addView(text("🔒 잠금 화면 기록 (알림 1개)",17,true));
        lock.addView(text("잠금 화면에서는 수유·기저귀·유축 시작 메뉴로 바로 기록할 수 있습니다. 유축량은 기록 탭에서 나중에 수정할 수 있습니다. 잠금 화면 내용은 다른 사람에게 보일 수 있어요.",12,false),margin(-1,-2,7,12));
        Button enabled=button(QuickNotification.enabled(this)?"빠른 기록 끄기":"잠금 화면 빠른 기록 켜기");enabled.setOnClickListener(v->toggle());
        lock.addView(enabled,margin(-1,48,0,0));root.addView(lock,margin(-1,-2,0,12));
        LinearLayout fast=card();fast.setPadding(dp(17),dp(13),dp(17),dp(13));
        fast.addView(text("⚡ 가족 위젯 빠른 동기화 · 3분 목표",17,true));
        fast.addView(text("켜면 가족 기록 변경을 실시간으로 받아 잠금화면·홈 위젯을 바로 갱신합니다. 지속 알림 및 추가 배터리 사용이 있으며, 절전/연결 끊김이나 Android 15의 사용 시간 제한 중에는 3분 보장이 불가능합니다.",12,false),margin(-1,-2,5,6));
        Button faster=button(FastFamilySyncService.enabled(this)?"빠른 동기화 끄기":"빠른 동기화 켜기");
        faster.setOnClickListener(v->toggleFastFamilySync());
        fast.addView(faster,margin(-1,46,0,0));
        root.addView(fast,margin(-1,-2,0,18));
        root.addView(text("가족 최근 기록 · 최근 12시간",19,true),margin(-1,-2,0,9));
        TextView filterTitle=text("표시할 기록 (복수 선택)",12,true);
        filterTitle.setTextColor(MUTED);root.addView(filterTitle,margin(-1,-2,3,3));
        LinearLayout filterRow=row();
        CheckBox filterFeed=new CheckBox(this);filterFeed.setText("🍼 수유");
        CheckBox filterPump=new CheckBox(this);filterPump.setText("🥛 유축");
        CheckBox filterDiaper=new CheckBox(this);filterDiaper.setText("🧷 기저귀");
        for(CheckBox c:new CheckBox[]{filterFeed,filterPump,filterDiaper}){
            c.setTextSize(12);c.setPadding(0,dp(5),0,dp(5));
            filterRow.addView(c,new LinearLayout.LayoutParams(0,dp(47),1f));
        }
        filterFeed.setChecked(FamilyStore.prefs(this).getBoolean("record_filter_feed",true));
        filterPump.setChecked(FamilyStore.prefs(this).getBoolean("record_filter_pump",true));
        filterDiaper.setChecked(FamilyStore.prefs(this).getBoolean("record_filter_diaper",true));
        root.addView(filterRow,margin(-1,-2,2,5));
        TextView filterTip=text("수유 = 모유·분유·유축수유 · 유축 = 직접 유축 시작",11,false);
        filterTip.setTextColor(MUTED);root.addView(filterTip,margin(-1,-2,1,8));
        LinearLayout familyHistory=col();root.addView(familyHistory,margin(-1,-2,0,8));
        // One backtest per screen render; no writes to Firestore or local preferences.
        final Map<Long,Integer> historicalPumpMl=historicalPumpEstimateMap();
        SimpleDateFormat fmt=new SimpleDateFormat("MM월 dd일 HH:mm",Locale.KOREAN);
        final Runnable[] renderHistory=new Runnable[1];
        renderHistory[0]=()->{
            familyHistory.removeAllViews();
            long now=System.currentTimeMillis(),cutoff=now-12L*60L*60L*1000L;
            boolean showFeed=filterFeed.isChecked(),showPump=filterPump.isChecked(),showDiaper=filterDiaper.isChecked();
            ArrayList<DocumentSnapshot> recent=new ArrayList<>(),past=new ArrayList<>();
            for(DocumentSnapshot snap:events){
                if(!matchesRecordFilter(snap.getString("kind"),showFeed,showPump,showDiaper))continue;
                Date when=snap.getDate("at");
                if(when!=null&&when.getTime()>=cutoff&&when.getTime()<=now+300000L)recent.add(snap);
                else past.add(snap);
            }
            TextView count=text("최근 12시간 "+recent.size()+"건 · 이전 기록 "+past.size()+"건",12,false);
            count.setTextColor(MUTED);familyHistory.addView(count,margin(-1,-2,0,7));
            if(recent.isEmpty())familyHistory.addView(text(!showFeed&&!showPump&&!showDiaper?
                "선택한 기록 종류가 없어요. 위에서 체크해 주세요.":
                "선택한 종류의 최근 12시간 기록이 없어요 🌱",15,false));
            for(DocumentSnapshot snap:recent)appendFamilyRecord(familyHistory,snap,fmt,historicalPumpMl);
            if(!past.isEmpty()){
                Button toggle=button(olderRecordsExpanded?"이전 기록 접기 ("+past.size()+"건)":"이전 기록 펼치기 ("+past.size()+"건)");
                toggle.setTextSize(13);familyHistory.addView(toggle,margin(-1,43,5,5));
                LinearLayout pastBox=col();pastBox.setVisibility(olderRecordsExpanded?View.VISIBLE:View.GONE);
                familyHistory.addView(pastBox,margin(-1,-2,0,4));
                Button more=button("");more.setTextSize(12);familyHistory.addView(more,margin(-1,42,0,9));
                int shown=olderRecordsExpanded?Math.min(olderRecordsVisible,past.size()):0;
                for(int i=0;i<shown;i++)appendFamilyRecord(pastBox,past.get(i),fmt,historicalPumpMl);
                int remain=past.size()-shown;
                more.setVisibility(olderRecordsExpanded&&remain>0?View.VISIBLE:View.GONE);
                if(remain>0)more.setText("이전 기록 "+Math.min(100,remain)+"건 더 보기 ("+remain+"건 남음)");
                toggle.setOnClickListener(v->{olderRecordsExpanded=!olderRecordsExpanded;olderRecordsVisible=100;renderHistory[0].run();});
                more.setOnClickListener(v->{olderRecordsVisible+=100;renderHistory[0].run();});
            }
        };
        filterFeed.setOnCheckedChangeListener((button,checked)->{
            FamilyStore.prefs(this).edit().putBoolean("record_filter_feed",checked).apply();
            olderRecordsVisible=100;renderHistory[0].run();
        });
        filterPump.setOnCheckedChangeListener((button,checked)->{
            FamilyStore.prefs(this).edit().putBoolean("record_filter_pump",checked).apply();
            olderRecordsVisible=100;renderHistory[0].run();
        });
        filterDiaper.setOnCheckedChangeListener((button,checked)->{
            FamilyStore.prefs(this).edit().putBoolean("record_filter_diaper",checked).apply();
            olderRecordsVisible=100;renderHistory[0].run();
        });
        renderHistory[0].run();
        TextView note=text("기존 아기로그 앱은 삭제하지 마세요. 새 가족 앱의 기록부터 공유됩니다.",11,false);note.setTextColor(MUTED);root.addView(note,margin(-1,-2,18,0));
        LinearLayout info=card();info.addView(text("👨‍👩‍👧 가족 초대 코드",17,true));
        TextView code=text(FamilyStore.code(this),17,true);code.setTextIsSelectable(true);info.addView(code,margin(-1,-2,8,4));
        Button share=button("초대 코드 공유");share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"아기로그 가족 코드: "+FamilyStore.code(this));startActivity(Intent.createChooser(i,"가족에게 보내기"));});
        info.addView(share,margin(-1,44,5,0));root.addView(info,margin(-1,-2,16,0));
        // Deliberately placed at the very bottom of the Records tab.
        LinearLayout exportCard=card();exportCard.addView(text("📥 가족 전체 기록 CSV 다운로드",17,true));
        exportCard.addView(text("접혀 있는 예전 기록까지 모두 포함합니다. Firebase에서 전체 수유·기저귀 기록을 조회해 CSV로 저장합니다. 육아 도구 기록은 육아 도구에서 별도 내보내세요.",12,false),margin(-1,-2,7,10));
        Button export=button("📥 가족 전체 기록 CSV 저장");
        export.setOnClickListener(v->exportAllFamilyRecords(export));
        exportCard.addView(export,margin(-1,48,0,8));
        TextView privacy=text("파일에 가족 기록이 포함되니 저장·공유에 주의해 주세요.",11,false);
        privacy.setTextColor(MUTED);exportCard.addView(privacy);
        root.addView(exportCard,margin(-1,-2,10,0));
    }
    // Filters affect only the on-screen family history; no writes or CSV changes.
    private static boolean matchesRecordFilter(String kind,boolean feed,boolean pump,boolean diaper){
        if(FamilyStore.FEED.equals(kind))return feed;
        if(FamilyStore.PUMP.equals(kind))return pump;
        if(FamilyStore.POOP.equals(kind)||FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind)||"diaper".equals(kind))return diaper;
        return false;
    }
    /** Reconstruct historic pumping predictions from all family records.
     * A bottle-feed of previously expressed milk is NOT a removal trigger.
     */
    private Map<Long,Integer> historicalPumpEstimateMap(){
        ArrayList<PumpForecast.Event> history=new ArrayList<>();
        for(DocumentSnapshot snap:events){
            Date at=snap.getDate("at");
            if(at==null)continue;
            String kind=snap.getString("kind");
            boolean pumping=FamilyStore.PUMP.equals(kind);
            boolean nursing=FamilyStore.FEED.equals(kind)&&snap.getData()!=null&&hasBreast(snap.getData());
            if(pumping||nursing)history.add(new PumpForecast.Event(at.getTime(),pumping,
                pumping?FamilyStore.number(snap.get("ml")):0));
        }
        return PumpForecast.historicalEstimates(history,System.currentTimeMillis());
    }
    private void appendFamilyRecord(LinearLayout root,DocumentSnapshot snap,SimpleDateFormat fmt,Map<Long,Integer> historicalPumpMl){
        Map<String,Object> map=snap.getData();if(map==null)return;
        String kind=snap.getString("kind");Date when=snap.getDate("at");
        LinearLayout line=card();line.addView(text(FamilyStore.icon(kind)+" "+FamilyStore.kindLabel(kind)+" · "+fmt.format(when==null?new Date():when),15,true));
        Integer predicted=FamilyStore.PUMP.equals(kind)&&when!=null?historicalPumpMl.get(when.getTime()):null;
        String detail=FamilyStore.detail(map)+(predicted==null?"":" · 당시 예상 "+predicted+"mL");
        TextView second=text(detail+" · "+snap.getString("who"),12,false);second.setTextColor(MUTED);line.addView(second,margin(-1,-2,5,0));
        line.setOnClickListener(v->editRecord(snap));
        TextView tap=text("눌러서 시간·양 수정",11,false);tap.setTextColor(darkMode?0xFFE7B5C5:0xFFBD8498);line.addView(tap,margin(-1,-2,4,0));
        if(FamilyStore.uid().equals(snap.getString("createdBy")))line.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("가족 기록에서 삭제할까요?")
            .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->snap.getReference().delete().addOnFailureListener(e->fail(e.getMessage()))).show();return true;});
        root.addView(line,margin(-1,-2,0,8));
    }
    /** One explanation button at the top-right of each statistics graph card. */
    private void statGraphHeader(LinearLayout card,String heading,String explanation){
        LinearLayout header=row();
        TextView title=text(heading,18,true);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1f));
        Button help=button("!");
        help.setContentDescription(heading+" 그래프 설명 보기");
        help.setTextSize(14);
        help.setMinWidth(dp(30));help.setMinimumWidth(dp(30));
        help.setMinHeight(dp(30));help.setMinimumHeight(dp(30));
        help.setPadding(0,0,0,0);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(dp(30),dp(30));
        params.setMargins(dp(6),0,0,0);
        header.addView(help,params);
        help.setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle(heading+" · 설명")
            .setMessage(explanation)
            .setPositiveButton("닫기",null)
            .show());
        card.addView(header,margin(-1,-2,0,wideStatsScreen()?4:10));
    }
    /** Always visible color key under a graph title. The ! button is for calculations only. */
    private void statGraphLegend(LinearLayout card,String[] labels,int[] colors){
        if(labels.length!=colors.length)throw new IllegalArgumentException("legend mismatch");
        LinearLayout list=col();
        for(int i=0;i<labels.length;i+=2){
            LinearLayout line=row();
            for(int j=i;j<Math.min(i+2,labels.length);j++){
                LinearLayout item=row();item.setGravity(Gravity.CENTER_VERTICAL);
                TextView square=text("■",14,true);square.setTextColor(colors[j]);
                item.addView(square,new LinearLayout.LayoutParams(-2,-2));
                TextView name=text(" "+labels[j],11,true);name.setTextColor(INK);
                item.addView(name,new LinearLayout.LayoutParams(0,-2,1f));
                line.addView(item,new LinearLayout.LayoutParams(0,-2,1f));
            }
            if(i+1>=labels.length)line.addView(new View(this),new LinearLayout.LayoutParams(0,dp(1),1f));
            list.addView(line,margin(-1,-2,0,3));
        }
        card.addView(list,margin(-1,-2,0,wideStatsScreen()?4:8));
    }
    private void statGraphLegend(LinearLayout card,String metric){
        String[] labels;
        switch(metric){
            case "milk":labels=new String[]{"분유","유축수유","모유 실측","모유 추정"};break;
            case "pumped":labels=new String[]{"유축수유 실측","모유 추정"};break;
            case "formula":labels=new String[]{"분유"};break;
            case "pumpOutput":labels=new String[]{"직접 유축 실측","모유 추정"};break;
            case "breast":labels=new String[]{"직접 모유수유"};break;
            case "diaperBreakdown":labels=new String[]{"소변만","대변만","소+대변"};break;
            case "feeds":labels=new String[]{"수유 회차"};break;
            default:labels=new String[]{"기록"};break;
        }
        statGraphLegend(card,labels,statsColors(metric));
    }
    private void drawStatistics(LinearLayout root){
        root.addView(text("📊 일별 통계",21,true),margin(-1,-2,4,9));
        LinearLayout period=row();Button week=button("최근 7일"),month=button("최근 30일");
        if(statisticsPeriod==7){week.setBackground(bg(0xFFD88692));week.setTextColor(Color.WHITE);}
        else{month.setBackground(bg(0xFFD88692));month.setTextColor(Color.WHITE);}
        week.setOnClickListener(v->{statisticsPeriod=7;draw();});
        month.setOnClickListener(v->{statisticsPeriod=30;draw();});
        period.addView(week,flex(45));period.addView(month,flex(45));root.addView(period);
        ArrayList<DailyStatistics.Day> days=DailyStatistics.collect(events,statisticsPeriod);
        int feeds=0,breast=0,pumped=0,formula=0,measured=0,diapers=0,poop=0,pee=0,pumpMl=0,pumpCount=0;
        for(DailyStatistics.Day d:days){feeds+=d.feedCount;breast+=d.breastCount;pumped+=d.pumpedMl;
            formula+=d.formulaMl;measured+=d.measured;diapers+=d.diapers;poop+=d.poop;pee+=d.pee;
            pumpMl+=d.pumpMl;pumpCount+=d.pumpCount;}
        LinearLayout overall=card();overall.setPadding(dp(14),dp(13),dp(14),dp(12));
        overall.addView(text("기간별 종합",18,true));
        LinearLayout overview1=row();summaryTile(overview1,"🍼 모유",breast+"회");
        summaryTile(overview1,"🍼 유축수유",pumped+"mL");summaryTile(overview1,"🍼 분유",formula+"mL");
        overall.addView(overview1);
        LinearLayout overview2=row();summaryTile(overview2,"수유 측정",measured+"mL");
        summaryTile(overview2,"🧷 기저귀",diapers+"개");overview2.addView(text("",1,false),flex(64));
        overall.addView(overview2);
        overall.addView(text("수유 "+feeds+"회 · 유축 시작 "+pumpCount+"회 · 유축량 "+pumpMl+"mL · 대변 "+poop+"회 · 소변 "+pee+"회 · 하루 평균 기저귀 "+String.format(Locale.KOREA,"%.1f",(double)diapers/statisticsPeriod)+"개",12,false),margin(-1,-2,8,0));
        root.addView(overall,margin(-1,-2,8,12));
        // The clock stays full width. The eight other graphs become four pairs
        // on landscape/tablet layouts and stay stacked in portrait mode.
        drawFeedingClock(root);
        LinearLayout graphCards=col();
        root.addView(graphCards,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout milks=card();
        statGraphHeader(milks,"일별 수유량 (mL) · 모유수유 횟수",
            "첫 직접 모유수유는 50mL, 이후에는 직전 유축·모유수유 시각으로부터 시간당 약 25mL를 추정합니다. 12시간 이상 공백도 50mL로 다시 시작합니다.\n\n"+
            "막대 위는 실제+추정 표시 합계, 막대 안 숫자는 각 구성량입니다. 추정량은 실제 섭취량·Firebase 실측 합계에 더하지 않습니다.");
        statGraphLegend(milks,"milk");
        milks.addView(statChart(days,true),margin(-1,-2,3,0));graphCards.addView(milks,margin(-1,-2,0,12));
        LinearLayout pumpChart=card();
        statGraphHeader(pumpChart,"일별 유축수유 총량 (mL) + 모유수유 횟수",
            "아기에게 먹인 유축모유의 실제 기록량에 직접 모유수유의 참고용 추정량을 시각적으로 쌓았습니다.\n\n"+
            "첫 직접 모유수유 또는 12시간 이상 공백은 50mL, 이후는 직전 유축·모유 후 시간당 약 25mL로 추정합니다.\n\n"+
            "모유수유 횟수는 모 ○회로 표시합니다. 추정량은 실측 합계에 포함되지 않습니다.");
        statGraphLegend(pumpChart,"pumped");
        pumpChart.addView(statVolumeChart(days,true),margin(-1,-2,4,0));graphCards.addView(pumpChart,margin(-1,-2,0,12));
        LinearLayout formulaChart=card();
        statGraphHeader(formulaChart,"일별 분유량 (mL)",
            "각 날짜에 아기에게 먹인 분유 총량을 표시합니다. 막대 위에는 총량(mL), 막대 안에는 mL를 생략한 분유량 숫자를 표시합니다.");
        statGraphLegend(formulaChart,"formula");
        formulaChart.addView(statVolumeChart(days,false),margin(-1,-2,4,0));graphCards.addView(formulaChart,margin(-1,-2,0,12));
        LinearLayout deepInsights=drawExtraStatistics(graphCards,days);
        arrangeStatsGraphs(graphCards);
        LinearLayout detail=card();detail.addView(text("날짜별 상세",18,true));
        detail.addView(text("모유=수유 횟수 · 유축량=직접 짠 양 · 유축 수유=아기에게 먹인 양",12,false),margin(-1,-2,4,8));
        SimpleDateFormat fmt=new SimpleDateFormat("MM/dd",Locale.KOREA);
        for(int i=days.size()-1;i>=0;i--){DailyStatistics.Day d=days.get(i);
            LinearLayout line=col();line.setPadding(dp(5),dp(9),dp(5),dp(9));
            line.addView(text(fmt.format(d.date)+"   모유 "+d.breastCount+"회 · 유축량 "+d.pumpMl+"mL · 유축 수유 "+d.pumpedMl+"mL · 분유 "+d.formulaMl+"mL",13,true));
            TextView second=text("수유 "+d.feedCount+"회 · 대변 "+d.poop+"회 · 소변 "+d.pee+"회 · 기저귀 "+d.diapers+"개",12,false);
            second.setTextColor(MUTED);line.addView(second,margin(-1,-2,3,0));detail.addView(line);
        }
        root.addView(detail,margin(-1,-2,0,12));
        root.addView(deepInsights,margin(-1,-2,0,16));
    }
    /** Reflow the eight bar charts into two equal-width columns on wide landscape devices.
     *  The clock and period/record details are intentionally outside this container.
     *  Existing cards are moved, not recreated: no changes to Firestore or calculations. */
    private boolean wideStatsScreen(){
        Configuration cfg=getResources().getConfiguration();
        return cfg.orientation==Configuration.ORIENTATION_LANDSCAPE && cfg.screenWidthDp>=700;
    }
    private void arrangeStatsGraphs(LinearLayout chartContainer){
        boolean wide=wideStatsScreen();
        if(!wide)return;
        ArrayList<View> cards=new ArrayList<>();
        while(chartContainer.getChildCount()>0){
            View child=chartContainer.getChildAt(0);
            chartContainer.removeViewAt(0);
            cards.add(child);
        }
        for(int i=0;i<cards.size();i+=2){
            LinearLayout pair=row();
            pair.setGravity(Gravity.TOP);
            for(int j=i;j<Math.min(i+2,cards.size());j++){
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
                lp.setMargins(dp(5),0,dp(5),dp(12));
                pair.addView(cards.get(j),lp);
            }
            // Odd final chart stretches rather than leaving a half-screen blank.
            if(i+1>=cards.size())pair.addView(new View(this),new LinearLayout.LayoutParams(0,1,1f));
            chartContainer.addView(pair,new LinearLayout.LayoutParams(-1,-2));
            // Compact pair: measure both titles and legends and use only the
            // maximum natural size for each row. Avoid previous 75dp/62dp
            // reserved spaces that pushed every chart far below the legend.
            pair.post(()->{
                int[] maxHeights=new int[2];
                for(int child=0;child<pair.getChildCount();child++){
                    View card=pair.getChildAt(child);
                    if(!(card instanceof LinearLayout))continue;
                    LinearLayout column=(LinearLayout)card;
                    if(column.getChildCount()<3)continue;
                    for(int index=0;index<2;index++)
                        maxHeights[index]=Math.max(maxHeights[index],column.getChildAt(index).getHeight());
                }
                for(int child=0;child<pair.getChildCount();child++){
                    View card=pair.getChildAt(child);
                    if(!(card instanceof LinearLayout))continue;
                    LinearLayout column=(LinearLayout)card;
                    if(column.getChildCount()<3)continue;
                    for(int index=0;index<2;index++){
                        View item=column.getChildAt(index);
                        if(maxHeights[index]>item.getMinimumHeight())item.setMinimumHeight(maxHeights[index]);
                    }
                }
                // Normal wrap-content after equalizing title/legend ensures
                // both cards finish on the same baseline without extra padding.
                pair.post(()->{
                    int height=0;
                    for(int child=0;child<pair.getChildCount();child++){
                        View view=pair.getChildAt(child);
                        if(view instanceof LinearLayout)height=Math.max(height,view.getHeight());
                    }
                    for(int child=0;child<pair.getChildCount();child++){
                        View view=pair.getChildAt(child);
                        if(view instanceof LinearLayout && height>0 && view.getHeight()!=height){
                            LinearLayout.LayoutParams params=(LinearLayout.LayoutParams)view.getLayoutParams();
                            params.height=height;
                            view.setLayoutParams(params);
                        }
                    }
                });
            });
        }
    }
    /** Exactly one 00:00–24:00 chart for each calendar day (not a rolling 24h period).
     * Each source feed is plotted separately; no 60-minute clustering here. */
    private static final String[] TIMELINE_TYPES={"breast","pumped","formula","mixed","other"};
    private static final String[] TIMELINE_LABELS={"직접 모유","유축수유","분유","혼합","기타"};
    private static final int[] TIMELINE_COLORS={0xFFC6A04F,0xFF6597CF,0xFFCE7E93,0xFFAA82BE,0xFF9A929C};
    private static String timelineType(Map<String,Object> row){
        if(row==null||Boolean.TRUE.equals(row.get("legacy")))return "other";
        Object parts=row.get("feedParts");
        int breast=0,pumped=0,formula=0;boolean unknown=FamilyStore.unknownBreast(row);
        if(parts instanceof Map){Map<?,?> map=(Map<?,?>)parts;
            breast=FamilyStore.number(map.get("breastMl"));pumped=FamilyStore.number(map.get("pumpedMl"));formula=FamilyStore.number(map.get("formulaMl"));
        }else{
            String type=String.valueOf(row.get("feedType"));int amount=FamilyStore.number(row.get("ml"));
            if("breast".equals(type))breast=Math.max(0,amount);
            else if("pumped".equals(type))pumped=Math.max(0,amount);
            else if("formula".equals(type))formula=Math.max(0,amount);
        }
        int kinds=((breast>0||unknown)?1:0)+(pumped>0?1:0)+(formula>0?1:0);
        if(kinds>1||"mixed".equals(row.get("feedType")))return "mixed";
        if(breast>0||unknown||"breast".equals(row.get("feedType")))return "breast";
        if(pumped>0||"pumped".equals(row.get("feedType")))return "pumped";
        if(formula>0||"formula".equals(row.get("feedType")))return "formula";
        return "other";
    }
    private static int timelineTypeIndex(String kind){for(int i=0;i<TIMELINE_TYPES.length;i++)if(TIMELINE_TYPES[i].equals(kind))return i;return 4;}
    /** v2.76 native feeding clock: same session rules as web with yesterday ghost marks. */
    private void drawFeedingClock(LinearLayout root){
        Calendar cal=Calendar.getInstance();
        final long now=System.currentTimeMillis();
        cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);
        cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
        final long midnight=cal.getTimeInMillis();
        cal.add(Calendar.DAY_OF_MONTH,-1);
        final long yesterdayStart=cal.getTimeInMillis(); // Local day boundary, safe across DST.
        ArrayList<DocumentSnapshot> feeds=new ArrayList<>();
        ArrayList<FeedClockView.Mark> marks=new ArrayList<>();
        SimpleDateFormat fmt=new SimpleDateFormat("a hh:mm",Locale.KOREAN);
        for(DocumentSnapshot d:events){
            Date at=d.getDate("at");
            if(at==null||!FamilyStore.FEED.equals(d.getString("kind")))continue;
            long stamp=at.getTime();if(stamp<yesterdayStart||stamp>now)continue;
            int type=timelineTypeIndex(timelineType(d.getData()));
            boolean previous=stamp<midnight;
            String details=previous?"":fmt.format(at)+"  "+TIMELINE_LABELS[type]+" · "+FamilyStore.detail(d.getData());
            marks.add(new FeedClockView.Mark(stamp,TIMELINE_COLORS[type],previous,details));
            if(!previous)feeds.add(d);
        }
        // Keep every real today record as a dot, but count an anchored 60-minute
        // group only once. No yesterday record enters counts or the detail list.
        java.util.Collections.sort(feeds,(a,b)->Long.compare(a.getDate("at").getTime(),b.getDate("at").getTime()));
        ArrayList<FeedSessions.Session> sessions=FeedSessions.group(feeds);
        int morning=0,afternoon=0;
        for(FeedSessions.Session session:sessions){
            cal.setTimeInMillis(session.startedAt);
            if(cal.get(Calendar.HOUR_OF_DAY)<12)morning++;else afternoon++;
        }
        cal.setTimeInMillis(now);
        LinearLayout clock=card();
        statGraphHeader(clock,"🕒 오늘 수유 시계 · 전날 흐린 점 비교",
            "오늘 수유는 첫 수유 후 1시간 이내 이어진 기록을 1회로 묶습니다. " +
            "개별 수유는 점으로 표시하고 오늘 점을 누르면 상세 내용을 볼 수 있습니다. " +
            "전날 수유는 불투명도 30%(70% 투명)의 점만 표시하며 오늘 횟수와 목록에는 포함하지 않습니다. " +
            "안쪽 원 오전, 바깥 원 오후입니다.");
        clock.addView(text("오늘 "+(cal.get(Calendar.MONTH)+1)+"월 "+cal.get(Calendar.DAY_OF_MONTH)+"일 · 총 "+sessions.size()+"회",15,true),margin(-1,-2,4,7));
        LinearLayout keys=row();
        TextView am=text("● 안쪽 · 오전  "+morning+"회",12,true),pm=text("● 바깥 · 오후  "+afternoon+"회",12,true);
        am.setGravity(Gravity.CENTER);pm.setGravity(Gravity.CENTER);
        am.setTextColor(darkMode?0xFFA7C8ED:0xFF457EBC);
        pm.setTextColor(darkMode?0xFFF2B8CB:0xFFC8799A);
        keys.addView(am,new LinearLayout.LayoutParams(0,-2,1f));
        keys.addView(pm,new LinearLayout.LayoutParams(0,-2,1f));
        clock.addView(keys,margin(-1,-2,3,5));
        FeedClockView view=new FeedClockView(this,marks,sessions.size(),morning,afternoon,darkMode);
        clock.addView(view,new LinearLayout.LayoutParams(-1,dp(318)));
        TextView picked=text("● 오늘 수유 점을 누르면 시각과 양을 확인할 수 있어요",12,false);
        picked.setTextColor(darkMode?0xFFF3DEE9:0xFF77556B);
        picked.setPadding(dp(9),dp(6),dp(9),dp(6));
        view.setOnMarkSelectedListener(mark->picked.setText(mark.detail));
        clock.addView(picked,margin(-1,-2,4,8));
        LinearLayout legend=row();
        for(int i=0;i<4;i++){
            TextView x=text("● "+TIMELINE_LABELS[i],10,true);
            x.setTextColor(darkMode?INK:TIMELINE_COLORS[i]);x.setGravity(Gravity.CENTER);
            legend.addView(x,new LinearLayout.LayoutParams(0,-2,1f));
        }
        clock.addView(legend,margin(-1,-2,5,10));
        for(int half=0;half<2;half++){
            boolean isMorning=half==0;
            TextView title=text(isMorning?"오전 00:00~11:59  ·  "+morning+"회":"오후 12:00~23:59  ·  "+afternoon+"회",13,true);
            title.setTextColor(darkMode?INK:(isMorning?0xFF457EBC:0xFFC8799A));
            clock.addView(title,margin(-1,-2,7,6));
            int shown=0;
            for(DocumentSnapshot d:feeds){
                Date at=d.getDate("at");cal.setTime(at);
                if((cal.get(Calendar.HOUR_OF_DAY)<12)!=isMorning)continue;
                int type=timelineTypeIndex(timelineType(d.getData()));
                TextView line=text("● "+fmt.format(at)+"  "+TIMELINE_LABELS[type]+" · "+FamilyStore.detail(d.getData()),12,true);
                line.setTextColor(darkMode?INK:TIMELINE_COLORS[type]);
                clock.addView(line,margin(-1,-2,4,5));shown++;
            }
            if(shown==0){TextView empty=text("수유 기록 없음",12,false);empty.setTextColor(MUTED);
                clock.addView(empty,margin(-1,-2,4,6));}
        }
        root.addView(clock,margin(-1,-2,0,12));
    }
    /** Native Android bar charts: no Canvas, with all 7 days fitted to screen. */
    private LinearLayout statVolumeChart(ArrayList<DailyStatistics.Day> days,boolean pumping){
        return nativeStatsChart(days,pumping?"pumped":"formula");
    }
    private LinearLayout statChart(ArrayList<DailyStatistics.Day> days,boolean milk){
        return nativeStatsChart(days,milk?"milk":"diapers");
    }
    /** Seven days share available width; thirty days can scroll horizontally. */
    private LinearLayout nativeStatsChart(ArrayList<DailyStatistics.Day> days,String metric){
        LinearLayout outer=col();
        int max=1;
        for(DailyStatistics.Day d:days)max=Math.max(max,statsValue(d,metric));
        TextView axis=text("날짜별 · 최대 "+max+(statsIsMl(metric)?"mL":"회/개"),11,false);
        axis.setTextColor(MUTED);outer.addView(axis,margin(-1,-2,2,2));
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        LinearLayout bars=row();bars.setGravity(Gravity.BOTTOM);
        // Taller stacked bars leave room for color-by-color values inside each segment.
        final int chartHeight=163;
        for(DailyStatistics.Day d:days){
            final int volume=statsValue(d,metric);
            LinearLayout column=col();column.setGravity(Gravity.CENTER_HORIZONTAL);
            String count=(metric.equals("milk")||metric.equals("pumped")||metric.equals("pumpOutput"))?"모 "+d.breastCount+"회":"";
            TextView breast=text(count.isEmpty()?" ":count,9,true);breast.setTextColor(INK);breast.setGravity(Gravity.CENTER);
            column.addView(breast,new LinearLayout.LayoutParams(-1,dp(17)));
            // Total above the bar is the sum of all visible segments, including
            // display-only breast estimate; period measured totals are unchanged.
            String val=statsIsMl(metric)?volume+"mL":String.valueOf(volume);
            TextView number=text(val,days.size()>7?9:9,true);number.setTextColor(darkMode?0xFFBCD7F3:0xFF445E81);number.setGravity(Gravity.CENTER);
            number.setSingleLine(true);column.addView(number,new LinearLayout.LayoutParams(-1,dp(22)));
            android.widget.FrameLayout cell=new android.widget.FrameLayout(this);
            LinearLayout segments=col();segments.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            int[] values=statsParts(d,metric);
            int[] colors=statsColors(metric);
            int totalHeight=(int)Math.round(chartHeight*(volume/(double)max));int used=0;
            final int barWidth=days.size()<=7?25:27;
            // Android vertical LinearLayout lays children top to bottom. Reverse
            // the segments so formula/actual sits at the bottom like web Canvas.
            for(int j=values.length-1;j>=0;j--){
                if(values[j]<=0)continue;
                int height=Math.max(1,(int)Math.round(chartHeight*(values[j]/(double)max)));
                if(j==0)height=Math.max(1,totalHeight-used);
                used+=height;
                android.widget.FrameLayout block=new android.widget.FrameLayout(this);
                block.setBackgroundColor(colors[j]);
                // Values are printed without "mL" and only when the colored
                // portion is tall enough: no collision between adjacent bands.
                String digits=String.valueOf(values[j]);
                if(height>=23&&digits.length()<=4){
                    TextView inside=text(digits,digits.length()>=4?8:9,true);
                    boolean darkBackground=colors[j]==0xFFD88692||colors[j]==0xFF7A9CCE||colors[j]==0xFFA18ACA;
                    inside.setTextColor(darkBackground?0xFFFFFFFF:0xFF233745);
                    inside.setGravity(Gravity.CENTER);inside.setSingleLine(true);
                    block.addView(inside,new android.widget.FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
                }
                segments.addView(block,new LinearLayout.LayoutParams(dp(barWidth),dp(height)));
            }
            if(volume==0){View baseline=new View(this);baseline.setBackgroundColor(darkMode?0xFF524651:0xFFEFE4E7);
                segments.addView(baseline,new LinearLayout.LayoutParams(dp(barWidth),dp(1)));}
            cell.addView(segments,new android.widget.FrameLayout.LayoutParams(dp(30),dp(chartHeight),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL));
            column.addView(cell,new LinearLayout.LayoutParams(-1,dp(chartHeight)));
            Calendar date=Calendar.getInstance();date.setTime(d.date);
            TextView label=text(String.valueOf(date.get(Calendar.DAY_OF_MONTH)),10,false);
            label.setGravity(Gravity.CENTER);label.setTextColor(MUTED);
            column.addView(label,new LinearLayout.LayoutParams(-1,dp(24)));
            // The seven-day chart uses weighted columns, allowing exactly seven visible bars.
            if(days.size()<=7)bars.addView(column,new LinearLayout.LayoutParams(0,dp(227),1f));
            else bars.addView(column,new LinearLayout.LayoutParams(dp(45),dp(227)));
        }
        scroll.addView(bars,new android.widget.FrameLayout.LayoutParams(days.size()<=7?-1:dp(days.size()*45),dp(227)));
        outer.addView(scroll,new LinearLayout.LayoutParams(-1,dp(237)));
        return outer;
    }
    private static boolean statsIsMl(String metric){return metric.equals("milk")||metric.equals("pumped")||metric.equals("formula")||metric.equals("pumpOutput");}
    private static int statsValue(DailyStatistics.Day d,String metric){
        switch(metric){
            case "milk":return d.measured+d.breastEstimatedMl;
            case "pumped":return d.pumpedMl+d.breastEstimatedMl;
            case "formula":return d.formulaMl;
            case "diapers":return d.diapers;
            case "pumpOutput":return d.pumpMl+d.breastEstimatedMl;
            case "feeds":return d.feedCount;
            case "breast":return d.breastCount;
            case "diaperBreakdown":return d.diapers;
            default:return 0;
        }
    }
    private static int[] statsParts(DailyStatistics.Day d,String metric){
        switch(metric){
            case "milk":return new int[]{d.formulaMl,d.pumpedMl,d.breastMl,d.breastEstimatedMl};
            case "pumped":return new int[]{d.pumpedMl,d.breastEstimatedMl};
            case "pumpOutput":return new int[]{d.pumpMl,d.breastEstimatedMl};
            case "diaperBreakdown":return new int[]{Math.max(0,d.pee-d.both),Math.max(0,d.poop-d.both),d.both};
            default:return new int[]{statsValue(d,metric)};
        }
    }
    private static int[] statsColors(String metric){
        switch(metric){
            case "milk":return new int[]{0xFFD88692,0xFF77A6D5,0xFFEAC276,0xFFF5D99B};
            case "pumped":return new int[]{0xFF77A6D5,0xFFF5D99B};
            case "formula":return new int[]{0xFFD88692};
            case "pumpOutput":return new int[]{0xFF8BB4A4,0xFFF5D99B};
            case "breast":return new int[]{0xFFE0B965};
            case "diaperBreakdown":return new int[]{0xFF75A6D0,0xFFD88692,0xFFA18ACA};
            case "diapers":return new int[]{0xFF69B59F};
            default:return new int[]{0xFF7A9CCE};
        }
    }
    private void extraGraph(LinearLayout root,ArrayList<DailyStatistics.Day> days,String title,String note,String metric){
        String detail=note==null||note.isEmpty()?"해당 날짜의 기록으로 계산한 그래프입니다.":note;
        if("pumpOutput".equals(metric))detail="실제로 직접 유축한 양에 직접 모유수유 참고용 추정량을 시각적으로 표시합니다. 첫 직접 모유수유와 12시간 초과 공백은 50mL, 이후 직전 유축·직수 후 시간당 약 25mL를 사용합니다. 추정량은 실측 합계에 포함되지 않습니다.";
        if("diaperBreakdown".equals(metric))detail="소변·대변을 함께 기록하면 기저귀 1개로 계산합니다. 날짜별 각 종류의 기록을 합산합니다.";
        LinearLayout c=card();statGraphHeader(c,title,detail);
        statGraphLegend(c,metric);
        c.addView(nativeStatsChart(days,metric),margin(-1,-2,3,0));root.addView(c,margin(-1,-2,0,12));
    }
    private String statTime(double minutes){
        if(Double.isNaN(minutes)||Double.isInfinite(minutes))return "기록 부족";
        int m=(int)Math.round(minutes);return (m/60)+"시간 "+String.format(Locale.KOREA,"%02d",m%60)+"분";
    }
    private static double avgStats(ArrayList<DailyStatistics.Day> days,int start,int end,String type){
        double sum=0;for(int i=start;i<end;i++)sum+=statsValue(days.get(i),type);return sum/Math.max(1,end-start);
    }
    private void statInsight(LinearLayout parent,String title,String value,String note){
        LinearLayout tile=col();tile.setPadding(dp(8),dp(10),dp(8),dp(10));tile.setBackground(bg(0xFFFFF0E7));
        TextView label=text(title,11,true);label.setTextColor(MUTED);tile.addView(label);
        TextView amount=text(value,16,true);amount.setTextColor(INK);tile.addView(amount,margin(-1,-2,5,2));
        TextView hint=text(note,10,false);hint.setTextColor(MUTED);tile.addView(hint);
        parent.addView(tile,new LinearLayout.LayoutParams(0,-2,1f));
    }
    private LinearLayout drawExtraStatistics(LinearLayout root,ArrayList<DailyStatistics.Day> days){
        long first=days.get(0).date.getTime();
        Calendar after=Calendar.getInstance();after.setTime(days.get(days.size()-1).date);after.add(Calendar.DATE,1);
        long last=after.getTimeInMillis();
        ArrayList<FeedSessions.Session> sessions=FeedSessions.group(events);
        int[] timeBuckets=new int[4];int night=0;long previous=-1;double sumGap=0,maxGap=0;int countGaps=0;
        Calendar cal=Calendar.getInstance();
        for(FeedSessions.Session session:sessions){
            if(session.startedAt<first||session.startedAt>=last)continue;
            cal.setTimeInMillis(session.startedAt);int hour=cal.get(Calendar.HOUR_OF_DAY);
            timeBuckets[hour/6]++;if(hour>=22||hour<6)night++;
            if(previous>=0){double gap=(session.startedAt-previous)/60000d;if(gap>0){sumGap+=gap;countGaps++;maxGap=Math.max(maxGap,gap);}}
            previous=session.startedAt;
        }
        int measured=0,feeds=0,breast=0,unmeasured=0,pumped=0,formula=0,pumpMl=0,pumpCount=0,diapers=0,pee=0,poop=0,both=0;
        for(DailyStatistics.Day d:days){measured+=d.measured;feeds+=d.feedCount;breast+=d.breastCount;
            unmeasured+=d.breastUnmeasured;pumped+=d.pumpedMl;formula+=d.formulaMl;pumpMl+=d.pumpMl;
            pumpCount+=d.pumpCount;diapers+=d.diapers;pee+=d.pee;poop+=d.poop;both+=d.both;}
        int knownPumps=0;
        for(DocumentSnapshot snap:events){Date date=snap.getDate("at");if(date==null)continue;
            if(date.getTime()>=first&&date.getTime()<last&&FamilyStore.PUMP.equals(snap.getString("kind"))&&FamilyStore.number(snap.get("ml"))>0)knownPumps++;}
        ArrayList<String[]> cards=new ArrayList<>();
        cards.add(new String[]{"하루 평균 실측 수유량",(measured/days.size())+"mL","모유 미측정량 제외"});
        cards.add(new String[]{"하루 평균 수유 회차",String.format(Locale.KOREA,"%.1f회",feeds/(double)days.size()),"첫 수유 후 1시간 이내 묶음"});
        cards.add(new String[]{"수유 회차당 실측량",feeds>0?(measured/feeds)+"mL":"기록 없음","모유 미측정량 제외"});
        cards.add(new String[]{"평균 수유 간격",countGaps>0?statTime(sumGap/countGaps):"기록 부족","기록된 회차의 시작 시각 기준"});
        cards.add(new String[]{"가장 긴 수유 간격",countGaps>0?statTime(maxGap):"기록 부족","기간 내 연속 회차 간격"});
        cards.add(new String[]{"밤 수유 회차",night+"회","22:00 ~ 06:00 시작"});
        cards.add(new String[]{"하루 평균 유축수유",(pumped/days.size())+"mL","아기에게 먹인 양"});
        cards.add(new String[]{"하루 평균 분유",(formula/days.size())+"mL","기록된 분유량"});
        cards.add(new String[]{"직접 모유수유",breast+"회","미측정 "+unmeasured+"회차"});
        cards.add(new String[]{"실측 수유량 비율","유축 "+(measured==0?0:Math.round(pumped*100d/measured))+"% · 분유 "+(measured==0?0:Math.round(formula*100d/measured))+"%","실측 전체 대비 (측정 모유도 포함)"});
        cards.add(new String[]{"직접 유축량",pumpMl+"mL","유축 시작 "+pumpCount+"회"});
        cards.add(new String[]{"1회 평균 직접 유축",knownPumps>0?(pumpMl/knownPumps)+"mL":"기록 없음","유축량 입력된 기록만"});
        cards.add(new String[]{"하루 평균 기저귀",String.format(Locale.KOREA,"%.1f개",diapers/(double)days.size()),"소+대변은 1개"});
        cards.add(new String[]{"소변 / 대변",pee+"회 / "+poop+"회","소+대변 "+both+"회"});
        if(days.size()>=7){
            int n=days.size();double beforeMilk=avgStats(days,n-7,n-4,"milk"),nowMilk=avgStats(days,n-4,n-1,"milk");
            // Use the measured milk amount, without graph-only time-based estimates, for trends.
            double beforeActual=0,nowActual=0;
            for(int i=n-7;i<n-4;i++)beforeActual+=days.get(i).measured/3d;
            for(int i=n-4;i<n-1;i++)nowActual+=days.get(i).measured/3d;
            cards.add(new String[]{"최근 3일 실측 수유 평균",Math.round(nowActual)+"mL",percentNote(nowActual,beforeActual)});
            double bf=avgStats(days,n-7,n-4,"formula"),nf=avgStats(days,n-4,n-1,"formula");
            cards.add(new String[]{"최근 3일 분유 평균",Math.round(nf)+"mL",percentNote(nf,bf)});
            double bs=avgStats(days,n-7,n-4,"feeds"),ns=avgStats(days,n-4,n-1,"feeds");
            cards.add(new String[]{"최근 3일 수유 회차",String.format(Locale.KOREA,"%.1f회",ns),"이전 3일 대비 "+String.format(Locale.KOREA,"%+.1f회",ns-bs)});
        }
        LinearLayout card=card();card.addView(text("🔎 수유·기저귀 심층 통계",18,true));
        TextView disclosure=text("기간 기록 기반 · 실측 수유량과 모유수유 시각적 추정량은 분리 · 건강 상태 판단 목적 아님",11,false);
        disclosure.setTextColor(MUTED);card.addView(disclosure,margin(-1,-2,5,10));
        for(int i=0;i<cards.size();i+=2){
            LinearLayout row=row();
            for(int j=i;j<Math.min(i+2,cards.size());j++){
                String[] values=cards.get(j);statInsight(row,values[0],values[1],values[2]);
            }
            if(i+1>=cards.size())row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1f));
            card.addView(row,margin(-1,-2,5,0));
        }
        extraGraph(root,days,"🥛 일별 직접 유축량 + 모유 추정","초록=실측 유축 · 연노랑=첫 직수 50mL, 이후 시간당 약 25mL 추정(실측량에 미포함)","pumpOutput");
        extraGraph(root,days,"🍼 일별 수유 회차","첫 수유 후 1시간 이내 기록은 1회차","feeds");
        extraGraph(root,days,"🤱 일별 직접 모유수유 횟수","모유가 포함된 수유 회차 기준","breast");
        LinearLayout timeCard=card();
        statGraphHeader(timeCard,"🌙 시간대별 수유 패턴",
            "수유 회차가 시작된 시간대를 6시간 단위로 집계합니다. 첫 수유 이후 1시간 이내 수유는 같은 회차로 묶습니다.");
        statGraphLegend(timeCard,new String[]{"00~06시","06~12시","12~18시","18~24시"},
            new int[]{0xFF8C9FD2,0xFFE7C981,0xFFD88692,0xFF8CA5BB});
        String[] labels={"00~06","06~12","12~18","18~24"};
        int totalMax=1;for(int val:timeBuckets)totalMax=Math.max(totalMax,val);
        LinearLayout graph=row();graph.setGravity(Gravity.BOTTOM);
        for(int i=0;i<4;i++){
            LinearLayout col=col();col.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView number=text(timeBuckets[i]+"회",11,true);number.setGravity(Gravity.CENTER);col.addView(number,new LinearLayout.LayoutParams(-1,dp(24)));
            android.widget.FrameLayout cell=new android.widget.FrameLayout(this);
            View bar=new View(this);bar.setBackgroundColor(new int[]{0xFF8C9FD2,0xFFE7C981,0xFFD88692,0xFF8CA5BB}[i]);
            int bh=Math.max(1,(int)Math.round(116*timeBuckets[i]/(double)totalMax));
            cell.addView(bar,new android.widget.FrameLayout.LayoutParams(dp(36),dp(bh),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL));
            col.addView(cell,new LinearLayout.LayoutParams(-1,dp(116)));
            TextView label=text(labels[i],10,false);// Narrow the bottom-label band on landscape to place the time chart
            // baseline level with the neighbouring diaper chart.
            label.setGravity(Gravity.CENTER);col.addView(label,new LinearLayout.LayoutParams(-1,dp(wideStatsScreen()?19:25)));
            graph.addView(col,new LinearLayout.LayoutParams(0,dp(wideStatsScreen()?161:167),1f));
        }
        if(wideStatsScreen()){
            android.widget.FrameLayout plot=new android.widget.FrameLayout(this);
            plot.addView(graph,new android.widget.FrameLayout.LayoutParams(-1,dp(161),Gravity.BOTTOM));
            timeCard.addView(plot,new LinearLayout.LayoutParams(-1,dp(208)));
        }else timeCard.addView(graph,margin(-1,-2,9,0));
        root.addView(timeCard,margin(-1,-2,0,12));
        extraGraph(root,days,"🧷 일별 기저귀 종류","파랑: 소변만 · 분홍: 대변만 · 보라: 소+대변 (1개)","diaperBreakdown");
        return card;
    }
    private static String percentNote(double now,double before){
        if(before==0)return now==0?"이전 3일 대비 변화 없음":"이전 3일 0mL · 비율 비교 불가";
        return String.format(Locale.KOREA,"이전 3일 대비 %+.1f%%",(now-before)/before*100d);
    }
    private long startToday(){java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private void record(String kind,String type,int ml,String size){RecordWorker.queue(this,kind,type,ml,size);Toast.makeText(this,"기록 전송 대기 중 · 연결되면 가족에게 표시돼요",Toast.LENGTH_SHORT).show();}
    private void pickDiaperType(){
        new AlertDialog.Builder(this).setTitle("🧷 기저귀 종류")
            .setItems(new String[]{"💧 소변","💩 대변","💧💩 소+대변"},(d,i)->pickDiaper(new String[]{FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH}[i])).show();
    }
    private void pickPumpStart(){
        new AlertDialog.Builder(this).setTitle("🥛 유축 시작 기록")
            .setMessage("시작 시각만 먼저 저장합니다. 유축량은 가족 최근 기록에서 나중에 수정할 수 있어요.")
            .setPositiveButton("지금 시작 저장",(d,w)->savePumpStart(System.currentTimeMillis()))
            .setNeutralButton("과거 시각 선택",(d,w)->choosePastPumpStart()).setNegativeButton("취소",null).show();
    }
    private void choosePastPumpStart(){
        Calendar when=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->{
            when.set(y,m,d);
            new TimePickerDialog(this,(t,h,minute)->{
                when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,minute);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);
                savePumpStart(when.getTimeInMillis());
            },when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show();
        },when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void savePumpStart(long at){
        Calendar earliest=Calendar.getInstance();earliest.set(2020,0,1,0,0,0);
        if(at<earliest.getTimeInMillis()||at>System.currentTimeMillis()+300000L){
            Toast.makeText(this,"유축 시작 시각은 2020년부터 현재까지 선택하세요.",Toast.LENGTH_LONG).show();return;
        }
        RecordWorker.queueFull(this,java.util.UUID.randomUUID().toString(),FamilyStore.PUMP,"",0,"",at,false);
        Toast.makeText(this,"유축 시작 기록 전송 중 · 양은 기록을 눌러 수정하세요",Toast.LENGTH_LONG).show();
    }
    private void pickDiaper(String kind){String[] labels={"소 · 적음","중 · 보통","대 · 많음"},sizes={"small","medium","large"};
        new AlertDialog.Builder(this).setTitle(FamilyStore.kindLabel(kind)+" 양").setItems(labels,(d,i)->record(kind,"",0,sizes[i])).show();}
    private TextView summaryTile(LinearLayout row,String title,String value){
        return summaryTile(row,title,value,false);
    }
    private TextView summaryTile(LinearLayout row,String title,String value,boolean compact){
        LinearLayout tile=col();tile.setPadding(dp(5),dp(7),dp(5),dp(7));tile.setBackground(bg(0xFFFFF0E7));
        TextView label=text(title,12,true);label.setGravity(Gravity.CENTER);tile.addView(label);
        TextView data=text(value,13,true);data.setGravity(Gravity.CENTER);tile.addView(data,margin(-1,-2,3,0));
        row.addView(tile,flex(compact?60:64));return data;
    }
    /** The feeding tiles keep elapsed time prominent and each event's measured amount below it. */
    private TextView[] feedSummaryTile(LinearLayout parent,String label){
        LinearLayout tile=col();tile.setPadding(dp(7),dp(7),dp(7),dp(7));tile.setBackground(bg(0xFFFFF0E7));
        TextView name=text(label,12,true);name.setGravity(Gravity.CENTER);tile.addView(name);
        TextView time=text("기록 없음",19,true);time.setGravity(Gravity.CENTER);tile.addView(time,margin(-1,-2,2,0));
        TextView amount=text("수유량 없음",12,false);amount.setGravity(Gravity.CENTER);
        amount.setTextColor(darkMode?INK:0xFF78606D);tile.addView(amount,margin(-1,-2,2,0));
        parent.addView(tile,flex(91));return new TextView[]{time,amount};
    }
    private String since(Date date){
        return ElapsedTime.display(date==null?-1:date.getTime());
    }
    private String feedingAmountText(DocumentSnapshot snap){
        if(snap==null)return "수유량 없음";
        Map<String,Object> item=snap.getData();if(item==null||Boolean.TRUE.equals(item.get("legacy")))return "수유량 정보 없음";
        int total=FamilyStore.knownMl(item);
        int breast=sourceAmount(item,"breastMl",FamilyStore.BREAST);
        int pumped=sourceAmount(item,"pumpedMl",FamilyStore.PUMPED);
        int formula=sourceAmount(item,"formulaMl",FamilyStore.FORMULA);
        boolean unknown=FamilyStore.unknownBreast(item);
        ArrayList<String> parts=new ArrayList<>();
        if(breast>0)parts.add("모유 "+breast);
        if(unknown)parts.add("모유 미측정");
        if(pumped>0)parts.add("유축 "+pumped);
        if(formula>0)parts.add("분유 "+formula);
        if(total==0)return unknown?"모유 미측정":"수유량 정보 없음";
        return android.text.TextUtils.join(" + ",parts)+" · 합계 "+total+"mL";
    }
    /** Count breast sessions and milk volumes individually, including older single-source events. */
    private boolean hasBreast(Map<String,Object> item){
        if(Boolean.TRUE.equals(item.get("legacy")))return false;
        Object raw=item.get("feedParts");
        if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
            return FamilyStore.number(p.get("breastMl"))>0||Boolean.TRUE.equals(p.get("breastUnmeasured"));
        }
        return FamilyStore.BREAST.equals(item.get("feedType"));
    }
    private int sourceAmount(Map<String,Object> item,String key,String oldType){
        if(Boolean.TRUE.equals(item.get("legacy")))return 0;
        Object raw=item.get("feedParts");
        if(raw instanceof Map)return Math.max(0,FamilyStore.number(((Map<?,?>)raw).get(key)));
        return oldType.equals(item.get("feedType"))?Math.max(0,FamilyStore.number(item.get("ml"))):0;
    }
    private void updateSummary(){
        if(dailyFeed==null||dailyPoop==null||dailyPee==null||todayBreast==null)return;
        int[] feeds=new int[2], totals=new int[2], breasts=new int[2], pumped=new int[2], formula=new int[2];
        int[] poops=new int[2], pees=new int[2], diapers=new int[2], pumpCounts=new int[2], pumpVolumes=new int[2];
        Date lf=null,lp=null,lu=null;
        PumpHistory pumpHistory=new PumpHistory();
        ArrayList<PumpForecast.Event> pumpForecastEvents=new ArrayList<>();
        DocumentSnapshot newestFeed=null,olderFeed=null;
        long day=startToday(),now=System.currentTimeMillis();
        Calendar previous=Calendar.getInstance();previous.setTimeInMillis(day);previous.add(Calendar.DAY_OF_MONTH,-1);
        long yesterday=previous.getTimeInMillis();
        for(DocumentSnapshot snap:events){
            Date date=snap.getDate("at");if(date==null||date.getTime()>now+300000L)continue;
            String kind=snap.getString("kind");if(kind==null)continue;
            if(FamilyStore.FEED.equals(kind)){
                if(newestFeed==null||date.after(newestFeed.getDate("at"))){
                    olderFeed=newestFeed;newestFeed=snap;
                }else if(olderFeed==null||date.after(olderFeed.getDate("at"))){
                    olderFeed=snap;
                }
            }
            if(FamilyStore.FEED.equals(kind)&&(lf==null||date.after(lf)))lf=date;
            if(FamilyStore.PUMP.equals(kind)
                ||(FamilyStore.FEED.equals(kind)&&snap.getData()!=null&&hasBreast(snap.getData()))){
                pumpHistory.add(date.getTime());
                pumpForecastEvents.add(new PumpForecast.Event(date.getTime(),
                    FamilyStore.PUMP.equals(kind),FamilyStore.PUMP.equals(kind)?FamilyStore.number(snap.get("ml")):0));
            }
            if((FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))&&(lp==null||date.after(lp)))lp=date;
            if((FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))&&(lu==null||date.after(lu)))lu=date;
            long at=date.getTime();
            int d=at>=day?0:(at>=yesterday?1:-1);
            if(d<0)continue;
            if(FamilyStore.PUMP.equals(kind)){pumpCounts[d]++;pumpVolumes[d]+=Math.max(0,FamilyStore.number(snap.get("ml")));}
            if(FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))pees[d]++;
            if(FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))poops[d]++;
            if(FamilyStore.PEE.equals(kind)||FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))diapers[d]++;
            if(FamilyStore.FEED.equals(kind)){
                Map<String,Object> item=snap.getData();if(item==null)continue;
                totals[d]+=FamilyStore.knownMl(item);
                pumped[d]+=sourceAmount(item,"pumpedMl",FamilyStore.PUMPED);
                formula[d]+=sourceAmount(item,"formulaMl",FamilyStore.FORMULA);
            }
        }
        // 1-hour sessions are anchored at the first feed. Subsequent feeds
        // within the window contribute milk volume but not another session.
        for(FeedSessions.Session session:FeedSessions.group(events)) {
            int bucket=session.startedAt>=day?0:(session.startedAt>=yesterday?1:-1);
            if(bucket>=0){feeds[bucket]++;if(session.includesBreast)breasts[bucket]++;}
        }
        todayBreast.setText(breasts[0]+"회");todayPumped.setText(pumped[0]+"mL");todayFormula.setText(formula[0]+"mL");
        yesterdayBreast.setText(breasts[1]+"회");yesterdayPumped.setText(pumped[1]+"mL");yesterdayFormula.setText(formula[1]+"mL");
        dailyPoop.setText(poops[0]+"회");dailyPee.setText(pees[0]+"회");
        yesterdayPoop.setText(poops[1]+"회");yesterdayPee.setText(pees[1]+"회");
        dailyDiapers.setText(diapers[0]+"개");yesterdayDiapers.setText(diapers[1]+"개");
        dailyFeed.setText("수유 총 "+feeds[0]+"회 · 측정량 "+totals[0]+"mL");
        if(todayPumpVolume!=null)todayPumpVolume.setText("🥛 유축 시작 "+pumpCounts[0]+"회 · 직접 유축량 "+pumpVolumes[0]+"mL");
        if(yesterdayPumpVolume!=null)yesterdayPumpVolume.setText("🥛 유축 시작 "+pumpCounts[1]+"회 · 직접 유축량 "+pumpVolumes[1]+"mL");
        yesterdayFeed.setText("수유 총 "+feeds[1]+"회 · 측정량 "+totals[1]+"mL");
        if(lastFeed!=null)lastFeed.setText(since(newestFeed==null?null:newestFeed.getDate("at")));
        if(lastFeedAmount!=null)lastFeedAmount.setText(feedingAmountText(newestFeed));
        if(previousFeed!=null)previousFeed.setText(since(olderFeed==null?null:olderFeed.getDate("at")));
        if(previousFeedAmount!=null)previousFeedAmount.setText(feedingAmountText(olderFeed));
        if(lastPoop!=null)lastPoop.setText(since(lp));
        if(lastPee!=null)lastPee.setText(since(lu));
        if(lastPump!=null)lastPump.setText(pumpHistory.latest()<0?"기록 없음":since(new Date(pumpHistory.latest())));
        if(previousPump!=null)previousPump.setText(pumpHistory.previous()<0?"기록 없음":since(new Date(pumpHistory.previous())));
        if(pumpNowEstimate!=null){
            PumpForecast.Model model=PumpForecast.analyze(pumpForecastEvents,now);
            int forecast=PumpForecast.estimate(pumpHistory.latest(),now,model.factor);
            boolean inPause=pumpHistory.latest()>0&&now>=pumpHistory.latest()&&now-pumpHistory.latest()<20L*60_000L;
            pumpNowEstimate.setText(forecast<0?"🥛 지금 유축 예상량 · 기록 없음":
                inPause?"🥛 지금 유축 예상 0mL · 유축·직접 모유수유 후 20분 대기":
                "🥛 지금 유축 예상 "+forecast+"mL · "+(model.samples>0?
                    "3일 유축 "+model.samples+"회 분석":"기본 추정")+" · 20분 이후 계산 · 최대 200mL");
        }
    }
    private static class FeedInputs {
        EditText breast,pumped,formula;CheckBox unknown;
    }
    private EditText amountLine(LinearLayout parent,String label,int current){
        parent.addView(text(label+" (mL)",14,true),margin(-1,-2,9,0));
        LinearLayout line=row();EditText input=new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setSingleLine(true);
        input.setText(String.valueOf(current));input.setSelectAllOnFocus(true);
        Button minus=button("−5"),plus=button("+5");
        minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(0,n-5)));});
        plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        line.addView(minus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,dp(54),1);mid.setMargins(dp(8),0,dp(8),0);line.addView(input,mid);
        line.addView(plus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        parent.addView(line);return input;
    }
    private int parseAmount(EditText input){try{return Integer.parseInt(input.getText().toString().trim());}catch(Exception e){return 0;}}
    private FeedInputs feedInputs(LinearLayout parent,Map<String,Object> item,boolean isExisting){
        int breast=0,pumped=isExisting?0:FamilyStore.defaultPumpedMl(this),formula=isExisting?0:FamilyStore.defaultFormulaMl(this);boolean unknown=false;
        if(isExisting&&item!=null){Object raw=item.get("feedParts");
            if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
                breast=FamilyStore.number(p.get("breastMl"));pumped=FamilyStore.number(p.get("pumpedMl"));
                formula=FamilyStore.number(p.get("formulaMl"));unknown=Boolean.TRUE.equals(p.get("breastUnmeasured"));
            }else{
                int ml=FamilyStore.number(item.get("ml"));String type=String.valueOf(item.get("feedType"));
                if(FamilyStore.BREAST.equals(type)){if(ml<0)unknown=true;else breast=ml;}
                else if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                else if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
            }
        }
        parent.addView(text("모유는 별도 수유, 새 혼합은 유축 + 분유만 입력 · 5mL 단위",12,false));
        FeedInputs f=new FeedInputs();f.breast=amountLine(parent,"모유",breast);
        f.pumped=amountLine(parent,"유축",pumped);f.formula=amountLine(parent,"분유",formula);
        f.unknown=new CheckBox(this);f.unknown.setText("직접 모유 수유 · 양 미측정 포함");f.unknown.setChecked(unknown);parent.addView(f.unknown);
        return f;
    }
    private Map<String,Object> checkedFeed(FeedInputs f){
        String[] values={f.breast.getText().toString().trim(),f.pumped.getText().toString().trim(),f.formula.getText().toString().trim()};
        int[] amounts=new int[3];int total=0;
        for(int i=0;i<3;i++){try{amounts[i]=Integer.parseInt(values[i]);}catch(Exception ex){throw new IllegalArgumentException("각 용량에 숫자를 입력하세요.");}
            if(amounts[i]<0||amounts[i]>1000||amounts[i]%5!=0)throw new IllegalArgumentException("수유량은 0~1000mL, 5mL 단위로 입력하세요.");
            total+=amounts[i];}
        if(total>1000||(total==0&&!f.unknown.isChecked()))throw new IllegalArgumentException("수유량 합계는 1000mL 이하로, 5mL 단위로 입력하세요. 미측정만 기록할 수도 있어요.");
        Map<String,Object> data=new HashMap<>();data.put("feedType",FamilyStore.feedType(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));
        data.put("ml",total);data.put("size","");data.put("feedParts",FamilyStore.feedParts(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));return data;
    }
    private void chooseFeedTime(Map<String,Object> data){
        final int[] minutes={0};
        LinearLayout layout=col();layout.setPadding(dp(15),dp(8),dp(15),dp(5));
        layout.addView(text("언제 수유했나요? 현재 또는 이전 시간을 고르세요.",14,true));
        LinearLayout choices=row();Button now=button("현재 시간"),earlier=button("이전 시간");
        choices.addView(now,flex(50));choices.addView(earlier,flex(50));layout.addView(choices);
        TextView selection=text("",15,true);selection.setGravity(Gravity.CENTER);layout.addView(selection,margin(-1,46,7,3));
        LinearLayout adjustment=row();Button minus=button("−5분");
        TextView accumulated=text("누적 0분 전",16,true);accumulated.setGravity(Gravity.CENTER);
        accumulated.setBackground(bg(0xFFFFEFBA));accumulated.setTextColor(darkMode?0xFFFFEFD1:0xFF163046);
        adjustment.addView(minus,flex(46));adjustment.addView(accumulated,flex(46));layout.addView(adjustment);
        SimpleDateFormat fmt=new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA);
        Runnable refresh=()->{
            selection.setText("기록할 시각: "+fmt.format(new Date(System.currentTimeMillis()-minutes[0]*60000L))
                +(minutes[0]==0?" · 현재":" · "+minutes[0]+"분 전"));
            accumulated.setText("누적 "+minutes[0]+"분 전");
        };
        now.setOnClickListener(v->{minutes[0]=0;refresh.run();});
        earlier.setOnClickListener(v->{if(minutes[0]==0)minutes[0]=5;refresh.run();});
        minus.setOnClickListener(v->{minutes[0]=Math.min(1440,minutes[0]+5);refresh.run();});
        refresh.run();
        new AlertDialog.Builder(this).setTitle("🍼 마지막 단계 · 수유 시간")
            .setView(layout).setNegativeButton("취소",null)
            .setPositiveButton("이 시간으로 기록",(dialog,which)->{
                Map<?,?> p=(Map<?,?>)data.get("feedParts");
                long at=System.currentTimeMillis()-minutes[0]*60000L;
                RecordWorker.queueParts(this,FamilyStore.number(p.get("breastMl")),FamilyStore.number(p.get("pumpedMl")),
                    FamilyStore.number(p.get("formulaMl")),Boolean.TRUE.equals(p.get("breastUnmeasured")),at);
                Toast.makeText(this,"수유 시간 저장 · 가족에게 전송 대기 중",Toast.LENGTH_SHORT).show();
            }).show();
    }
    /** New feeds distinguish direct breastfeeding from pumped milk + formula mixing. */
    private void showFeedSettings(){
        LinearLayout pane=col();pane.setPadding(dp(16),dp(7),dp(16),dp(2));
        pane.addView(text("각 수유 종류의 기본 용량",16,true));
        pane.addView(text("유축·분유 각각 5mL 단위 · 이 기기에만 저장 · 기존 기록 유지",12,false));
        pane.addView(text("🌙 화면 모드",15,true),margin(-1,-2,15,5));
        RadioGroup modes=new RadioGroup(this);modes.setOrientation(RadioGroup.VERTICAL);
        String[] themeValues={"system","light","dark"};
        String[] themeLabels={"시스템 설정 따르기","라이트 모드","다크 모드"};
        RadioButton[] themeChoices=new RadioButton[3];
        String currentTheme=FamilyStore.prefs(this).getString(THEME_PREF,"system");
        for(int i=0;i<themeValues.length;i++){
            RadioButton option=new RadioButton(this);option.setText(themeLabels[i]);option.setTextColor(INK);
            option.setId(View.generateViewId());option.setChecked(themeValues[i].equals(currentTheme));
            themeChoices[i]=option;modes.addView(option);
        }
        pane.addView(modes,margin(-1,-2,2,7));
        pane.addView(text("화면 설정은 이 기기에만 저장되며 가족 기록에는 영향이 없습니다.",12,false));
        final EditText[] fields=new EditText[2];
        final int[] initial={FamilyStore.defaultPumpedMl(this),FamilyStore.defaultFormulaMl(this)};
        final String[] labels={"유축", "분유"};
        for(int i=0;i<2;i++){
            pane.addView(text(labels[i]+" 기본값",14,true),margin(-1,-2,10,2));
            LinearLayout controls=row();
            Button minus=button("−5"),plus=button("+5");
            EditText input=new EditText(this);input.setSingleLine(true);
            input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setGravity(Gravity.CENTER);
            input.setTextSize(21);input.setText(String.valueOf(initial[i]));fields[i]=input;
            controls.addView(minus,flex(22));controls.addView(input,flex(56));controls.addView(plus,flex(22));
            pane.addView(controls,margin(-1,-2,5,5));
            minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(5,n-5)));});
            plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        }
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("⚙ 아기로그 설정")
            .setView(pane).setNegativeButton("취소",null).setPositiveButton("저장",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{
            int[] values=new int[2];
            for(int i=0;i<2;i++){
                String raw=fields[i].getText().toString().trim();
                try{values[i]=Integer.parseInt(raw);}catch(NumberFormatException e){values[i]=-1;}
                if(values[i]<5||values[i]>1000||values[i]%5!=0){
                    fields[i].setError("5~1000mL, 5mL 단위로 입력해 주세요.");return;
                }
            }
            String nextTheme="system";
            for(int i=0;i<themeChoices.length;i++)if(themeChoices[i].isChecked())nextTheme=themeValues[i];
            String oldTheme=FamilyStore.prefs(this).getString(THEME_PREF,"system");
            FamilyStore.setDefaultVolumes(this,values[0],values[1]);
            FamilyStore.prefs(this).edit().putString(THEME_PREF,nextTheme).apply();
            QuickNotification.reset(this);QuickNotification.show(this);
            HomeWidgetProvider.updateAll(this);
            dialog.dismiss();
            if(!oldTheme.equals(nextTheme))recreate();
            else Toast.makeText(this,"설정 저장 완료",Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }
    private void pickFeed(){
        new AlertDialog.Builder(this).setTitle("🍼 수유 종류")
            .setItems(new String[]{"모유수유","유축","분유","혼합 (유축 + 분유)"},
                (dialog,which)->pickFeedOfType(which)).show();
    }
    private void pickFeedOfType(int choice){
        ScrollView scroll=new ScrollView(this);LinearLayout root=col();
        root.setPadding(dp(17),dp(10),dp(17),dp(10));scroll.addView(root);
        EditText breast=null,pumped=null,formula=null;CheckBox unknown=null;
        if(choice==0){
            breast=amountLine(root,"모유",0);
            unknown=new CheckBox(this);unknown.setText("모유수유 양 미측정");unknown.setChecked(true);root.addView(unknown);
        }else if(choice==1){pumped=amountLine(root,"유축",FamilyStore.defaultPumpedMl(this));
        }else if(choice==2){formula=amountLine(root,"분유",FamilyStore.defaultFormulaMl(this));
        }else{
            root.addView(text("혼합은 유축 + 분유만 기록합니다. 각각 5mL 이상 입력해 주세요.",13,true));
            pumped=amountLine(root,"유축",FamilyStore.defaultPumpedMl(this));formula=amountLine(root,"분유",FamilyStore.defaultFormulaMl(this));
        }
        final EditText bInput=breast,pInput=pumped,fInput=formula;final CheckBox unknownBox=unknown;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🍼 수유 기록 · 5mL 단위")
            .setView(scroll).setNegativeButton("취소",null).setPositiveButton("다음: 시간 선택",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int b=bInput==null?0:parseAmount(bInput);
            int p=pInput==null?0:parseAmount(pInput);
            int f=fInput==null?0:parseAmount(fInput);
            boolean isUnknown=unknownBox!=null&&unknownBox.isChecked();
            if(isUnknown)b=0; // Unmeasured direct breastfeeding cannot have a numeric amount.
            int total=b+p+f;
            if(b<0||p<0||f<0||b%5!=0||p%5!=0||f%5!=0||total>1000){
                Toast.makeText(this,"수유량은 합계 1000mL 이하, 5mL 단위로 입력하세요.",Toast.LENGTH_LONG).show();return;
            }
            if(choice==3&&(p<5||f<5)){
                Toast.makeText(this,"혼합은 유축과 분유를 각각 5mL 이상 입력해야 합니다.",Toast.LENGTH_LONG).show();return;
            }
            if(choice!=3&&total==0&&!isUnknown){
                Toast.makeText(this,"수유량을 입력하거나 모유 양 미측정을 선택하세요.",Toast.LENGTH_LONG).show();return;
            }
            Map<String,Object> data=new HashMap<>();
            data.put("feedType",FamilyStore.feedType(b,p,f,isUnknown));data.put("ml",total);data.put("size","");
            data.put("feedParts",FamilyStore.feedParts(b,p,f,isUnknown));
            dialog.dismiss();chooseFeedTime(data);
        }));dialog.show();
    }
    private Spinner spinner(String[] items,int selected){
        Spinner result=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        result.setAdapter(adapter);result.setSelection(selected);return result;
    }
    private int indexOf(String[] values,String value,int fallback){for(int i=0;i<values.length;i++)if(values[i].equals(value))return i;return fallback;}
    private void editRecord(DocumentSnapshot snap){
        Map<String,Object> item=snap.getData();if(item==null)return;
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH,FamilyStore.PUMP};
        String[] types={FamilyStore.BREAST,FamilyStore.PUMPED,FamilyStore.FORMULA};
        String[] sizes={FamilyStore.SMALL,FamilyStore.MEDIUM,FamilyStore.LARGE};
        Calendar when=Calendar.getInstance();Date old=snap.getDate("at");if(old!=null)when.setTime(old);
        ScrollView scroll=new ScrollView(this);LinearLayout form=col();form.setPadding(dp(18),dp(8),dp(18),dp(8));scroll.addView(form);
        form.addView(text("기록 종류",14,true));Spinner kind=spinner(new String[]{"수유","소변","대변","소+대변","유축 시작"},indexOf(kinds,snap.getString("kind"),0));form.addView(kind);
        form.addView(text("기록 날짜·시간",14,true),margin(-1,-2,12,3));
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA);
        Button time=button(fmt.format(when.getTime()));form.addView(time,margin(-1,49,3,10));
        time.setOnClickListener(v->new DatePickerDialog(this,(view,y,m,d)->{
            when.set(y,m,d);
            new TimePickerDialog(this,(t,h,min)->{when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,min);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);time.setText(fmt.format(when.getTime()));},when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show();
        },when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show());
        LinearLayout feedBox=col();FeedInputs feed=feedInputs(feedBox,item,FamilyStore.FEED.equals(snap.getString("kind")));form.addView(feedBox);
        LinearLayout diaperBox=col();diaperBox.addView(text("기저귀 양 (소+대변은 같은 양 적용)",13,true));
        Spinner size=spinner(new String[]{"소","중","대"},indexOf(sizes,snap.getString("size"),1));diaperBox.addView(size);form.addView(diaperBox);
        LinearLayout pumpBox=col();pumpBox.addView(text("유축한 양 (mL) · 아직 모르면 0",13,true));
        EditText pumpInput=amountLine(pumpBox,"유축량",FamilyStore.PUMP.equals(snap.getString("kind"))?FamilyStore.number(item.get("ml")):0);
        form.addView(pumpBox);
        kind.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id){boolean feed=position==0,pump=position==4;
                feedBox.setVisibility(feed?View.VISIBLE:View.GONE);pumpBox.setVisibility(pump?View.VISIBLE:View.GONE);
                diaperBox.setVisibility(!feed&&!pump?View.VISIBLE:View.GONE);}
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("시간·양 수정").setView(scroll)
            .setNegativeButton("취소",null).setPositiveButton("수정 저장",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long timeMs=when.getTimeInMillis();Calendar first=Calendar.getInstance();first.set(2020,0,1,0,0,0);
            if(timeMs<first.getTimeInMillis()||timeMs>System.currentTimeMillis()+300000L){Toast.makeText(this,"시간은 2020년부터 현재까지 입력하세요.",Toast.LENGTH_LONG).show();return;}
            String k=kinds[kind.getSelectedItemPosition()];Map<String,Object> changes=new HashMap<>();
            changes.put("kind",k);changes.put("at",new Timestamp(new Date(timeMs)));changes.put("legacy",false);
            if(FamilyStore.FEED.equals(k)){
                try{changes.putAll(checkedFeed(feed));}
                catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            }else if(FamilyStore.PUMP.equals(k)){
                String raw=pumpInput.getText().toString().trim();int ml;
                try{ml=Integer.parseInt(raw);}catch(NumberFormatException e){pumpInput.setError("0~1000mL를 입력하세요");return;}
                if(ml<0||ml>1000||ml%5!=0){pumpInput.setError("0~1000mL · 5mL 단위");return;}
                changes.put("feedType","");changes.put("ml",ml);changes.put("size","");changes.put("feedParts",FieldValue.delete());
            }else{
                changes.put("feedType","");changes.put("ml",0);changes.put("size",sizes[size.getSelectedItemPosition()]);
                changes.put("feedParts",FieldValue.delete());
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            snap.getReference().update(changes).addOnSuccessListener(ok->{Toast.makeText(this,"수정 완료 · 가족에게 반영됩니다.",Toast.LENGTH_SHORT).show();dialog.dismiss();})
                .addOnFailureListener(err->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);fail("수정 실패: "+err.getMessage());});
        }));
        dialog.show();
    }
    private void openFeedFromWidgetIfRequested(){
        Intent intent=getIntent();
        if(intent!=null&&"ready".equals(state)&&intent.getBooleanExtra("open_feed_from_widget",false)){
            intent.removeExtra("open_feed_from_widget");
            pickFeed();
        }
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        openFeedFromWidgetIfRequested();
    }
    private void toggle(){if(QuickNotification.enabled(this)){QuickNotification.enabled(this,false);draw();return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);return;}
        QuickNotification.enabled(this,true);draw();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);
        if(request==99){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)QuickNotification.enabled(this,true);
            else Toast.makeText(this,"알림 권한이 필요합니다",Toast.LENGTH_LONG).show();draw();}}
}
