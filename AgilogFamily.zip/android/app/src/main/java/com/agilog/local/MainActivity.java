package com.agilog.local;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.view.View;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private final int BACK=0xFFFFF9F6,INK=0xFF644B56,MUTED=0xFF9F8993,BLUSH=0xFFF6E0E8;
    private final ArrayList<DocumentSnapshot> events=new ArrayList<>();
    private ListenerRegistration listener;
    private String state="loading";
    private String status="가족 연결 준비 중...";
    private TextView dailyFeed, dailyPoop, dailyPee, lastFeed, lastPoop, lastPee, unknownNote;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable elapsedTick=new Runnable(){@Override public void run(){if("ready".equals(state))updateSummary();timer.postDelayed(this,60000L);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);draw();
        if(FirebaseAuth.getInstance().getCurrentUser()!=null)afterAuth();
        else FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(a->afterAuth()).addOnFailureListener(e->fail("로그인 실패: "+e.getMessage()));
    }
    @Override protected void onResume(){super.onResume();timer.removeCallbacks(elapsedTick);timer.post(elapsedTick);if(QuickNotification.enabled(this))QuickNotification.show(this);}
    @Override protected void onPause(){timer.removeCallbacks(elapsedTick);super.onPause();}
    @Override protected void onDestroy(){timer.removeCallbacks(elapsedTick);if(listener!=null)listener.remove();super.onDestroy();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(3),dp(top),dp(3),dp(bottom));return p;}
    private LinearLayout.LayoutParams flex(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1f);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private TextView text(String val,int size,boolean bold){TextView t=new TextView(this);t.setText(val);t.setTextSize(size);t.setTextColor(INK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String title){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextSize(14);b.setTextColor(INK);b.setBackground(bg(BLUSH));return b;}
    private LinearLayout card(){LinearLayout l=col();l.setPadding(dp(17),dp(18),dp(17),dp(18));l.setBackground(bg(Color.WHITE));return l;}
    private void fail(String message){status=message;Toast.makeText(this,message,Toast.LENGTH_LONG).show();draw();}
    private void afterAuth(){String code=FamilyStore.code(this);
        if(!code.isEmpty()){
            FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid())
                .get().addOnSuccessListener(d->{if(d.exists())connected();else{state="connect";draw();}})
                .addOnFailureListener(e->{state="connect";fail("가족 확인 실패: "+e.getMessage());});
        }else{state="connect";draw();}
    }
    private void connect(boolean create,String name,String code){
        name=name.trim();code=code.trim().toUpperCase().replaceAll("[\\s-]","");
        if(name.isEmpty()||name.length()>40){fail("이름은 1~40자로 입력해 주세요.");return;}
        if(create)code=FamilyStore.randomCode();
        if(!FamilyStore.validCode(code)){fail("가족 코드를 20자리로 입력해 주세요.");return;}
        final String family=code,who=name;
        status="가족 연결 중...";draw();
        if(create){Map<String,Object> familyData=new HashMap<>();familyData.put("createdBy",FamilyStore.uid());familyData.put("createdAt",FieldValue.serverTimestamp());
            FamilyStore.db().collection("families").document(family).set(familyData)
                .addOnSuccessListener(v->addMember(family,who))
                .addOnFailureListener(e->{state="connect";fail("가족 만들기 실패: "+e.getMessage());});
        }else addMember(family,who);
    }
    private void addMember(String code,String who){
        Map<String,Object> member=new HashMap<>();member.put("name",who);member.put("joinedAt",FieldValue.serverTimestamp());
        var ref=FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid());
        ref.set(member).addOnSuccessListener(v->{FamilyStore.setFamily(this,code,who);connected();})
           .addOnFailureListener(e->ref.get().addOnSuccessListener(existing->{
               if(existing.exists()){FamilyStore.setFamily(this,code,who);connected();}
               else{state="connect";fail("가족 코드를 확인해 주세요: "+e.getMessage());}
           }).addOnFailureListener(e2->{state="connect";fail("가입 실패: "+e.getMessage());}));
    }
    private void connected(){state="ready";status="가족 실시간 공유 연결됨";draw();
        QuickNotification.show(this);
        if(listener!=null)listener.remove();
        listener=FamilyStore.db().collection("families").document(FamilyStore.code(this)).collection("events")
            .orderBy("at", Query.Direction.DESCENDING)
            .addSnapshotListener((snap,error)->{
                if(error!=null){status="기록 불러오기 오류: "+error.getMessage();draw();return;}
                events.clear();if(snap!=null)events.addAll(snap.getDocuments());draw();
            });
    }
    private void draw(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BACK);
        LinearLayout root=col();root.setPadding(dp(15),dp(27),dp(15),dp(50));scroll.addView(root);setContentView(scroll);
        root.addView(text("우리 아이 하루를 함께",12,false));root.addView(text("아기로그 가족 🍼",28,true),margin(-1,-2,3,8));
        TextView message=text(status,12,false);message.setTextColor(MUTED);root.addView(message,margin(-1,-2,0,18));
        if("loading".equals(state))return;
        if("connect".equals(state)){
            LinearLayout c=card();c.addView(text("가족 코드로 연결하기",20,true),margin(-1,-2,0,10));
            EditText name=new EditText(this);name.setSingleLine(true);name.setHint("이름: 엄마, 아빠 등");name.setText(FamilyStore.name(this));c.addView(name);
            Button create=button("새 가족 만들기");create.setOnClickListener(v->connect(true,name.getText().toString(),""));c.addView(create,margin(-1,50,8,15));
            EditText code=new EditText(this);code.setSingleLine(true);code.setHint("가족 초대 코드 20자리");c.addView(code);
            Button join=button("가족 코드로 참여하기");join.setOnClickListener(v->connect(false,name.getText().toString(),code.getText().toString()));c.addView(join,margin(-1,50,8,0));
            root.addView(c);return;
        }
        LinearLayout info=card();info.addView(text("👨‍👩‍👧 가족 초대 코드",17,true));
        TextView code=text(FamilyStore.code(this),17,true);code.setTextIsSelectable(true);info.addView(code,margin(-1,-2,8,4));
        Button share=button("초대 코드 공유");share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"아기로그 가족 코드: "+FamilyStore.code(this));startActivity(Intent.createChooser(i,"가족에게 보내기"));});
        info.addView(share,margin(-1,44,5,0));root.addView(info,margin(-1,-2,0,17));
        LinearLayout summary=card();summary.addView(text("오늘의 누적 기록",18,true));LinearLayout counts=row();
        dailyFeed=summaryTile(counts,"🍼 수유량", "0mL · 0회");
        dailyPoop=summaryTile(counts,"💩 대변", "0회");
        dailyPee=summaryTile(counts,"💧 소변", "0회");
        summary.addView(counts);
        unknownNote=text("※ 직접 모유 수유 양 미측정은 총 수유량에서 제외됩니다.",11,false);
        summary.addView(unknownNote,margin(-1,-2,8,0));
        summary.addView(text("마지막 기록으로부터",15,true),margin(-1,-2,16,5));
        LinearLayout times=row();
        lastFeed=summaryTile(times,"🍼 수유", "기록 없음");
        lastPoop=summaryTile(times,"💩 대변", "기록 없음");
        lastPee=summaryTile(times,"💧 소변", "기록 없음");
        summary.addView(times);root.addView(summary,margin(-1,-2,0,20));updateSummary();
        root.addView(text("빠른 기록 +",20,true),margin(-1,-2,0,6));
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH};
        for(int j=0;j<2;j++){
            LinearLayout actions=row();
            for(int i=j*2;i<j*2+2;i++){
                String kind=kinds[i];Button b=button(FamilyStore.icon(kind)+"\n"+FamilyStore.kindLabel(kind));
                b.setOnClickListener(v->{if(FamilyStore.FEED.equals(kind))pickFeed();else pickDiaper(kind);});actions.addView(b,flex(72));
            }root.addView(actions,margin(-1,-2,0,4));
        }
        LinearLayout lock=card();lock.addView(text("🔒 잠금 화면 기록 (알림 1개)",17,true));
        lock.addView(text("수유·소변·대변·소+대변을 잠금 화면 알림에서 기록합니다. 수유 용량은 5mL 단위이며, 혼합 수유는 앱에서 입력합니다.",12,false),margin(-1,-2,7,12));
        Button enabled=button(QuickNotification.enabled(this)?"빠른 기록 끄기":"잠금 화면 빠른 기록 켜기");enabled.setOnClickListener(v->toggle());
        lock.addView(enabled,margin(-1,48,0,0));root.addView(lock,margin(-1,-2,0,18));
        root.addView(text("가족 최근 기록",19,true),margin(-1,-2,0,9));
        SimpleDateFormat fmt=new SimpleDateFormat("MM월 dd일 HH:mm",Locale.KOREAN);
        if(events.isEmpty())root.addView(text("아직 기록이 없어요 🌱",15,false));
        int shown=0;for(DocumentSnapshot snap:events){if(shown++>=100)break;Map<String,Object> map=snap.getData();if(map==null)continue;
            String kind=snap.getString("kind");Date time=snap.getDate("at");
            LinearLayout line=card();line.addView(text(FamilyStore.icon(kind)+" "+FamilyStore.kindLabel(kind)+" · "+fmt.format(time==null?new Date():time),15,true));
            TextView second=text(FamilyStore.detail(map)+" · "+snap.getString("who"),12,false);second.setTextColor(MUTED);line.addView(second,margin(-1,-2,5,0));
            line.setOnClickListener(v->editRecord(snap));
            TextView tap=text("눌러서 시간·양 수정",11,false);tap.setTextColor(0xFFBD8498);line.addView(tap,margin(-1,-2,4,0));
            if(FamilyStore.uid().equals(snap.getString("createdBy")))line.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("가족 기록에서 삭제할까요?")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->snap.getReference().delete().addOnFailureListener(e->fail(e.getMessage()))).show();return true;});
            root.addView(line,margin(-1,-2,0,8));
        }
        TextView note=text("기존 아기로그 앱은 삭제하지 마세요. 새 가족 앱의 기록부터 공유됩니다.",11,false);note.setTextColor(MUTED);root.addView(note,margin(-1,-2,18,0));
    }
    private long startToday(){java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private void record(String kind,String type,int ml,String size){RecordWorker.queue(this,kind,type,ml,size);Toast.makeText(this,"기록 전송 대기 중 · 연결되면 가족에게 표시돼요",Toast.LENGTH_SHORT).show();}
    private void pickDiaper(String kind){String[] labels={"소 · 적음","중 · 보통","대 · 많음"},sizes={"small","medium","large"};
        new AlertDialog.Builder(this).setTitle(FamilyStore.kindLabel(kind)+" 양").setItems(labels,(d,i)->record(kind,"",0,sizes[i])).show();}
    private TextView summaryTile(LinearLayout row,String title,String value){
        LinearLayout tile=col();tile.setPadding(dp(5),dp(12),dp(5),dp(12));tile.setBackground(bg(0xFFFFF0E7));
        TextView label=text(title,12,true);label.setGravity(Gravity.CENTER);tile.addView(label);
        TextView data=text(value,13,true);data.setGravity(Gravity.CENTER);tile.addView(data,margin(-1,-2,6,0));
        row.addView(tile,flex(78));return data;
    }
    private String since(Date date){
        if(date==null)return "기록 없음";
        long mins=Math.max(0,(System.currentTimeMillis()-date.getTime())/60000);
        if(mins<1)return "방금";if(mins<60)return mins+"분";
        long h=mins/60;if(h<24)return h+"시간 "+(mins%60)+"분";
        return (h/24)+"일 "+(h%24)+"시간";
    }
    private void updateSummary(){
        if(dailyFeed==null||dailyPoop==null||dailyPee==null)return;
        int total=0,feedCount=0,peeCount=0,poopCount=0;boolean unmeasured=false;
        Date lf=null,lp=null,lu=null;
        long day=startToday(),now=System.currentTimeMillis();
        for(DocumentSnapshot snap:events){Date date=snap.getDate("at");if(date==null)continue;
            String k=snap.getString("kind");if(k==null)continue;
            if(FamilyStore.FEED.equals(k)&& (lf==null||date.after(lf)))lf=date;
            if((FamilyStore.POOP.equals(k)||FamilyStore.BOTH.equals(k))&&(lp==null||date.after(lp)))lp=date;
            if((FamilyStore.PEE.equals(k)||FamilyStore.BOTH.equals(k))&&(lu==null||date.after(lu)))lu=date;
            if(date.getTime()<day||date.getTime()>now+300000)continue;
            if(FamilyStore.FEED.equals(k)){
                feedCount++;Map<String,Object> data=snap.getData();if(data!=null){total+=FamilyStore.knownMl(data);unmeasured|=FamilyStore.unknownBreast(data);}
            }
            if(FamilyStore.PEE.equals(k)||FamilyStore.BOTH.equals(k))peeCount++;
            if(FamilyStore.POOP.equals(k)||FamilyStore.BOTH.equals(k))poopCount++;
        }
        dailyFeed.setText(total+"mL · "+feedCount+"회");dailyPee.setText(peeCount+"회");dailyPoop.setText(poopCount+"회");
        if(unknownNote!=null)unknownNote.setVisibility(unmeasured?View.VISIBLE:View.GONE);
        if(lastFeed!=null)lastFeed.setText(since(lf));if(lastPoop!=null)lastPoop.setText(since(lp));if(lastPee!=null)lastPee.setText(since(lu));
    }
    private static class FeedInputs {
        EditText breast,pumped,formula;CheckBox unknown;
    }
    private EditText amountLine(LinearLayout parent,String label,int current){
        parent.addView(text(label+" (mL)",14,true),margin(-1,-2,9,0));
        LinearLayout line=row();EditText input=new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setSingleLine(true);
        input.setText(String.valueOf(current));input.setSelectAllOnFocus(true);
        Button minus=button("−5"),plus=button("+5");
        minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(0,n-5)));});
        plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        line.addView(minus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,dp(54),1);mid.setMargins(dp(8),0,dp(8),0);line.addView(input,mid);
        line.addView(plus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        parent.addView(line);return input;
    }
    private int parseAmount(EditText input){try{return Integer.parseInt(input.getText().toString().trim());}catch(Exception e){return 0;}}
    private FeedInputs feedInputs(LinearLayout parent,Map<String,Object> item,boolean isExisting){
        int breast=0,pumped=0,formula=isExisting?0:70;boolean unknown=false;
        if(isExisting&&item!=null){Object raw=item.get("feedParts");
            if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
                breast=FamilyStore.number(p.get("breastMl"));pumped=FamilyStore.number(p.get("pumpedMl"));
                formula=FamilyStore.number(p.get("formulaMl"));unknown=Boolean.TRUE.equals(p.get("breastUnmeasured"));
            }else{
                int ml=FamilyStore.number(item.get("ml"));String type=String.valueOf(item.get("feedType"));
                if(FamilyStore.BREAST.equals(type)){if(ml<0)unknown=true;else breast=ml;}
                else if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                else if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
            }
        }
        parent.addView(text("한 번에 모유 + 유축 + 분유 입력 가능 · 5mL 단위",12,false));
        FeedInputs f=new FeedInputs();f.breast=amountLine(parent,"모유",breast);
        f.pumped=amountLine(parent,"유축",pumped);f.formula=amountLine(parent,"분유",formula);
        f.unknown=new CheckBox(this);f.unknown.setText("직접 모유 수유 · 양 미측정 포함");f.unknown.setChecked(unknown);parent.addView(f.unknown);
        parent.addView(text("양 미측정 모유는 오늘의 총 수유량에 더하지 않습니다.",12,false));
        return f;
    }
    private Map<String,Object> checkedFeed(FeedInputs f){
        String[] values={f.breast.getText().toString().trim(),f.pumped.getText().toString().trim(),f.formula.getText().toString().trim()};
        int[] amounts=new int[3];int total=0;
        for(int i=0;i<3;i++){try{amounts[i]=Integer.parseInt(values[i]);}catch(Exception ex){throw new IllegalArgumentException("각 용량에 숫자를 입력하세요.");}
            if(amounts[i]<0||amounts[i]>1000||amounts[i]%5!=0)throw new IllegalArgumentException("수유량은 0~1000mL, 5mL 단위로 입력하세요.");
            total+=amounts[i];}
        if(total>1000||(total==0&&!f.unknown.isChecked()))throw new IllegalArgumentException("수유량 합계는 1000mL 이하로, 5mL 단위로 입력하세요. 미측정만 기록할 수도 있어요.");
        Map<String,Object> data=new HashMap<>();data.put("feedType",FamilyStore.feedType(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));
        data.put("ml",total);data.put("size","");data.put("feedParts",FamilyStore.feedParts(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));return data;
    }
    private void pickFeed(){
        ScrollView scroll=new ScrollView(this);LinearLayout root=col();root.setPadding(dp(17),dp(10),dp(17),dp(10));scroll.addView(root);
        FeedInputs inputs=feedInputs(root,null,false);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🍼 수유 기록 · 기본 70mL")
            .setView(scroll).setNegativeButton("취소",null).setPositiveButton("기록 저장",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            Map<String,Object> data;
            try{data=checkedFeed(inputs);}catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            Map<?,?> p=(Map<?,?>)data.get("feedParts");
            RecordWorker.queueParts(this,FamilyStore.number(p.get("breastMl")),FamilyStore.number(p.get("pumpedMl")),
                FamilyStore.number(p.get("formulaMl")),Boolean.TRUE.equals(p.get("breastUnmeasured")));
            Toast.makeText(this,"수유 기록 전송 대기 중",Toast.LENGTH_SHORT).show();dialog.dismiss();
        }));dialog.show();
    }
    private Spinner spinner(String[] items,int selected){
        Spinner result=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        result.setAdapter(adapter);result.setSelection(selected);return result;
    }
    private int indexOf(String[] values,String value,int fallback){for(int i=0;i<values.length;i++)if(values[i].equals(value))return i;return fallback;}
    private void editRecord(DocumentSnapshot snap){
        Map<String,Object> item=snap.getData();if(item==null)return;
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH};
        String[] types={FamilyStore.BREAST,FamilyStore.PUMPED,FamilyStore.FORMULA};
        String[] sizes={FamilyStore.SMALL,FamilyStore.MEDIUM,FamilyStore.LARGE};
        Calendar when=Calendar.getInstance();Date old=snap.getDate("at");if(old!=null)when.setTime(old);
        ScrollView scroll=new ScrollView(this);LinearLayout form=col();form.setPadding(dp(18),dp(8),dp(18),dp(8));scroll.addView(form);
        form.addView(text("기록 종류",14,true));Spinner kind=spinner(new String[]{"수유","소변","대변","소+대변"},indexOf(kinds,snap.getString("kind"),0));form.addView(kind);
        form.addView(text("기록 날짜·시간",14,true),margin(-1,-2,12,3));
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA);
        Button time=button(fmt.format(when.getTime()));form.addView(time,margin(-1,49,3,10));
        time.setOnClickListener(v->new DatePickerDialog(this,(view,y,m,d)->{
            when.set(y,m,d);
            new TimePickerDialog(this,(t,h,min)->{when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,min);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);time.setText(fmt.format(when.getTime()));},when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show();
        },when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show());
        LinearLayout feedBox=col();FeedInputs feed=feedInputs(feedBox,item,FamilyStore.FEED.equals(snap.getString("kind")));form.addView(feedBox);
        LinearLayout diaperBox=col();diaperBox.addView(text("기저귀 양 (소+대변은 같은 양 적용)",13,true));
        Spinner size=spinner(new String[]{"소","중","대"},indexOf(sizes,snap.getString("size"),1));diaperBox.addView(size);form.addView(diaperBox);
        kind.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id){boolean feed=position==0;feedBox.setVisibility(feed?View.VISIBLE:View.GONE);diaperBox.setVisibility(feed?View.GONE:View.VISIBLE);}
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("시간·양 수정").setView(scroll)
            .setNegativeButton("취소",null).setPositiveButton("수정 저장",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long timeMs=when.getTimeInMillis();Calendar first=Calendar.getInstance();first.set(2020,0,1,0,0,0);
            if(timeMs<first.getTimeInMillis()||timeMs>System.currentTimeMillis()+300000L){Toast.makeText(this,"시간은 2020년부터 현재까지 입력하세요.",Toast.LENGTH_LONG).show();return;}
            String k=kinds[kind.getSelectedItemPosition()];Map<String,Object> changes=new HashMap<>();
            changes.put("kind",k);changes.put("at",new Timestamp(new Date(timeMs)));changes.put("legacy",false);
            if(FamilyStore.FEED.equals(k)){
                try{changes.putAll(checkedFeed(feed));}
                catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            }else{
                changes.put("feedType","");changes.put("ml",0);changes.put("size",sizes[size.getSelectedItemPosition()]);
                changes.put("feedParts",FieldValue.delete());
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            snap.getReference().update(changes).addOnSuccessListener(ok->{Toast.makeText(this,"수정 완료 · 가족에게 반영됩니다.",Toast.LENGTH_SHORT).show();dialog.dismiss();})
                .addOnFailureListener(err->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);fail("수정 실패: "+err.getMessage());});
        }));
        dialog.show();
    }
    private void toggle(){if(QuickNotification.enabled(this)){QuickNotification.enabled(this,false);draw();return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);return;}
        QuickNotification.enabled(this,true);draw();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);
        if(request==99){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)QuickNotification.enabled(this,true);
            else Toast.makeText(this,"알림 권한이 필요합니다",Toast.LENGTH_LONG).show();draw();}}
}
