package com.agilog.local;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private final int BACK=0xFFFFF9F6,INK=0xFF644B56,MUTED=0xFF9F8993,BLUSH=0xFFF6E0E8;
    private final ArrayList<DocumentSnapshot> events=new ArrayList<>();
    private ListenerRegistration listener;
    private String state="loading";
    private String status="가족 연결 준비 중...";
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);draw();
        if(FirebaseAuth.getInstance().getCurrentUser()!=null)afterAuth();
        else FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(a->afterAuth()).addOnFailureListener(e->fail("로그인 실패: "+e.getMessage()));
    }
    @Override protected void onResume(){super.onResume();if(QuickNotification.enabled(this))QuickNotification.show(this);}
    @Override protected void onDestroy(){if(listener!=null)listener.remove();super.onDestroy();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(3),dp(top),dp(3),dp(bottom));return p;}
    private LinearLayout.LayoutParams flex(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1f);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private TextView text(String val,int size,boolean bold){TextView t=new TextView(this);t.setText(val);t.setTextSize(size);t.setTextColor(INK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String title){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextSize(14);b.setTextColor(INK);b.setBackground(bg(BLUSH));return b;}
    private LinearLayout card(){LinearLayout l=col();l.setPadding(dp(17),dp(18),dp(17),dp(18));l.setBackground(bg(Color.WHITE));return l;}
    private void fail(String message){status=message;Toast.makeText(this,message,Toast.LENGTH_LONG).show();draw();}
    private void afterAuth(){String code=FamilyStore.code(this);
        if(!code.isEmpty()){
            FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid())
                .get().addOnSuccessListener(d->{if(d.exists())connected();else{state="connect";draw();}})
                .addOnFailureListener(e->{state="connect";fail("가족 확인 실패: "+e.getMessage());});
        }else{state="connect";draw();}
    }
    private void connect(boolean create,String name,String code){
        name=name.trim();code=code.trim().toUpperCase().replaceAll("[\\s-]","");
        if(name.isEmpty()||name.length()>40){fail("이름은 1~40자로 입력해 주세요.");return;}
        if(create)code=FamilyStore.randomCode();
        if(!FamilyStore.validCode(code)){fail("가족 코드를 20자리로 입력해 주세요.");return;}
        final String family=code,who=name;
        status="가족 연결 중...";draw();
        if(create){Map<String,Object> familyData=new HashMap<>();familyData.put("createdBy",FamilyStore.uid());familyData.put("createdAt",FieldValue.serverTimestamp());
            FamilyStore.db().collection("families").document(family).set(familyData)
                .addOnSuccessListener(v->addMember(family,who))
                .addOnFailureListener(e->{state="connect";fail("가족 만들기 실패: "+e.getMessage());});
        }else addMember(family,who);
    }
    private void addMember(String code,String who){
        Map<String,Object> member=new HashMap<>();member.put("name",who);member.put("joinedAt",FieldValue.serverTimestamp());
        var ref=FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid());
        ref.set(member).addOnSuccessListener(v->{FamilyStore.setFamily(this,code,who);connected();})
           .addOnFailureListener(e->ref.get().addOnSuccessListener(existing->{
               if(existing.exists()){FamilyStore.setFamily(this,code,who);connected();}
               else{state="connect";fail("가족 코드를 확인해 주세요: "+e.getMessage());}
           }).addOnFailureListener(e2->{state="connect";fail("가입 실패: "+e.getMessage());}));
    }
    private void connected(){state="ready";status="가족 실시간 공유 연결됨";draw();
        QuickNotification.show(this);
        if(listener!=null)listener.remove();
        listener=FamilyStore.db().collection("families").document(FamilyStore.code(this)).collection("events")
            .orderBy("at", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener((snap,error)->{
                if(error!=null){status="기록 불러오기 오류: "+error.getMessage();draw();return;}
                events.clear();if(snap!=null)events.addAll(snap.getDocuments());draw();
            });
    }
    private void draw(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BACK);
        LinearLayout root=col();root.setPadding(dp(15),dp(27),dp(15),dp(50));scroll.addView(root);setContentView(scroll);
        root.addView(text("우리 아이 하루를 함께",12,false));root.addView(text("아기로그 가족 🍼",28,true),margin(-1,-2,3,8));
        TextView message=text(status,12,false);message.setTextColor(MUTED);root.addView(message,margin(-1,-2,0,18));
        if("loading".equals(state))return;
        if("connect".equals(state)){
            LinearLayout c=card();c.addView(text("가족 코드로 연결하기",20,true),margin(-1,-2,0,10));
            EditText name=new EditText(this);name.setSingleLine(true);name.setHint("이름: 엄마, 아빠 등");name.setText(FamilyStore.name(this));c.addView(name);
            Button create=button("새 가족 만들기");create.setOnClickListener(v->connect(true,name.getText().toString(),""));c.addView(create,margin(-1,50,8,15));
            EditText code=new EditText(this);code.setSingleLine(true);code.setHint("가족 초대 코드 20자리");c.addView(code);
            Button join=button("가족 코드로 참여하기");join.setOnClickListener(v->connect(false,name.getText().toString(),code.getText().toString()));c.addView(join,margin(-1,50,8,0));
            root.addView(c);return;
        }
        LinearLayout info=card();info.addView(text("👨‍👩‍👧 가족 초대 코드",17,true));
        TextView code=text(FamilyStore.code(this),17,true);code.setTextIsSelectable(true);info.addView(code,margin(-1,-2,8,4));
        Button share=button("초대 코드 공유");share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"아기로그 가족 코드: "+FamilyStore.code(this));startActivity(Intent.createChooser(i,"가족에게 보내기"));});
        info.addView(share,margin(-1,44,5,0));root.addView(info,margin(-1,-2,0,17));
        LinearLayout summary=card();summary.addView(text("오늘의 기록",18,true));LinearLayout counts=row();
        for(String kind:new String[]{FamilyStore.FEED,FamilyStore.POOP,FamilyStore.PEE}){
            int n=0;long today=startToday();for(DocumentSnapshot e:events){Date d=e.getDate("at");if(kind.equals(e.getString("kind"))&&d!=null&&d.getTime()>=today)n++;}
            TextView item=text(FamilyStore.icon(kind)+"\n"+n+"회\n"+FamilyStore.kindLabel(kind),15,true);item.setGravity(Gravity.CENTER);item.setBackground(bg(0xFFFFF0E7));counts.addView(item,flex(105));
        }summary.addView(counts);root.addView(summary,margin(-1,-2,0,20));
        root.addView(text("빠른 기록 +",20,true),margin(-1,-2,0,6));LinearLayout actions=row();
        for(String kind:new String[]{FamilyStore.FEED,FamilyStore.POOP,FamilyStore.PEE}){
            Button b=button(FamilyStore.icon(kind)+"\n"+FamilyStore.kindLabel(kind));
            b.setOnClickListener(v->{if(FamilyStore.FEED.equals(kind))pickFeed();else pickDiaper(kind);});actions.addView(b,flex(100));
        }root.addView(actions,margin(-1,-2,0,20));
        LinearLayout lock=card();lock.addView(text("🔒 잠금 화면 기록 (알림 1개)",17,true));
        lock.addView(text("수유·대변·소변이 한 알림에 보이고, 선택한 뒤 수유량도 알림에서 기록할 수 있습니다.",12,false),margin(-1,-2,7,12));
        Button enabled=button(QuickNotification.enabled(this)?"빠른 기록 끄기":"잠금 화면 빠른 기록 켜기");enabled.setOnClickListener(v->toggle());
        lock.addView(enabled,margin(-1,48,0,0));root.addView(lock,margin(-1,-2,0,18));
        root.addView(text("가족 최근 기록",19,true),margin(-1,-2,0,9));
        SimpleDateFormat fmt=new SimpleDateFormat("MM월 dd일 HH:mm",Locale.KOREAN);
        if(events.isEmpty())root.addView(text("아직 기록이 없어요 🌱",15,false));
        for(DocumentSnapshot snap:events){Map<String,Object> map=snap.getData();if(map==null)continue;
            String kind=snap.getString("kind");Date time=snap.getDate("at");
            LinearLayout line=card();line.addView(text(FamilyStore.icon(kind)+" "+FamilyStore.kindLabel(kind)+" · "+fmt.format(time==null?new Date():time),15,true));
            TextView second=text(FamilyStore.detail(map)+" · "+snap.getString("who"),12,false);second.setTextColor(MUTED);line.addView(second,margin(-1,-2,5,0));
            if(FamilyStore.uid().equals(snap.getString("createdBy")))line.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("가족 기록에서 삭제할까요?")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->snap.getReference().delete().addOnFailureListener(e->fail(e.getMessage()))).show();return true;});
            root.addView(line,margin(-1,-2,0,8));
        }
        TextView note=text("기존 아기로그 앱은 삭제하지 마세요. 새 가족 앱의 기록부터 공유됩니다.",11,false);note.setTextColor(MUTED);root.addView(note,margin(-1,-2,18,0));
    }
    private long startToday(){java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private void record(String kind,String type,int ml,String size){RecordWorker.queue(this,kind,type,ml,size);Toast.makeText(this,"기록 전송 대기 중 · 연결되면 가족에게 표시돼요",Toast.LENGTH_SHORT).show();}
    private void pickDiaper(String kind){String[] labels={"소 · 적음","중 · 보통","대 · 많음"},sizes={"small","medium","large"};
        new AlertDialog.Builder(this).setTitle(FamilyStore.kindLabel(kind)+" 양").setItems(labels,(d,i)->record(kind,"",0,sizes[i])).show();}
    private void pickFeed(){String[] labels={"모유 직접 수유","유축 수유","분유 수유"},types={"breast","pumped","formula"};
        new AlertDialog.Builder(this).setTitle("수유 종류").setItems(labels,(d,i)->pickMl(types[i],30)).show();}
    private void pickMl(String type,int start){
        ScrollView scroll=new ScrollView(this);LinearLayout layout=col();layout.setPadding(dp(10),dp(12),dp(10),dp(12));scroll.addView(layout);
        layout.addView(text(FamilyStore.typeLabel(type)+" · 양 선택",18,true));
        if(FamilyStore.BREAST.equals(type)){Button none=button("직접 수유 · 양 미측정");none.setOnClickListener(v->record(FamilyStore.FEED,type,-1,""));layout.addView(none,margin(-1,51,9,11));}
        int end=Math.min(1000,start+170);for(int ml=start;ml<=end;ml+=30){LinearLayout row=row();for(int x=0;x<3;x++){
            int qty=ml+x*10;if(qty>end)continue;Button b=button(qty+"mL");b.setOnClickListener(v->record(FamilyStore.FEED,type,qty,""));row.addView(b,flex(49));}
            layout.addView(row);
        }
        if(end<1000){Button more=button("더 큰 용량 보기 ▶");more.setOnClickListener(v->pickMl(type,end+10));layout.addView(more,margin(-1,48,12,0));}
        new AlertDialog.Builder(this).setView(scroll).setNegativeButton("닫기",null).show();
    }
    private void toggle(){if(QuickNotification.enabled(this)){QuickNotification.enabled(this,false);draw();return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);return;}
        QuickNotification.enabled(this,true);draw();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);
        if(request==99){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)QuickNotification.enabled(this,true);
            else Toast.makeText(this,"알림 권한이 필요합니다",Toast.LENGTH_LONG).show();draw();}}
}
