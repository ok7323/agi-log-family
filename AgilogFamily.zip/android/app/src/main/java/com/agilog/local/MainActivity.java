package com.agilog.local;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.view.View;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private final int BACK=0xFFFFF9F6,INK=0xFF644B56,MUTED=0xFF9F8993,BLUSH=0xFFF6E0E8;
    private final ArrayList<DocumentSnapshot> events=new ArrayList<>();
    private ListenerRegistration listener;
    private static volatile boolean foregroundActive=false;
    static boolean isForeground(){return foregroundActive;}
    private String state="loading";
    private String status="가족 연결 준비 중...";
    private TextView dailyFeed, dailyPoop, dailyPee, lastFeed, lastFeedAmount, previousFeed, previousFeedAmount, lastPoop, lastPee, yesterdayFeed;
    private TextView todayBreast, todayPumped, todayFormula;
    private TextView yesterdayBreast, yesterdayPumped, yesterdayFormula, yesterdayPoop, yesterdayPee;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable elapsedTick=new Runnable(){@Override public void run(){if("ready".equals(state))updateSummary();timer.postDelayed(this,60000L);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);draw();
        if(FirebaseAuth.getInstance().getCurrentUser()!=null)afterAuth();
        else FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(a->afterAuth()).addOnFailureListener(e->fail("로그인 실패: "+e.getMessage()));
    }
    @Override protected void onResume(){
        super.onResume();
        foregroundActive=true;
        timer.removeCallbacks(elapsedTick);
        timer.post(elapsedTick); // Foreground-only minute update; never runs when paused.
        startForegroundListener();
        if(QuickNotification.enabled(this))QuickNotification.show(this);
        openFeedFromWidgetIfRequested();
    }
    @Override protected void onPause(){
        foregroundActive=false;
        timer.removeCallbacks(elapsedTick);
        stopForegroundListener(); // No Firestore live stream while screen/app is inactive.
        super.onPause();
    }
    @Override protected void onDestroy(){
        timer.removeCallbacks(elapsedTick);
        stopForegroundListener();
        super.onDestroy();
    }
    private void stopForegroundListener(){
        if(listener!=null){listener.remove();listener=null;}
    }
    private void startForegroundListener(){
        if(!foregroundActive||listener!=null||!"ready".equals(state)||FamilyStore.code(this).isEmpty())return;
        listener=FamilyStore.db().collection("families").document(FamilyStore.code(this)).collection("events")
            .orderBy("at", Query.Direction.DESCENDING)
            .addSnapshotListener((snap,error)->{
                if(!foregroundActive)return;
                if(error!=null){status="기록 불러오기 오류: "+error.getMessage();draw();return;}
                events.clear();
                if(snap!=null){events.addAll(snap.getDocuments());QuickStats.update(this,snap.getDocuments());}
                draw();
                QuickNotification.show(this);
                HomeWidgetProvider.updateAll(this);
            });
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(3),dp(top),dp(3),dp(bottom));return p;}
    private LinearLayout.LayoutParams flex(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1f);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private TextView text(String val,int size,boolean bold){TextView t=new TextView(this);t.setText(val);t.setTextSize(size);t.setTextColor(INK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String title){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextSize(14);b.setTextColor(INK);b.setBackground(bg(BLUSH));return b;}
    private LinearLayout card(){LinearLayout l=col();l.setPadding(dp(17),dp(18),dp(17),dp(18));l.setBackground(bg(Color.WHITE));return l;}
    private void fail(String message){status=message;Toast.makeText(this,message,Toast.LENGTH_LONG).show();draw();}
    private void afterAuth(){String code=FamilyStore.code(this);
        if(!code.isEmpty()){
            FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid())
                .get().addOnSuccessListener(d->{if(d.exists())connected();else{state="connect";draw();}})
                .addOnFailureListener(e->{state="connect";fail("가족 확인 실패: "+e.getMessage());});
        }else{state="connect";draw();}
    }
    private void connect(boolean create,String name,String code){
        name=name.trim();code=code.trim().toUpperCase().replaceAll("[\\s-]","");
        if(name.isEmpty()||name.length()>40){fail("이름은 1~40자로 입력해 주세요.");return;}
        if(create)code=FamilyStore.randomCode();
        if(!FamilyStore.validCode(code)){fail("가족 코드를 20자리로 입력해 주세요.");return;}
        final String family=code,who=name;
        status="가족 연결 중...";draw();
        if(create){Map<String,Object> familyData=new HashMap<>();familyData.put("createdBy",FamilyStore.uid());familyData.put("createdAt",FieldValue.serverTimestamp());
            FamilyStore.db().collection("families").document(family).set(familyData)
                .addOnSuccessListener(v->addMember(family,who))
                .addOnFailureListener(e->{state="connect";fail("가족 만들기 실패: "+e.getMessage());});
        }else addMember(family,who);
    }
    private void addMember(String code,String who){
        Map<String,Object> member=new HashMap<>();member.put("name",who);member.put("joinedAt",FieldValue.serverTimestamp());
        var ref=FamilyStore.db().collection("families").document(code).collection("members").document(FamilyStore.uid());
        ref.set(member).addOnSuccessListener(v->{FamilyStore.setFamily(this,code,who);connected();})
           .addOnFailureListener(e->ref.get().addOnSuccessListener(existing->{
               if(existing.exists()){FamilyStore.setFamily(this,code,who);connected();}
               else{state="connect";fail("가족 코드를 확인해 주세요: "+e.getMessage());}
           }).addOnFailureListener(e2->{state="connect";fail("가입 실패: "+e.getMessage());}));
    }
    private void connected(){state="ready";status="";draw();
        if(QuickNotification.enabled(this)||HomeWidgetProvider.hasWidgets(this)){
            QuickStatsWorker.schedule(this);
            if(!foregroundActive)QuickStatsWorker.request(this); // The foreground listener already gets fresh data.
        }
        QuickNotification.show(this);
        HomeWidgetProvider.updateAll(this);
        openFeedFromWidgetIfRequested();
        stopForegroundListener();
        startForegroundListener();
    }
    private void draw(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BACK);
        LinearLayout root=col();root.setPadding(dp(15),dp(27),dp(15),dp(50));scroll.addView(root);setContentView(scroll);
        root.addView(text("우리 아이 하루를 함께",12,false));root.addView(text("아기로그 가족 🍼",28,true),margin(-1,-2,3,8));
        if(status!=null&&!status.isEmpty()){TextView message=text(status,12,false);message.setTextColor(MUTED);root.addView(message,margin(-1,-2,0,18));}
        if("loading".equals(state))return;
        if("connect".equals(state)){
            LinearLayout c=card();c.addView(text("가족 코드로 연결하기",20,true),margin(-1,-2,0,10));
            EditText name=new EditText(this);name.setSingleLine(true);name.setHint("이름: 엄마, 아빠 등");name.setText(FamilyStore.name(this));c.addView(name);
            Button create=button("새 가족 만들기");create.setOnClickListener(v->connect(true,name.getText().toString(),""));c.addView(create,margin(-1,50,8,15));
            EditText code=new EditText(this);code.setSingleLine(true);code.setHint("가족 초대 코드 20자리");c.addView(code);
            Button join=button("가족 코드로 참여하기");join.setOnClickListener(v->connect(false,name.getText().toString(),code.getText().toString()));c.addView(join,margin(-1,50,8,0));
            root.addView(c);return;
        }
        // Ordering: latest elapsed times -> quick record -> today -> yesterday -> history -> invitation.
        LinearLayout elapsed=card();elapsed.setPadding(dp(16),dp(12),dp(16),dp(11));elapsed.addView(text("마지막 기록으로부터",18,true));
        LinearLayout feedingTimes=row();
        TextView[] current=feedSummaryTile(feedingTimes,"🍼 마지막 수유");
        lastFeed=current[0];lastFeedAmount=current[1];
        TextView[] previous=feedSummaryTile(feedingTimes,"🍼 이전 수유");
        previousFeed=previous[0];previousFeedAmount=previous[1];
        elapsed.addView(feedingTimes);
        LinearLayout diaperTimes=row();
        lastPoop=summaryTile(diaperTimes,"💩 대변","기록 없음",true);
        lastPee=summaryTile(diaperTimes,"💧 소변","기록 없음",true);
        elapsed.addView(diaperTimes);root.addView(elapsed,margin(-1,-2,0,12));
        root.addView(text("빠른 기록 +",20,true),margin(-1,-2,0,6));
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH};
        for(int j=0;j<2;j++){
            LinearLayout actions=row();
            for(int i=j*2;i<j*2+2;i++){
                String kind=kinds[i];Button b=button(FamilyStore.icon(kind)+"\n"+FamilyStore.kindLabel(kind));
                b.setOnClickListener(v->{if(FamilyStore.FEED.equals(kind))pickFeed();else pickDiaper(kind);});actions.addView(b,flex(72));
            }root.addView(actions,margin(-1,-2,0,4));
        }
        LinearLayout today=card();today.setPadding(dp(15),dp(12),dp(15),dp(12));today.addView(text("오늘 누적 기록",18,true));
        LinearLayout todayMilks=row();
        todayBreast=summaryTile(todayMilks,"🍼 모유","0회");
        todayPumped=summaryTile(todayMilks,"🍼 유축","0mL");
        todayFormula=summaryTile(todayMilks,"🍼 분유","0mL");
        today.addView(todayMilks);
        LinearLayout todayDiapers=row();
        dailyPoop=summaryTile(todayDiapers,"💩 대변","0회");
        dailyPee=summaryTile(todayDiapers,"💧 소변","0회");
        today.addView(todayDiapers);
        dailyFeed=text("수유 총 0회 · 측정량 0mL",13,true);
        today.addView(dailyFeed,margin(-1,-2,5,0));
        root.addView(today,margin(-1,-2,6,15));

        LinearLayout yesterdayCard=card();yesterdayCard.setPadding(dp(15),dp(12),dp(15),dp(12));yesterdayCard.addView(text("어제 누적 기록",18,true));
        LinearLayout yesterdayMilks=row();
        yesterdayBreast=summaryTile(yesterdayMilks,"🍼 모유","0회");
        yesterdayPumped=summaryTile(yesterdayMilks,"🍼 유축","0mL");
        yesterdayFormula=summaryTile(yesterdayMilks,"🍼 분유","0mL");
        yesterdayCard.addView(yesterdayMilks);
        LinearLayout yesterdayDiapers=row();
        yesterdayPoop=summaryTile(yesterdayDiapers,"💩 대변","0회");
        yesterdayPee=summaryTile(yesterdayDiapers,"💧 소변","0회");
        yesterdayCard.addView(yesterdayDiapers);
        yesterdayFeed=text("수유 총 0회 · 측정량 0mL",13,true);
        yesterdayCard.addView(yesterdayFeed,margin(-1,-2,5,0));
        root.addView(yesterdayCard,margin(-1,-2,0,16));
        updateSummary();
        LinearLayout lock=card();lock.addView(text("🔒 잠금 화면 기록 (알림 1개)",17,true));
        lock.addView(text("잠금 화면에 마지막 수유 후 경과시간, 오늘·어제 모유수유 횟수와 유축+분유 총 mL를 표시합니다. 수유 용량 선택 뒤 현재 시간 또는 이전 시간(−5분 누적)을 저장할 수 있어요. 혼합 수유는 위젯에서 유축 + 분유만 입력합니다. 다른 사람이 잠금 화면에서 이 정보를 볼 수 있습니다.",12,false),margin(-1,-2,7,12));
        Button enabled=button(QuickNotification.enabled(this)?"빠른 기록 끄기":"잠금 화면 빠른 기록 켜기");enabled.setOnClickListener(v->toggle());
        lock.addView(enabled,margin(-1,48,0,0));root.addView(lock,margin(-1,-2,0,18));
        root.addView(text("가족 최근 기록",19,true),margin(-1,-2,0,9));
        SimpleDateFormat fmt=new SimpleDateFormat("MM월 dd일 HH:mm",Locale.KOREAN);
        if(events.isEmpty())root.addView(text("아직 기록이 없어요 🌱",15,false));
        int shown=0;for(DocumentSnapshot snap:events){if(shown++>=100)break;Map<String,Object> map=snap.getData();if(map==null)continue;
            String kind=snap.getString("kind");Date time=snap.getDate("at");
            LinearLayout line=card();line.addView(text(FamilyStore.icon(kind)+" "+FamilyStore.kindLabel(kind)+" · "+fmt.format(time==null?new Date():time),15,true));
            TextView second=text(FamilyStore.detail(map)+" · "+snap.getString("who"),12,false);second.setTextColor(MUTED);line.addView(second,margin(-1,-2,5,0));
            line.setOnClickListener(v->editRecord(snap));
            TextView tap=text("눌러서 시간·양 수정",11,false);tap.setTextColor(0xFFBD8498);line.addView(tap,margin(-1,-2,4,0));
            if(FamilyStore.uid().equals(snap.getString("createdBy")))line.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("가족 기록에서 삭제할까요?")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->snap.getReference().delete().addOnFailureListener(e->fail(e.getMessage()))).show();return true;});
            root.addView(line,margin(-1,-2,0,8));
        }
        TextView note=text("기존 아기로그 앱은 삭제하지 마세요. 새 가족 앱의 기록부터 공유됩니다.",11,false);note.setTextColor(MUTED);root.addView(note,margin(-1,-2,18,0));
        LinearLayout info=card();info.addView(text("👨‍👩‍👧 가족 초대 코드",17,true));
        TextView code=text(FamilyStore.code(this),17,true);code.setTextIsSelectable(true);info.addView(code,margin(-1,-2,8,4));
        Button share=button("초대 코드 공유");share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"아기로그 가족 코드: "+FamilyStore.code(this));startActivity(Intent.createChooser(i,"가족에게 보내기"));});
        info.addView(share,margin(-1,44,5,0));root.addView(info,margin(-1,-2,16,0));
    }
    private long startToday(){java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private void record(String kind,String type,int ml,String size){RecordWorker.queue(this,kind,type,ml,size);Toast.makeText(this,"기록 전송 대기 중 · 연결되면 가족에게 표시돼요",Toast.LENGTH_SHORT).show();}
    private void pickDiaper(String kind){String[] labels={"소 · 적음","중 · 보통","대 · 많음"},sizes={"small","medium","large"};
        new AlertDialog.Builder(this).setTitle(FamilyStore.kindLabel(kind)+" 양").setItems(labels,(d,i)->record(kind,"",0,sizes[i])).show();}
    private TextView summaryTile(LinearLayout row,String title,String value){
        return summaryTile(row,title,value,false);
    }
    private TextView summaryTile(LinearLayout row,String title,String value,boolean compact){
        LinearLayout tile=col();tile.setPadding(dp(5),dp(7),dp(5),dp(7));tile.setBackground(bg(0xFFFFF0E7));
        TextView label=text(title,12,true);label.setGravity(Gravity.CENTER);tile.addView(label);
        TextView data=text(value,13,true);data.setGravity(Gravity.CENTER);tile.addView(data,margin(-1,-2,3,0));
        row.addView(tile,flex(compact?60:64));return data;
    }
    /** The feeding tiles keep elapsed time prominent and each event's measured amount below it. */
    private TextView[] feedSummaryTile(LinearLayout parent,String label){
        LinearLayout tile=col();tile.setPadding(dp(7),dp(7),dp(7),dp(7));tile.setBackground(bg(0xFFFFF0E7));
        TextView name=text(label,12,true);name.setGravity(Gravity.CENTER);tile.addView(name);
        TextView time=text("기록 없음",19,true);time.setGravity(Gravity.CENTER);tile.addView(time,margin(-1,-2,2,0));
        TextView amount=text("수유량 없음",12,false);amount.setGravity(Gravity.CENTER);
        amount.setTextColor(0xFF78606D);tile.addView(amount,margin(-1,-2,2,0));
        parent.addView(tile,flex(91));return new TextView[]{time,amount};
    }
    private String since(Date date){
        return ElapsedTime.display(date==null?-1:date.getTime());
    }
    private String feedingAmountText(DocumentSnapshot snap){
        if(snap==null)return "수유량 없음";
        Map<String,Object> item=snap.getData();if(item==null||Boolean.TRUE.equals(item.get("legacy")))return "수유량 정보 없음";
        int total=FamilyStore.knownMl(item);
        int breast=sourceAmount(item,"breastMl",FamilyStore.BREAST);
        int pumped=sourceAmount(item,"pumpedMl",FamilyStore.PUMPED);
        int formula=sourceAmount(item,"formulaMl",FamilyStore.FORMULA);
        boolean unknown=FamilyStore.unknownBreast(item);
        ArrayList<String> parts=new ArrayList<>();
        if(breast>0)parts.add("모유 "+breast);
        if(unknown)parts.add("모유 미측정");
        if(pumped>0)parts.add("유축 "+pumped);
        if(formula>0)parts.add("분유 "+formula);
        if(total==0)return unknown?"모유 미측정":"수유량 정보 없음";
        return android.text.TextUtils.join(" + ",parts)+" · 합계 "+total+"mL";
    }
    /** Count breast sessions and milk volumes individually, including older single-source events. */
    private boolean hasBreast(Map<String,Object> item){
        if(Boolean.TRUE.equals(item.get("legacy")))return false;
        Object raw=item.get("feedParts");
        if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
            return FamilyStore.number(p.get("breastMl"))>0||Boolean.TRUE.equals(p.get("breastUnmeasured"));
        }
        return FamilyStore.BREAST.equals(item.get("feedType"));
    }
    private int sourceAmount(Map<String,Object> item,String key,String oldType){
        if(Boolean.TRUE.equals(item.get("legacy")))return 0;
        Object raw=item.get("feedParts");
        if(raw instanceof Map)return Math.max(0,FamilyStore.number(((Map<?,?>)raw).get(key)));
        return oldType.equals(item.get("feedType"))?Math.max(0,FamilyStore.number(item.get("ml"))):0;
    }
    private void updateSummary(){
        if(dailyFeed==null||dailyPoop==null||dailyPee==null||todayBreast==null)return;
        int[] feeds=new int[2], totals=new int[2], breasts=new int[2], pumped=new int[2], formula=new int[2];
        int[] poops=new int[2], pees=new int[2];
        Date lf=null,lp=null,lu=null;
        DocumentSnapshot newestFeed=null,olderFeed=null;
        long day=startToday(),now=System.currentTimeMillis();
        Calendar previous=Calendar.getInstance();previous.setTimeInMillis(day);previous.add(Calendar.DAY_OF_MONTH,-1);
        long yesterday=previous.getTimeInMillis();
        for(DocumentSnapshot snap:events){
            Date date=snap.getDate("at");if(date==null||date.getTime()>now+300000L)continue;
            String kind=snap.getString("kind");if(kind==null)continue;
            if(FamilyStore.FEED.equals(kind)){
                if(newestFeed==null||date.after(newestFeed.getDate("at"))){
                    olderFeed=newestFeed;newestFeed=snap;
                }else if(olderFeed==null||date.after(olderFeed.getDate("at"))){
                    olderFeed=snap;
                }
            }
            if(FamilyStore.FEED.equals(kind)&&(lf==null||date.after(lf)))lf=date;
            if((FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))&&(lp==null||date.after(lp)))lp=date;
            if((FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))&&(lu==null||date.after(lu)))lu=date;
            long at=date.getTime();
            int d=at>=day?0:(at>=yesterday?1:-1);
            if(d<0)continue;
            if(FamilyStore.PEE.equals(kind)||FamilyStore.BOTH.equals(kind))pees[d]++;
            if(FamilyStore.POOP.equals(kind)||FamilyStore.BOTH.equals(kind))poops[d]++;
            if(FamilyStore.FEED.equals(kind)){
                feeds[d]++;
                Map<String,Object> item=snap.getData();if(item==null)continue;
                totals[d]+=FamilyStore.knownMl(item);
                if(hasBreast(item))breasts[d]++;
                pumped[d]+=sourceAmount(item,"pumpedMl",FamilyStore.PUMPED);
                formula[d]+=sourceAmount(item,"formulaMl",FamilyStore.FORMULA);
            }
        }
        todayBreast.setText(breasts[0]+"회");todayPumped.setText(pumped[0]+"mL");todayFormula.setText(formula[0]+"mL");
        yesterdayBreast.setText(breasts[1]+"회");yesterdayPumped.setText(pumped[1]+"mL");yesterdayFormula.setText(formula[1]+"mL");
        dailyPoop.setText(poops[0]+"회");dailyPee.setText(pees[0]+"회");
        yesterdayPoop.setText(poops[1]+"회");yesterdayPee.setText(pees[1]+"회");
        dailyFeed.setText("수유 총 "+feeds[0]+"회 · 측정량 "+totals[0]+"mL");
        yesterdayFeed.setText("수유 총 "+feeds[1]+"회 · 측정량 "+totals[1]+"mL");
        if(lastFeed!=null)lastFeed.setText(since(newestFeed==null?null:newestFeed.getDate("at")));
        if(lastFeedAmount!=null)lastFeedAmount.setText(feedingAmountText(newestFeed));
        if(previousFeed!=null)previousFeed.setText(since(olderFeed==null?null:olderFeed.getDate("at")));
        if(previousFeedAmount!=null)previousFeedAmount.setText(feedingAmountText(olderFeed));
        if(lastPoop!=null)lastPoop.setText(since(lp));
        if(lastPee!=null)lastPee.setText(since(lu));
    }
    private static class FeedInputs {
        EditText breast,pumped,formula;CheckBox unknown;
    }
    private EditText amountLine(LinearLayout parent,String label,int current){
        parent.addView(text(label+" (mL)",14,true),margin(-1,-2,9,0));
        LinearLayout line=row();EditText input=new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setSingleLine(true);
        input.setText(String.valueOf(current));input.setSelectAllOnFocus(true);
        Button minus=button("−5"),plus=button("+5");
        minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(0,n-5)));});
        plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        line.addView(minus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,dp(54),1);mid.setMargins(dp(8),0,dp(8),0);line.addView(input,mid);
        line.addView(plus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        parent.addView(line);return input;
    }
    private int parseAmount(EditText input){try{return Integer.parseInt(input.getText().toString().trim());}catch(Exception e){return 0;}}
    private FeedInputs feedInputs(LinearLayout parent,Map<String,Object> item,boolean isExisting){
        int breast=0,pumped=0,formula=isExisting?0:70;boolean unknown=false;
        if(isExisting&&item!=null){Object raw=item.get("feedParts");
            if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
                breast=FamilyStore.number(p.get("breastMl"));pumped=FamilyStore.number(p.get("pumpedMl"));
                formula=FamilyStore.number(p.get("formulaMl"));unknown=Boolean.TRUE.equals(p.get("breastUnmeasured"));
            }else{
                int ml=FamilyStore.number(item.get("ml"));String type=String.valueOf(item.get("feedType"));
                if(FamilyStore.BREAST.equals(type)){if(ml<0)unknown=true;else breast=ml;}
                else if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                else if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
            }
        }
        parent.addView(text("모유는 별도 수유, 새 혼합은 유축 + 분유만 입력 · 5mL 단위",12,false));
        FeedInputs f=new FeedInputs();f.breast=amountLine(parent,"모유",breast);
        f.pumped=amountLine(parent,"유축",pumped);f.formula=amountLine(parent,"분유",formula);
        f.unknown=new CheckBox(this);f.unknown.setText("직접 모유 수유 · 양 미측정 포함");f.unknown.setChecked(unknown);parent.addView(f.unknown);
        return f;
    }
    private Map<String,Object> checkedFeed(FeedInputs f){
        String[] values={f.breast.getText().toString().trim(),f.pumped.getText().toString().trim(),f.formula.getText().toString().trim()};
        int[] amounts=new int[3];int total=0;
        for(int i=0;i<3;i++){try{amounts[i]=Integer.parseInt(values[i]);}catch(Exception ex){throw new IllegalArgumentException("각 용량에 숫자를 입력하세요.");}
            if(amounts[i]<0||amounts[i]>1000||amounts[i]%5!=0)throw new IllegalArgumentException("수유량은 0~1000mL, 5mL 단위로 입력하세요.");
            total+=amounts[i];}
        if(total>1000||(total==0&&!f.unknown.isChecked()))throw new IllegalArgumentException("수유량 합계는 1000mL 이하로, 5mL 단위로 입력하세요. 미측정만 기록할 수도 있어요.");
        Map<String,Object> data=new HashMap<>();data.put("feedType",FamilyStore.feedType(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));
        data.put("ml",total);data.put("size","");data.put("feedParts",FamilyStore.feedParts(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));return data;
    }
    private void chooseFeedTime(Map<String,Object> data){
        final int[] minutes={0};
        LinearLayout layout=col();layout.setPadding(dp(15),dp(8),dp(15),dp(5));
        layout.addView(text("언제 수유했나요? 현재 또는 이전 시간을 고르세요.",14,true));
        LinearLayout choices=row();Button now=button("현재 시간"),earlier=button("이전 시간");
        choices.addView(now,flex(50));choices.addView(earlier,flex(50));layout.addView(choices);
        TextView selection=text("",15,true);selection.setGravity(Gravity.CENTER);layout.addView(selection,margin(-1,46,7,3));
        LinearLayout adjustment=row();Button minus=button("−5분");
        TextView accumulated=text("누적 0분 전",16,true);accumulated.setGravity(Gravity.CENTER);
        accumulated.setBackground(bg(0xFFFFEFBA));accumulated.setTextColor(0xFF163046);
        adjustment.addView(minus,flex(46));adjustment.addView(accumulated,flex(46));layout.addView(adjustment);
        SimpleDateFormat fmt=new SimpleDateFormat("MM/dd HH:mm",Locale.KOREA);
        Runnable refresh=()->{
            selection.setText("기록할 시각: "+fmt.format(new Date(System.currentTimeMillis()-minutes[0]*60000L))
                +(minutes[0]==0?" · 현재":" · "+minutes[0]+"분 전"));
            accumulated.setText("누적 "+minutes[0]+"분 전");
        };
        now.setOnClickListener(v->{minutes[0]=0;refresh.run();});
        earlier.setOnClickListener(v->{if(minutes[0]==0)minutes[0]=5;refresh.run();});
        minus.setOnClickListener(v->{minutes[0]=Math.min(1440,minutes[0]+5);refresh.run();});
        refresh.run();
        new AlertDialog.Builder(this).setTitle("🍼 마지막 단계 · 수유 시간")
            .setView(layout).setNegativeButton("취소",null)
            .setPositiveButton("이 시간으로 기록",(dialog,which)->{
                Map<?,?> p=(Map<?,?>)data.get("feedParts");
                long at=System.currentTimeMillis()-minutes[0]*60000L;
                RecordWorker.queueParts(this,FamilyStore.number(p.get("breastMl")),FamilyStore.number(p.get("pumpedMl")),
                    FamilyStore.number(p.get("formulaMl")),Boolean.TRUE.equals(p.get("breastUnmeasured")),at);
                Toast.makeText(this,"수유 시간 저장 · 가족에게 전송 대기 중",Toast.LENGTH_SHORT).show();
            }).show();
    }
    /** New feeds distinguish direct breastfeeding from pumped milk + formula mixing. */
    private void pickFeed(){
        new AlertDialog.Builder(this).setTitle("🍼 수유 종류")
            .setItems(new String[]{"모유수유","유축","분유","혼합 (유축 + 분유)"},
                (dialog,which)->pickFeedOfType(which)).show();
    }
    private void pickFeedOfType(int choice){
        ScrollView scroll=new ScrollView(this);LinearLayout root=col();
        root.setPadding(dp(17),dp(10),dp(17),dp(10));scroll.addView(root);
        EditText breast=null,pumped=null,formula=null;CheckBox unknown=null;
        if(choice==0){
            breast=amountLine(root,"모유",0);
            unknown=new CheckBox(this);unknown.setText("모유수유 양 미측정");unknown.setChecked(true);root.addView(unknown);
        }else if(choice==1){pumped=amountLine(root,"유축",70);
        }else if(choice==2){formula=amountLine(root,"분유",70);
        }else{
            root.addView(text("혼합은 유축 + 분유만 기록합니다. 각각 5mL 이상 입력해 주세요.",13,true));
            pumped=amountLine(root,"유축",0);formula=amountLine(root,"분유",70);
        }
        final EditText bInput=breast,pInput=pumped,fInput=formula;final CheckBox unknownBox=unknown;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🍼 수유 기록 · 5mL 단위")
            .setView(scroll).setNegativeButton("취소",null).setPositiveButton("다음: 시간 선택",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int b=bInput==null?0:parseAmount(bInput);
            int p=pInput==null?0:parseAmount(pInput);
            int f=fInput==null?0:parseAmount(fInput);
            boolean isUnknown=unknownBox!=null&&unknownBox.isChecked();
            if(isUnknown)b=0; // Unmeasured direct breastfeeding cannot have a numeric amount.
            int total=b+p+f;
            if(b<0||p<0||f<0||b%5!=0||p%5!=0||f%5!=0||total>1000){
                Toast.makeText(this,"수유량은 합계 1000mL 이하, 5mL 단위로 입력하세요.",Toast.LENGTH_LONG).show();return;
            }
            if(choice==3&&(p<5||f<5)){
                Toast.makeText(this,"혼합은 유축과 분유를 각각 5mL 이상 입력해야 합니다.",Toast.LENGTH_LONG).show();return;
            }
            if(choice!=3&&total==0&&!isUnknown){
                Toast.makeText(this,"수유량을 입력하거나 모유 양 미측정을 선택하세요.",Toast.LENGTH_LONG).show();return;
            }
            Map<String,Object> data=new HashMap<>();
            data.put("feedType",FamilyStore.feedType(b,p,f,isUnknown));data.put("ml",total);data.put("size","");
            data.put("feedParts",FamilyStore.feedParts(b,p,f,isUnknown));
            dialog.dismiss();chooseFeedTime(data);
        }));dialog.show();
    }
    private Spinner spinner(String[] items,int selected){
        Spinner result=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        result.setAdapter(adapter);result.setSelection(selected);return result;
    }
    private int indexOf(String[] values,String value,int fallback){for(int i=0;i<values.length;i++)if(values[i].equals(value))return i;return fallback;}
    private void editRecord(DocumentSnapshot snap){
        Map<String,Object> item=snap.getData();if(item==null)return;
        String[] kinds={FamilyStore.FEED,FamilyStore.PEE,FamilyStore.POOP,FamilyStore.BOTH};
        String[] types={FamilyStore.BREAST,FamilyStore.PUMPED,FamilyStore.FORMULA};
        String[] sizes={FamilyStore.SMALL,FamilyStore.MEDIUM,FamilyStore.LARGE};
        Calendar when=Calendar.getInstance();Date old=snap.getDate("at");if(old!=null)when.setTime(old);
        ScrollView scroll=new ScrollView(this);LinearLayout form=col();form.setPadding(dp(18),dp(8),dp(18),dp(8));scroll.addView(form);
        form.addView(text("기록 종류",14,true));Spinner kind=spinner(new String[]{"수유","소변","대변","소+대변"},indexOf(kinds,snap.getString("kind"),0));form.addView(kind);
        form.addView(text("기록 날짜·시간",14,true),margin(-1,-2,12,3));
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.KOREA);
        Button time=button(fmt.format(when.getTime()));form.addView(time,margin(-1,49,3,10));
        time.setOnClickListener(v->new DatePickerDialog(this,(view,y,m,d)->{
            when.set(y,m,d);
            new TimePickerDialog(this,(t,h,min)->{when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,min);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);time.setText(fmt.format(when.getTime()));},when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show();
        },when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show());
        LinearLayout feedBox=col();FeedInputs feed=feedInputs(feedBox,item,FamilyStore.FEED.equals(snap.getString("kind")));form.addView(feedBox);
        LinearLayout diaperBox=col();diaperBox.addView(text("기저귀 양 (소+대변은 같은 양 적용)",13,true));
        Spinner size=spinner(new String[]{"소","중","대"},indexOf(sizes,snap.getString("size"),1));diaperBox.addView(size);form.addView(diaperBox);
        kind.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id){boolean feed=position==0;feedBox.setVisibility(feed?View.VISIBLE:View.GONE);diaperBox.setVisibility(feed?View.GONE:View.VISIBLE);}
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("시간·양 수정").setView(scroll)
            .setNegativeButton("취소",null).setPositiveButton("수정 저장",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long timeMs=when.getTimeInMillis();Calendar first=Calendar.getInstance();first.set(2020,0,1,0,0,0);
            if(timeMs<first.getTimeInMillis()||timeMs>System.currentTimeMillis()+300000L){Toast.makeText(this,"시간은 2020년부터 현재까지 입력하세요.",Toast.LENGTH_LONG).show();return;}
            String k=kinds[kind.getSelectedItemPosition()];Map<String,Object> changes=new HashMap<>();
            changes.put("kind",k);changes.put("at",new Timestamp(new Date(timeMs)));changes.put("legacy",false);
            if(FamilyStore.FEED.equals(k)){
                try{changes.putAll(checkedFeed(feed));}
                catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            }else{
                changes.put("feedType","");changes.put("ml",0);changes.put("size",sizes[size.getSelectedItemPosition()]);
                changes.put("feedParts",FieldValue.delete());
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            snap.getReference().update(changes).addOnSuccessListener(ok->{Toast.makeText(this,"수정 완료 · 가족에게 반영됩니다.",Toast.LENGTH_SHORT).show();dialog.dismiss();})
                .addOnFailureListener(err->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);fail("수정 실패: "+err.getMessage());});
        }));
        dialog.show();
    }
    private void openFeedFromWidgetIfRequested(){
        Intent intent=getIntent();
        if(intent!=null&&"ready".equals(state)&&intent.getBooleanExtra("open_feed_from_widget",false)){
            intent.removeExtra("open_feed_from_widget");
            pickFeed();
        }
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        openFeedFromWidgetIfRequested();
    }
    private void toggle(){if(QuickNotification.enabled(this)){QuickNotification.enabled(this,false);draw();return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);return;}
        QuickNotification.enabled(this,true);draw();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);
        if(request==99){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)QuickNotification.enabled(this,true);
            else Toast.makeText(this,"알림 권한이 필요합니다",Toast.LENGTH_LONG).show();draw();}}
}
