Android asset files are sourced from ../../web by the Gradle sourceSets rule in android/app/build.gradle. Do not duplicate the web folder here.
