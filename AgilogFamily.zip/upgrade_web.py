from pathlib import Path
p=Path('/mnt/data/agilog_v3/web/app.js');s=p.read_text()
s=s.replace('query,orderBy,limit,onSnapshot','query,orderBy,onSnapshot')
s=s.replace("breast:'모유',pumped:'유축',formula:'분유'", "breast:'모유',pumped:'유축',formula:'분유',mixed:'혼합'")
s=s.replace("const q=query(collection(db,'families',code,'events'),orderBy('at','desc'),limit(100));", "const q=query(collection(db,'families',code,'events'),orderBy('at','desc')); // 전체 기록을 받아 오늘 총계와 마지막 시간을 정확하게 계산")
s=s.replace("function formatTime(item){", """function partsFor(r){
  if(r.feedParts && typeof r.feedParts==='object'){
    return {breastMl:Number(r.feedParts.breastMl)||0,pumpedMl:Number(r.feedParts.pumpedMl)||0,formulaMl:Number(r.feedParts.formulaMl)||0,breastUnmeasured:r.feedParts.breastUnmeasured===true};
  }
  const p={breastMl:0,pumpedMl:0,formulaMl:0,breastUnmeasured:r.feedType==='breast'&&r.ml===-1};
  if(['breast','pumped','formula'].includes(r.feedType)&&Number(r.ml)>0)p[r.feedType==='breast'?'breastMl':r.feedType==='pumped'?'pumpedMl':'formulaMl']=r.ml;
  return p;
}
function feedTotal(r){if(r.kind!=='feed'||r.legacy)return 0;const p=partsFor(r);return p.breastMl+p.pumpedMl+p.formulaMl;}
function feedUnknown(r){return r.kind==='feed'&&!r.legacy&&partsFor(r).breastUnmeasured;}
function elapsed(date){if(!date)return '기록 없음';const minutes=Math.max(0,Math.floor((Date.now()-date.getTime())/60000));
  if(minutes<1)return '방금';if(minutes<60)return minutes+'분 전';const hours=Math.floor(minutes/60);if(hours<24)return hours+'시간 '+(minutes%60)+'분 전';return Math.floor(hours/24)+'일 '+(hours%24)+'시간 전';
}
function refreshSummary(){
  const now=new Date(),day=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
  const today=records.filter(r=>r.at?.toDate?.() instanceof Date && r.at.toDate().getTime()>=day&&r.at.toDate().getTime()<=Date.now()+300000);
  $('n-feed').textContent=today.filter(r=>r.kind==='feed').length+'회';
  $('n-poop').textContent=today.filter(r=>r.kind==='poop'||r.kind==='both').length+'회';
  $('n-pee').textContent=today.filter(r=>r.kind==='pee'||r.kind==='both').length+'회';
  $('total-feed').textContent=today.reduce((sum,r)=>sum+feedTotal(r),0)+'mL';
  show('unknown-feed',today.some(feedUnknown));
  for(const k of ['feed','poop','pee']){
    const r=records.find(e=>e.kind===k||(e.kind==='both'&&k!=='feed'));
    $('last-'+k).textContent=elapsed(r?.at?.toDate?.());
  }
}
function formatTime(item){""")
start=s.index('function details(r){');end=s.index('function renderRecords(){',start)
s=s[:start]+"""function details(r){
  if(r.legacy)return '이전 기록 · 상세 정보 없음';
  if(r.kind==='feed'){
    const p=partsFor(r),items=[];
    if(p.breastMl)items.push('모유 '+p.breastMl+'mL');
    if(p.breastUnmeasured)items.push('모유 양 미측정');
    if(p.pumpedMl)items.push('유축 '+p.pumpedMl+'mL');
    if(p.formulaMl)items.push('분유 '+p.formulaMl+'mL');
    return (items.length?items.join(' + '):'수유')+' · 합계 '+feedTotal(r)+'mL'+(p.breastUnmeasured?' (미측정 제외)':'');
  }
  return '양 '+(labels[r.size]||'-');
}
"""+s[end:]
old="  const today=new Date().toDateString();for(const k of ['feed','poop','pee'])$('n-'+k).textContent=records.filter(r=>(r.kind===k||(r.kind==='both'&&(k==='poop'||k==='pee')))&&(r.at?.toDate?.()||new Date(0)).toDateString()===today).length;"
assert old in s;s=s.replace(old,"  refreshSummary();")
s=s.replace('  for(const r of records){const entry=', '  for(const r of records.slice(0,100)){const entry=')
start=s.index('function editVisibility(){');end=s.index('function option(',start)
s=s[:start]+"""function editVisibility(){const feed=$('editKind').value==='feed';show('editFeed',feed);show('editDiaper',!feed);}
function fillParts(prefix,p){
  $(prefix+'BreastMl').value=p.breastMl;
  $(prefix+'PumpedMl').value=p.pumpedMl;
  $(prefix+'FormulaMl').value=p.formulaMl;
  $(prefix+'BreastUnknown').checked=p.breastUnmeasured;
}
function readParts(prefix){
  const get=k=>{const raw=$(prefix+k).value.trim();const n=Number(raw);if(!raw||!Number.isInteger(n)||n<0||n>1000||n%5!==0)throw Error('모유·유축·분유는 각각 0~1000mL, 5mL 단위로 입력하세요.');return n;};
  const p={breastMl:get('BreastMl'),pumpedMl:get('PumpedMl'),formulaMl:get('FormulaMl'),breastUnmeasured:$(prefix+'BreastUnknown').checked};
  const total=p.breastMl+p.pumpedMl+p.formulaMl;
  if((total===0&&!p.breastUnmeasured)||total>1000)throw Error('수유량 합계는 1~1000mL 범위여야 해요. 직접 모유 수유 양 미측정만 기록할 수도 있어요.');
  return p;
}
function feedData(p){const total=p.breastMl+p.pumpedMl+p.formulaMl;
  const types=[p.breastMl>0||p.breastUnmeasured?'breast':null,p.pumpedMl>0?'pumped':null,p.formulaMl>0?'formula':null].filter(Boolean);
  return {feedType:types.length>1?'mixed':types[0],ml:total,size:'',feedParts:p};
}
function openEdit(r){
  clearError();clearEditError();editingId=r.id;
  $('editKind').value=['feed','pee','poop','both'].includes(r.kind)?r.kind:'feed';
  $('editAt').value=localInputValue(r.at?.toDate?.()||new Date());
  fillParts('edit',r.kind==='feed'?partsFor(r):{breastMl:0,pumpedMl:0,formulaMl:70,breastUnmeasured:false});
  $('editSize').value=['small','medium','large'].includes(r.size)?r.size:'medium';
  editVisibility();$('editDialog').showModal();
}
async function saveEdit(evt){
  evt.preventDefault();clearError();clearEditError();if(!editingId)return;
  const date=new Date($('editAt').value);
  if(!Number.isFinite(date.getTime())||date.getTime()>Date.now()+300000||date.getFullYear()<2020){editError('기록 시간은 2020년 이후부터 현재까지 입력할 수 있어요.');return;}
  const k=$('editKind').value;
  const data={kind:k,at:Timestamp.fromDate(date),legacy:false};
  try{
    if(k==='feed')Object.assign(data,feedData(readParts('edit')));
    else Object.assign(data,{feedType:'',ml:0,size:$('editSize').value,feedParts:null});
  }catch(e){editError(e.message);return;}
  // Firestore rules accept feedParts only on feeds; updateDoc can delete the previous feedParts on diaper edits.
  if(k!=='feed')data.feedParts=deleteField();
  const save=$('saveEdit');save.disabled=true;
  try{await updateDoc(doc(db,'families',family,'events',editingId),data);
    $('editDialog').close();editingId=null;$('status').textContent='기록 수정 완료';
  }catch(e){editError('수정할 수 없습니다: '+e.message);}finally{save.disabled=false;}
}
"""+s[end:]
s=s.replace('onSnapshot,deleteDoc,updateDoc,Timestamp,serverTimestamp', 'onSnapshot,deleteDoc,updateDoc,deleteField,Timestamp,serverTimestamp')
start=s.index('function renderPicker(){');end=s.index('async function init(){',start)
s=s[:start]+"""function renderPicker(){const el=$('pickerStep');el.replaceChildren();
  if(kind!=='feed'){
    el.append(stepTitle('양을 선택하면 바로 저장돼요'));
    grid(el,[['소 · 적음','small'],['중 · 보통','medium'],['대 · 많음','large']],size=>save(kind,'',0,size));return;
  }
  el.append(stepTitle('한 번의 수유 · 혼합 가능 (5mL 단위)'));
  const rows=[['모유','BreastMl',0],['유축','PumpedMl',0],['분유','FormulaMl',70]];
  for(const [label,id,value] of rows){
    const row=document.createElement('div');row.className='feed-line';
    const name=document.createElement('label');name.textContent=label+' (mL)';name.htmlFor='pick'+id;
    const input=document.createElement('input');input.type='number';input.min='0';input.max='1000';input.step='5';input.value=String(value);input.id='pick'+id;
    row.append(name,input);el.append(row);
  }
  const check=document.createElement('label');check.className='feed-check';
  const input=document.createElement('input');input.type='checkbox';input.id='pickBreastUnknown';check.append(input,document.createTextNode('직접 모유 수유 · 양 미측정 포함'));el.append(check);
  const hint=document.createElement('p');hint.className='feed-footnote';hint.textContent='예: 모유 20 + 유축 30 + 분유 40 = 오늘 총 수유량 90mL. 미측정 모유는 합계에서 제외됩니다.';el.append(hint);
  const saveBtn=option('🍼 이번 수유 저장',async()=>{
    try{const data=feedData(readParts('pick'));saveBtn.disabled=true;
      await addDoc(collection(db,'families',family,'events'),{kind:'feed',...data,legacy:false,...meta(),at:serverTimestamp()});
      show('picker',false);$('status').textContent='수유 기록 저장됨';
    }catch(e){error('기록 저장 실패: '+e.message);}finally{saveBtn.disabled=false;}
  });saveBtn.className='primary';saveBtn.style.width='100%';el.append(saveBtn);
}
async function save(k,t,ml,size){clearError();const e={kind:k,feedType:t,ml,size,legacy:false,...meta(),at:serverTimestamp()};
  show('picker',false);try{await addDoc(collection(db,'families',family,'events'),e);$('status').textContent='저장됨 · '+(labels[k]||k);}catch(ex){show('picker',true);error('기록 저장에 실패했습니다: '+ex.message);}}
"""+s[end:]
s=s.replace("$('create').onclick=createFamily", "setInterval(()=>{if(records.length)refreshSummary();},60000);\n$('create').onclick=createFamily")
p.write_text(s)
