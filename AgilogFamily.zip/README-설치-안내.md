# 🍼 아기로그 가족 — 아이폰 + 안드로이드 연동 앱

## 무엇을 만들었나요?

- **아이폰**: 사파리에서 홈 화면에 추가하는 **PWA 설치형 웹 앱**. 앱스토어/서명 없는 설치 방식입니다. (정식 네이티브 `.ipa`가 아닙니다.)
- **안드로이드**: 별도 APK로 설치하는 **아기로그 가족** 네이티브 앱. 기존 아기로그 앱은 지우지 않아도 됩니다.
- **공통**: Firebase 익명 로그인 + Firestore 가족 코드/실시간 공유. 가족 코드 20자리로 연결하면 iPhone ↔ Android에서 같은 기록이 보입니다.
- **기록**: 수유 모유/유축/분유, 5~1000mL(5mL 단위, 처음 70mL 선택), 모유 직접 수유 양 미측정, 대변·소변 소/중/대, 누가 기록했는지.
- **안드로이드**: 잠금 화면 알림 1개에서 수유/대변/소변을 순서대로 선택하고 서버로 전송. 인터넷 없이 눌러도 WorkManager가 대기시킨 후 재시도합니다.

**중요:** 이 프로젝트는 소스·배포 설정 단계입니다. 이 문서를 보는 것만으로 서버가 생성되거나 앱이 배포된 것은 아닙니다. Firebase 등록과 GitHub Actions 빌드·배포가 먼저 필요합니다. iPhone의 Safari PWA에는 잠금 화면 빠른 입력 위젯이 없습니다.

## ① Firebase 만들기 (휴대폰 크롬으로 가능)

1. https://console.firebase.google.com/ 에서 Firebase 프로젝트 하나를 만듭니다. **두 앱 모두 같은 Firebase 프로젝트**를 사용합니다.
2. **Authentication → Sign-in method → Anonymous(익명)** 를 사용 설정합니다.
3. **Firestore Database**를 생성합니다. 생성 후 **규칙(Rules)** 메뉴에서 이 압축파일의 `firestore.rules` 내용 전체를 복사해 **Publish** 하세요. **테스트 모드에서 멈추지 마세요.**
4. **프로젝트 설정(톱니바퀴) → 앱 추가 → 웹 </>** 을 누릅니다. Web 앱 등록 화면에서 `apiKey`, `authDomain`, `projectId`, `appId` 네 값을 확인합니다.
5. 같은 Firebase 프로젝트에서 **앱 추가 → Android** 를 눌러 패키지 이름을 **`com.agilog.family`** 로 등록합니다. `google-services.json`을 다운로드해 휴대폰의 다운로드 폴더에 보관합니다.
6. Firebase Authentication에서 **승인된 도메인(Authorized domains)** 에 `깃허브계정.github.io` 를 추가합니다. `https://` 또는 `/저장소명`은 빼고 도메인만 넣습니다.

### Firebase Web 설정 복사 방법

GitHub 저장소 최상위에 `firebase-config.js` 라는 이름으로 파일을 만드세요. 아래 네 가지 값을 Firebase 웹 설정에서 실제 값으로 바꿉니다.

```javascript
export const firebaseConfig = {
  apiKey: '실제 apiKey',
  authDomain: '실제 authDomain',
  projectId: '실제 projectId',
  appId: '실제 appId'
};
```

이 값은 Firebase 공식 문서에서 **비밀 키가 아닌 앱 구성 값**으로 다룹니다. 그래도 **서버 관리자 서비스 계정 키는 절대 공개 저장소에 올리면 안 됩니다**. 이 프로젝트는 Firebase 규칙으로 가족 데이터를 보호합니다.

## ② GitHub에서 아이폰 앱과 Android APK 만들기

이전에 사용한 GitHub 계정으로 크롬을 열고, 새 GitHub 저장소를 하나 만듭니다. **무료 GitHub Pages를 사용하려면 저장소를 `Public`으로 만드세요.** 개인 가족 기록은 공개 저장소에 저장하지 않고 Firebase에 저장합니다.

GitHub 저장소 최상위에 다음 3개 파일을 준비하세요.

1. **`AgilogFamily.zip`** — 이 안내와 함께 받은 ZIP 파일입니다. **압축 해제하지 않고 올립니다.**
2. **`google-services.json`** — Firebase에서 Android 앱 등록 후 내려받은 JSON 파일.
3. **`firebase-config.js`** — 위 4개 값이 실제 Firebase 값인 Web 설정 파일. `REPLACE` 문자열이 들어 있으면 배포가 중단됩니다.

이후 GitHub **Add file → Create new file** 로 다음 경로를 만듭니다.

`.github/workflows/build-and-deploy.yml`

그리고 다운로드한 **압축파일 내부의 `.github/workflows/build-and-deploy.yml`** 의 텍스트 전체를 붙여넣어 커밋합니다. 프로젝트 ZIP 안의 `.github` 파일이 자동으로 실행되는 것이 아니기 때문에 **별도 생성이 필요합니다**.

GitHub 저장소에서 **Settings → Pages → Build and deployment → Source → GitHub Actions** 를 선택합니다. Actions 탭에서 `아기로그 가족 앱 · APK + 아이폰 웹앱`이 실행됩니다.

- 초록 체크 성공 후 **Android APK**는 `Actions → 해당 실행 → Artifacts → agi-log-family-android-apk` 로 다운로드합니다. 압축을 풀어 `app-debug.apk`를 설치합니다.
- **아이폰용 앱 주소**는 `Settings → Pages`의 링크, 또는 Actions의 `deploy-iphone-app` 결과에 표시됩니다. 예: `https://계정.github.io/저장소/`.

### 안드로이드 설치 관련

- **새 앱 ID `com.agilog.family`** 를 사용합니다. 이전에 설치한 `com.agilog.local`의 '아기로그'를 덮어쓰지 않습니다.
- 휴대폰에 **기존 아기로그와 새 아기로그 가족이 모두 나타날 수 있습니다**. 이전 앱의 잠금 화면 알림을 끄고, 앞으로는 새 `아기로그 가족`에서 기록하세요.
- **이전 로컬 기록은 자동으로 새 가족 앱에 복사되지 않습니다.** 이전 앱을 삭제하지 마세요. 중요한 기록은 기존 앱에서 수동으로 보관하세요.
- GitHub Actions는 시제품 디버그 APK를 만듭니다. 빌드마다 서명이 달라질 수 있어 이후 업데이트 설치에 실패할 수 있습니다. 정식 배포에는 고정 릴리스 서명 키가 필요합니다.

## ③ 아이폰에 설치하기

1. 위 GitHub Pages 링크를 **아이폰 Safari**로 엽니다.
2. Safari의 **공유** 아이콘 → **홈 화면에 추가**를 누릅니다.
3. **웹 앱으로 열기(Open as Web App)** 옵션이 나타나면 켭니다.
4. 홈 화면에 **아기로그 가족** 아이콘이 생성됩니다.
5. 아이폰에서 먼저 `새 가족 만들기` → 가족 코드 복사 → 안드로이드 앱에서 `가족 코드로 참여하기`를 선택하거나 그 반대 순서로 연결합니다.
6. 두 기기에서 같은 코드로 연결하고 각각 수유 또는 대소변을 기록해 보세요. 인터넷 연결이 있는 상태에서 기록 목록이 동기화됩니다.

## 개인정보·운영상 주의

- **가족 코드가 사실상 초대 권한입니다.** 아는 누구나 가족에 참여할 수 있으므로 안전하게 공유하세요. 이 시제품에는 코드 만료/재발급, 멤버 강제 퇴장, 계정 복구 기능이 없습니다. 20자리 난수 코드를 사용하여 추측 가능성을 낮췄지만, 코드를 공개하면 접근 위험이 있습니다.
- 각 설치는 **익명 Firebase Auth** UID를 사용합니다. PWA 브라우저 저장소 초기화/휴대폰 교체 시 UID가 바뀌며 새 가족 코드를 알고 있으면 새 사용자로 다시 참여할 수 있습니다. 과거 본인의 기록 삭제 권한은 새 UID로 복구되지 않습니다.
- Firestore 권한은 `firestore.rules`가 적용된 경우에만 가족 멤버로 제한됩니다. **실제 고객용 배포 전 보안 검토, Firebase App Check, 회원제 로그인, 가족 코드 변경, 데이터 내보내기/백업, 비용 제한과 감사를 추가하세요**.
- Android의 잠금 화면 알림은 제조사/One UI 버전에 따라 축소 표시되거나 잠금 해제를 요구할 수 있습니다. 앱은 잠금화면 잠금 보안을 우회할 수 없습니다.
- iPhone 웹 앱의 기록은 앱 화면에서만 할 수 있으며 **잠금화면 원터치 기록은 현재 제공되지 않습니다**. 별도 iOS 네이티브 WidgetKit 확장 및 Apple 서명 개발이 필요합니다.
- Firebase 기본 무료 사용량 범위 내에서는 무료일 수 있으나, 사용량과 플랜에 따라 과금될 수 있습니다. GitHub Actions/Pages에도 플랜·사용량 제한이 있습니다.
- **실제 APK/아이폰 실기기 테스트와 Firebase 연결 검증은 수행하지 못했습니다.** 이 파일은 구축·배포 가능한 시제품 소스이며, 제품 완성/운영을 보장하지 않습니다.

## 코드 폴더 안내

- `web`: 아이폰 사파리용 설치형 PWA (같은 URL은 안드로이드 브라우저에서도 실행 가능)
- `android`: Firebase 연결 안드로이드 Java 앱 및 잠금화면 알림
- `firestore.rules`: 가족·기록 접근을 제한하는 서버 보안 규칙
- `.github/workflows`: GitHub에 올려 쓸 빌드/배포 설정 사본

## 공식 문서

- https://support.apple.com/guide/iphone/turn-a-website-into-an-app-iphea86e5236/ios
- https://firebase.google.com/docs/auth/web/anonymous-auth
- https://firebase.google.com/docs/android/setup
- https://firebase.google.com/docs/firestore/security/get-started
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site


## v2.1 업데이트 (2026-10-31)
- 수유량 기본 70mL (30~1000mL / 10mL 단위 유지).
- 수유/소변/대변/소+대변 네 버튼(안드로이드 잠금 화면도 적용). 소+대변은 같은 크기 소/중/대 한 번에 기록.
- 최근 기록 터치 → 종류, 날짜·시간, 수유량/기저귀 양 수정 (iPhone 웹/Android 모두).
- 가족 구성원 누구나 기록을 수정할 수 있고, 삭제는 작성자만 할 수 있음. Firebase Firestore rules v2.1을 **반드시 별도로 게시**해야 수정 기능이 정상 작동함.
- GitHub 저장소에 이미 있는 AgilogFamily.zip 파일을 새 ZIP으로 교체하세요. 나머지 firebase-config.js, google-services.json 파일은 그대로 사용합니다.

## v2.2 업데이트 (2026-10-31)

- **5mL 단위 수유 기록**: 모유·유축·분유를 각 0~1000mL, 5mL 간격으로 설정합니다. 새 수유를 열면 분유 70mL가 기본으로 채워집니다. 세 항목의 합계는 최대 1000mL입니다.
- **한 번의 수유에 혼합 기록**: 예를 들어 모유 20 + 유축 30 + 분유 40mL를 **한 사건**으로 저장하고, 총량은 **90mL**로 집계합니다. 모유 직수를 별도 체크하여 **양 미측정**으로 남길 수도 있으며, 미측정량은 수유 총량에 포함하지 않습니다.
- **마지막 기록 경과시간**: 마지막 수유, 마지막 대변, 마지막 소변 각각에 대해 몇 시간/분이 지났는지 표시합니다. `소+대변` 기록은 소변과 대변의 마지막 시각을 함께 갱신합니다. 화면에 연결된 동안 약 1분마다 갱신합니다.
- **하루 누적 요약**: 기기 현지 시간의 자정~현재를 기준으로 총 수유량(mL), 수유 횟수, 대변 횟수, 소변 횟수를 계산합니다. `소+대변`은 대변 및 소변 각각 1회씩 계산합니다. 요약용으로 가족 기록 전체를 구독하고, 최근 기록 목록은 100개까지만 표시합니다.
- **기존 기록 호환**: 예전에 입력한 단일 종류 수유 및 양 미측정도 그대로 표시하고, 기록 수정 시 새 혼합 형식으로 변환할 수 있습니다.
- **잠금화면**: 안드로이드 알림의 수유량 조절 및 목록을 5mL 단위로 변경했습니다. **혼합 수유 입력은 앱을 열어 이용**하세요.
- **필수 작업**: Firebase Firestore의 규칙을 이번 ZIP의 `firestore.rules`로 먼저 교체/게시한 뒤, GitHub의 `AgilogFamily.zip`을 교체하세요. 기존 JS/JSON 설정 파일은 그대로 유지합니다.
- **검증 범위**: 웹 JavaScript 문법 검사와 앱 소스 구조 검사는 완료했지만, Android APK 컴파일·아이폰 Safari 실기기·Firestore 서버에 대한 실제 실행 테스트는 수행하지 못했습니다.


## v2.3 업데이트 (2026-10-31)

- **잠금 화면 요약 (Android)**: 마지막 수유 이후 경과 시간을 Chronometer로 표시하며, 오늘 0시부터의 총 수유량과 어제의 총 수유량을 표시합니다. 직접 모유 수유 중 미측정량은 총 mL에 포함하지 않습니다. 휴대폰 시간대 기준으로 날짜를 나눕니다.
- **업데이트 방식**: 앱이 열려 있으면 Firestore 실시간 변경 사항으로 요약이 갱신됩니다. 앱을 닫았을 때는 WorkManager가 네트워크 연결 시 약 15분 간격으로 서버를 조회하려고 시도합니다. 절전·배터리 설정·연결 상태에 따라 총량 갱신이 지연될 수 있지만 경과시간 Chronometer는 알림이 표시되는 동안 계속 흐릅니다.
- **소+대변 버튼**: 안드로이드 잠금 화면 알림의 네 번째 버튼은 `💧💩` 아이콘만 표시합니다(글자 제거). 앱 내부 버튼명은 유지합니다.
- **시간 지정**: 안드로이드 잠금 화면에서 수유 종류 및 용량 선택 후 ‘지금 저장’, ‘이전 저장’을 선택합니다. `−5분`/`+5분`으로 이전 시간을 5분씩 조절하며, 확대 알림의 ‘↩ 수유량 다시 선택’으로 이전 단계로 돌아갈 수 있습니다. 이전 저장의 초기 선택은 5분 전입니다. 앱 수유 대화상자에서도 현재 또는 이전 시간 선택 후 저장할 수 있습니다. 아이폰 웹앱에도 수유 시간 5분 단위 선택을 추가했습니다.
- **보안 규칙**: v2.2의 Firestore 규칙을 그대로 사용합니다. 새 데이터 필드를 추가하지 않습니다.
- **중요**: 사용자가 잠금 화면에 수유 기록을 표시하도록 요청한 기능이므로 잠금 화면을 볼 수 있는 사람도 최근 수유 정보와 수유량을 확인할 수 있습니다. Android 알림 개인 정보 표시 설정에서 숨길 수 있지만 그러면 잠금 화면 표시도 제한됩니다.
- **배포**: GitHub 저장소의 최상단 `AgilogFamily.zip`을 이 ZIP 파일로 교체합니다. 기존 `.github/workflows/build-and-deploy.yml`, `firebase-config.js`, `google-services.json`은 그대로 둘 수 있습니다.
- **검증**: 코드/XML/ZIP 검사 완료. Android 실기기/빌드 및 iPhone Safari 테스트는 별도로 확인이 필요합니다.
