from pathlib import Path
p=Path('/mnt/data/agilog_v3/android/app/src/main/java/com/agilog/local/MainActivity.java');s=p.read_text()
s=s.replace('import android.os.Bundle;','import android.os.Bundle;\nimport android.os.Handler;\nimport android.os.Looper;')
s=s.replace('import android.widget.Button;', 'import android.widget.Button;\nimport android.widget.CheckBox;')
s=s.replace('    private String status="가족 연결 준비 중...";', '''    private String status="가족 연결 준비 중...";
    private TextView dailyFeed, dailyPoop, dailyPee, lastFeed, lastPoop, lastPee, unknownNote;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable elapsedTick=new Runnable(){@Override public void run(){if("ready".equals(state))updateSummary();timer.postDelayed(this,60000L);}};''')
s=s.replace('    @Override protected void onResume(){super.onResume();if(QuickNotification.enabled(this))QuickNotification.show(this);}', '    @Override protected void onResume(){super.onResume();timer.removeCallbacks(elapsedTick);timer.post(elapsedTick);if(QuickNotification.enabled(this))QuickNotification.show(this);}\n    @Override protected void onPause(){timer.removeCallbacks(elapsedTick);super.onPause();}')
s=s.replace('    @Override protected void onDestroy(){if(listener!=null)listener.remove();super.onDestroy();}', '    @Override protected void onDestroy(){timer.removeCallbacks(elapsedTick);if(listener!=null)listener.remove();super.onDestroy();}')
s=s.replace('            .orderBy("at", Query.Direction.DESCENDING).limit(100)', '            .orderBy("at", Query.Direction.DESCENDING)')
start=s.index('        LinearLayout summary=card();');end=s.index('        root.addView(text("빠른 기록 +"',start)
s=s[:start]+'''        LinearLayout summary=card();summary.addView(text("오늘의 누적 기록",18,true));LinearLayout counts=row();
        dailyFeed=summaryTile(counts,"🍼 수유량", "0mL · 0회");
        dailyPoop=summaryTile(counts,"💩 대변", "0회");
        dailyPee=summaryTile(counts,"💧 소변", "0회");
        summary.addView(counts);
        unknownNote=text("※ 직접 모유 수유 양 미측정은 총 수유량에서 제외됩니다.",11,false);
        summary.addView(unknownNote,margin(-1,-2,8,0));
        summary.addView(text("마지막 기록으로부터",15,true),margin(-1,-2,16,5));
        LinearLayout times=row();
        lastFeed=summaryTile(times,"🍼 수유", "기록 없음");
        lastPoop=summaryTile(times,"💩 대변", "기록 없음");
        lastPee=summaryTile(times,"💧 소변", "기록 없음");
        summary.addView(times);root.addView(summary,margin(-1,-2,0,20));updateSummary();
'''+s[end:]
s=s.replace('수유·소변·대변·소+대변 4개 버튼을 잠금 화면 알림에서 선택할 수 있습니다. 수유 기본값은 70mL입니다.', '수유·소변·대변·소+대변을 잠금 화면 알림에서 기록합니다. 수유 용량은 5mL 단위이며, 혼합 수유는 앱에서 입력합니다.')
s=s.replace('        for(DocumentSnapshot snap:events){Map<String,Object> map=snap.getData();if(map==null)continue;', '        int shown=0;for(DocumentSnapshot snap:events){if(shown++>=100)break;Map<String,Object> map=snap.getData();if(map==null)continue;')
start=s.index('    private void pickFeed(){');end=s.index('    private Spinner spinner(',start)
s=s[:start]+'''    private TextView summaryTile(LinearLayout row,String title,String value){
        LinearLayout tile=col();tile.setPadding(dp(5),dp(12),dp(5),dp(12));tile.setBackground(bg(0xFFFFF0E7));
        TextView label=text(title,12,true);label.setGravity(Gravity.CENTER);tile.addView(label);
        TextView data=text(value,13,true);data.setGravity(Gravity.CENTER);tile.addView(data,margin(-1,-2,6,0));
        row.addView(tile,flex(78));return data;
    }
    private String since(Date date){
        if(date==null)return "기록 없음";
        long mins=Math.max(0,(System.currentTimeMillis()-date.getTime())/60000);
        if(mins<1)return "방금";if(mins<60)return mins+"분";
        long h=mins/60;if(h<24)return h+"시간 "+(mins%60)+"분";
        return (h/24)+"일 "+(h%24)+"시간";
    }
    private void updateSummary(){
        if(dailyFeed==null||dailyPoop==null||dailyPee==null)return;
        int total=0,feedCount=0,peeCount=0,poopCount=0;boolean unmeasured=false;
        Date lf=null,lp=null,lu=null;
        long day=startToday(),now=System.currentTimeMillis();
        for(DocumentSnapshot snap:events){Date date=snap.getDate("at");if(date==null)continue;
            String k=snap.getString("kind");if(k==null)continue;
            if(FamilyStore.FEED.equals(k)&& (lf==null||date.after(lf)))lf=date;
            if((FamilyStore.POOP.equals(k)||FamilyStore.BOTH.equals(k))&&(lp==null||date.after(lp)))lp=date;
            if((FamilyStore.PEE.equals(k)||FamilyStore.BOTH.equals(k))&&(lu==null||date.after(lu)))lu=date;
            if(date.getTime()<day||date.getTime()>now+300000)continue;
            if(FamilyStore.FEED.equals(k)){
                feedCount++;Map<String,Object> data=snap.getData();if(data!=null){total+=FamilyStore.knownMl(data);unmeasured|=FamilyStore.unknownBreast(data);}
            }
            if(FamilyStore.PEE.equals(k)||FamilyStore.BOTH.equals(k))peeCount++;
            if(FamilyStore.POOP.equals(k)||FamilyStore.BOTH.equals(k))poopCount++;
        }
        dailyFeed.setText(total+"mL · "+feedCount+"회");dailyPee.setText(peeCount+"회");dailyPoop.setText(poopCount+"회");
        if(unknownNote!=null)unknownNote.setVisibility(unmeasured?View.VISIBLE:View.GONE);
        if(lastFeed!=null)lastFeed.setText(since(lf));if(lastPoop!=null)lastPoop.setText(since(lp));if(lastPee!=null)lastPee.setText(since(lu));
    }
    private static class FeedInputs {
        EditText breast,pumped,formula;CheckBox unknown;
    }
    private EditText amountLine(LinearLayout parent,String label,int current){
        parent.addView(text(label+" (mL)",14,true),margin(-1,-2,9,0));
        LinearLayout line=row();EditText input=new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setSingleLine(true);
        input.setText(String.valueOf(current));input.setSelectAllOnFocus(true);
        Button minus=button("−5"),plus=button("+5");
        minus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.max(0,n-5)));});
        plus.setOnClickListener(v->{int n=parseAmount(input);input.setText(String.valueOf(Math.min(1000,n+5)));});
        line.addView(minus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,dp(54),1);mid.setMargins(dp(8),0,dp(8),0);line.addView(input,mid);
        line.addView(plus,new LinearLayout.LayoutParams(dp(67),dp(50)));
        parent.addView(line);return input;
    }
    private int parseAmount(EditText input){try{return Integer.parseInt(input.getText().toString().trim());}catch(Exception e){return 0;}}
    private FeedInputs feedInputs(LinearLayout parent,Map<String,Object> item,boolean isExisting){
        int breast=0,pumped=0,formula=isExisting?0:70;boolean unknown=false;
        if(isExisting&&item!=null){Object raw=item.get("feedParts");
            if(raw instanceof Map){Map<?,?> p=(Map<?,?>)raw;
                breast=FamilyStore.number(p.get("breastMl"));pumped=FamilyStore.number(p.get("pumpedMl"));
                formula=FamilyStore.number(p.get("formulaMl"));unknown=Boolean.TRUE.equals(p.get("breastUnmeasured"));
            }else{
                int ml=FamilyStore.number(item.get("ml"));String type=String.valueOf(item.get("feedType"));
                if(FamilyStore.BREAST.equals(type)){if(ml<0)unknown=true;else breast=ml;}
                else if(FamilyStore.PUMPED.equals(type))pumped=Math.max(0,ml);
                else if(FamilyStore.FORMULA.equals(type))formula=Math.max(0,ml);
            }
        }
        parent.addView(text("한 번에 모유 + 유축 + 분유 입력 가능 · 5mL 단위",12,false));
        FeedInputs f=new FeedInputs();f.breast=amountLine(parent,"모유",breast);
        f.pumped=amountLine(parent,"유축",pumped);f.formula=amountLine(parent,"분유",formula);
        f.unknown=new CheckBox(this);f.unknown.setText("직접 모유 수유 · 양 미측정 포함");f.unknown.setChecked(unknown);parent.addView(f.unknown);
        parent.addView(text("양 미측정 모유는 오늘의 총 수유량에 더하지 않습니다.",12,false));
        return f;
    }
    private Map<String,Object> checkedFeed(FeedInputs f){
        String[] values={f.breast.getText().toString().trim(),f.pumped.getText().toString().trim(),f.formula.getText().toString().trim()};
        int[] amounts=new int[3];int total=0;
        for(int i=0;i<3;i++){try{amounts[i]=Integer.parseInt(values[i]);}catch(Exception ex){throw new IllegalArgumentException("각 용량에 숫자를 입력하세요.");}
            if(amounts[i]<0||amounts[i]>1000||amounts[i]%5!=0)throw new IllegalArgumentException("수유량은 0~1000mL, 5mL 단위로 입력하세요.");
            total+=amounts[i];}
        if(total>1000||(total==0&&!f.unknown.isChecked()))throw new IllegalArgumentException("수유량 합계는 1000mL 이하로, 5mL 단위로 입력하세요. 미측정만 기록할 수도 있어요.");
        Map<String,Object> data=new HashMap<>();data.put("feedType",FamilyStore.feedType(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));
        data.put("ml",total);data.put("size","");data.put("feedParts",FamilyStore.feedParts(amounts[0],amounts[1],amounts[2],f.unknown.isChecked()));return data;
    }
    private void pickFeed(){
        ScrollView scroll=new ScrollView(this);LinearLayout root=col();root.setPadding(dp(17),dp(10),dp(17),dp(10));scroll.addView(root);
        FeedInputs inputs=feedInputs(root,null,false);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🍼 수유 기록 · 기본 70mL")
            .setView(scroll).setNegativeButton("취소",null).setPositiveButton("기록 저장",null).create();
        dialog.setOnShowListener(shown->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            Map<String,Object> data;
            try{data=checkedFeed(inputs);}catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            Map<?,?> p=(Map<?,?>)data.get("feedParts");
            RecordWorker.queueParts(this,FamilyStore.number(p.get("breastMl")),FamilyStore.number(p.get("pumpedMl")),
                FamilyStore.number(p.get("formulaMl")),Boolean.TRUE.equals(p.get("breastUnmeasured")));
            Toast.makeText(this,"수유 기록 전송 대기 중",Toast.LENGTH_SHORT).show();dialog.dismiss();
        }));dialog.show();
    }
'''+s[end:]
start=s.index('        LinearLayout feedBox=col();');end=s.index('        LinearLayout diaperBox=col();',start)
s=s[:start]+'''        LinearLayout feedBox=col();FeedInputs feed=feedInputs(feedBox,item,FamilyStore.FEED.equals(snap.getString("kind")));form.addView(feedBox);
'''+s[end:]
start=s.index('            if(FamilyStore.FEED.equals(k)){\n                int qty;');end=s.index('            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);',start)
s=s[:start]+'''            if(FamilyStore.FEED.equals(k)){
                try{changes.putAll(checkedFeed(feed));}
                catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}
            }else{
                changes.put("feedType","");changes.put("ml",0);changes.put("size",sizes[size.getSelectedItemPosition()]);
                changes.put("feedParts",FieldValue.delete());
            }
'''+s[end:]
p.write_text(s)
