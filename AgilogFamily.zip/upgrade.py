from pathlib import Path
root=Path('/mnt/data/agilog_v3'); web=root/'web/index.html'; text=web.read_text()
text=text.replace('repeat(3,1fr);gap:9px}', 'repeat(3,1fr);gap:9px}')
text=text.replace('.hint{font-size:12px;color:#937b83;margin:6px 0}', '.hint{font-size:12px;color:#937b83;margin:6px 0}.last-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:11px}.last-item{background:#fdf5f3;padding:11px 5px;border-radius:13px;text-align:center;font-size:12px}.last-item b{display:block;margin-top:7px;font-size:14px}.feed-line{display:grid;grid-template-columns:1fr 128px;align-items:center;gap:9px}.feed-line input{margin:4px 0}.feed-footnote{padding:10px;border-radius:12px;background:#faf0ed;margin:12px 0}.stat b{font-size:20px}.feed-line label{font-size:14px;font-weight:700}.feed-check{display:flex;align-items:center;gap:8px;margin-top:8px;font-size:13px}.feed-check input{width:20px;height:20px;margin:0}.picker-feed-actions{display:flex;gap:8px}.picker-feed-actions button{flex:1}')
old='''<div class="grid"><div class="stat">🍼<b id="n-feed">0</b><span>수유</span></div><div class="stat">💩<b id="n-poop">0</b><span>대변</span></div><div class="stat">💧<b id="n-pee">0</b><span>소변</span></div></div></section>'''
new='''<div class="grid"><div class="stat">🍼<b id="total-feed">0mL</b><span>총 수유량 <span id="n-feed">0회</span></span></div><div class="stat">💩<b id="n-poop">0회</b><span>대변 횟수</span></div><div class="stat">💧<b id="n-pee">0회</b><span>소변 횟수</span></div></div>
<p id="unknown-feed" class="hint hidden">※ 모유 양 미측정 기록은 총 수유량에서 제외됩니다.</p>
<div class="last-grid"><div class="last-item">마지막 수유<b id="last-feed">기록 없음</b></div><div class="last-item">마지막 대변<b id="last-poop">기록 없음</b></div><div class="last-item">마지막 소변<b id="last-pee">기록 없음</b></div></div></section>'''
assert old in text;text=text.replace(old,new)
old='''<label class="field">수유 종류<select id="editFeedType"><option value="breast">모유</option><option value="pumped">유축</option><option value="formula">분유</option></select></label>
<label class="field">수유량(mL)<input type="number" id="editMl" min="30" max="1000" step="10" value="70"></label>
<p class="hint">기본 70mL · 10mL 단위 · 직접 모유 수유는 -1 입력 시 양 미측정</p>'''
new='''<p class="hint">한 번의 수유에 모유·유축·분유를 동시에 입력할 수 있어요. 5mL 단위 (기본 분유 70mL).</p>
<div class="feed-line"><label for="editBreastMl">모유 (mL)</label><input type="number" id="editBreastMl" min="0" max="1000" step="5" value="0"></div>
<div class="feed-line"><label for="editPumpedMl">유축 (mL)</label><input type="number" id="editPumpedMl" min="0" max="1000" step="5" value="0"></div>
<div class="feed-line"><label for="editFormulaMl">분유 (mL)</label><input type="number" id="editFormulaMl" min="0" max="1000" step="5" value="70"></div>
<label class="feed-check"><input type="checkbox" id="editBreastUnknown">직접 모유 수유 · 양 미측정 포함</label>
<p class="hint">확인된 양만 오늘의 총 수유량에 더합니다.</p>'''
assert old in text;text=text.replace(old,new)
# replacing picker contents dynamic JS; add support in HTML via JS only
web.write_text(text)
