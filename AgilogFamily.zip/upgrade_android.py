from pathlib import Path
p=Path('/mnt/data/agilog_v3/android/app/src/main/java/com/agilog/local/FamilyStore.java');s=p.read_text()
s=s.replace('static String typeLabel(String type){return BREAST.equals(type)?"모유":PUMPED.equals(type)?"유축":"분유";}', 'static String typeLabel(String type){return BREAST.equals(type)?"모유":PUMPED.equals(type)?"유축":"mixed".equals(type)?"혼합":"분유";}')
start=s.index('    static String detail(');end=s.index('    private FamilyStore()',start)
s=s[:start]+'''    static int knownMl(Map<String,Object> row){
        if(!FEED.equals(row.get("kind"))||Boolean.TRUE.equals(row.get("legacy")))return 0;
        Object obj=row.get("feedParts");
        if(obj instanceof Map){Map<?,?> p=(Map<?,?>)obj;return number(p.get("breastMl"))+number(p.get("pumpedMl"))+number(p.get("formulaMl"));}
        return Math.max(0,number(row.get("ml")));
    }
    static int number(Object value){return value instanceof Number?((Number)value).intValue():0;}
    static boolean unknownBreast(Map<String,Object> row){
        Object p=row.get("feedParts");if(p instanceof Map)return Boolean.TRUE.equals(((Map<?,?>)p).get("breastUnmeasured"));
        return BREAST.equals(row.get("feedType"))&&number(row.get("ml"))==-1;
    }
    static Map<String,Object> feedParts(int breast,int pumped,int formula,boolean unknown){
        Map<String,Object> p=new HashMap<>();p.put("breastMl",breast);p.put("pumpedMl",pumped);p.put("formulaMl",formula);p.put("breastUnmeasured",unknown);return p;
    }
    static String feedType(int breast,int pumped,int formula,boolean unknown){
        int c=(breast>0||unknown?1:0)+(pumped>0?1:0)+(formula>0?1:0);
        return c>1?"mixed":breast>0||unknown?BREAST:pumped>0?PUMPED:FORMULA;
    }
    static String detail(Map<String,Object> row){String kind=String.valueOf(row.get("kind"));
        if(Boolean.TRUE.equals(row.get("legacy")))return "이전 기록 · 상세 정보 없음";
        if(FEED.equals(kind)){
            Object parts=row.get("feedParts");
            if(!(parts instanceof Map)){
                int ml=number(row.get("ml"));return typeLabel(String.valueOf(row.get("feedType")))+" · "+(ml==-1?"양 미측정":ml+"mL");
            }
            Map<?,?> p=(Map<?,?>)parts;StringBuilder b=new StringBuilder();
            if(number(p.get("breastMl"))>0)b.append("모유 ").append(number(p.get("breastMl"))).append("mL · ");
            if(Boolean.TRUE.equals(p.get("breastUnmeasured")))b.append("모유 미측정 · ");
            if(number(p.get("pumpedMl"))>0)b.append("유축 ").append(number(p.get("pumpedMl"))).append("mL · ");
            if(number(p.get("formulaMl"))>0)b.append("분유 ").append(number(p.get("formulaMl"))).append("mL · ");
            b.append("합계 ").append(knownMl(row)).append("mL");return b.toString();
        }
        return "양 "+sizeLabel(String.valueOf(row.get("size")));
    }
'''+s[end:];p.write_text(s)

p=Path('/mnt/data/agilog_v3/android/app/src/main/java/com/agilog/local/RecordWorker.java');s=p.read_text()
s=s.replace('    @NonNull @Override public Result doWork(){', '''    static void queueParts(Context c,int breast,int pumped,int formula,boolean unknown){
        String id=UUID.randomUUID().toString();
        Data data=new Data.Builder().putString("id",id).putString("family",FamilyStore.code(c))
            .putString("kind",FamilyStore.FEED).putString("type",FamilyStore.feedType(breast,pumped,formula,unknown))
            .putInt("ml",breast+pumped+formula).putString("size","")
            .putLong("at",System.currentTimeMillis()).putBoolean("legacy",false)
            .putBoolean("hasParts",true).putInt("breastMl",breast).putInt("pumpedMl",pumped)
            .putInt("formulaMl",formula).putBoolean("breastUnmeasured",unknown).build();
        OneTimeWorkRequest job=new OneTimeWorkRequest.Builder(RecordWorker.class)
            .setInputData(data).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.SECONDS).build();
        WorkManager.getInstance(c).enqueueUniqueWork("agi-record-"+id,ExistingWorkPolicy.KEEP,job);
    }
    @NonNull @Override public Result doWork(){''')
s=s.replace('            Tasks.await(ref.set(event),20,TimeUnit.SECONDS);', '''            if(getInputData().getBoolean("hasParts",false))event.put("feedParts",FamilyStore.feedParts(
                getInputData().getInt("breastMl",0),getInputData().getInt("pumpedMl",0),
                getInputData().getInt("formulaMl",0),getInputData().getBoolean("breastUnmeasured",false)));
            Tasks.await(ref.set(event),20,TimeUnit.SECONDS);''')
p.write_text(s)

p=Path('/mnt/data/agilog_v3/android/app/src/main/java/com/agilog/local/QuickNotification.java');s=p.read_text()
s=s.replace('"−10"','"−5"').replace('"+10"','"+5"')
s=s.replace('int start=30+page*80;', 'int start=5+page*40;')
s=s.replace('int ml=start+i*10;', 'int ml=start+i*5;')
s=s.replace('start+80<=1000', 'start+40<=1000')
s=s.replace('amount+10','amount+5').replace('Math.max(30,amount-10)','Math.max(5,amount-5)')
s=s.replace('Math.min(12,page+1)','Math.min(24,page+1)')
s=s.replace('ml<30||ml>1000||ml%10!=0||ml<30+page*80||ml>100+page*80','ml<5||ml>1000||ml%5!=0||ml<5+page*40||ml>40+page*40')
p.write_text(s)

p=Path('/mnt/data/agilog_v3/android/app/build.gradle');s=p.read_text().replace('versionCode 5','versionCode 6').replace("versionName '2.1.0'","versionName '2.2.0'");p.write_text(s)
